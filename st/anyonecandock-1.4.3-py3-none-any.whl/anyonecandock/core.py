#!/usr/bin/env python3
"""
core-local.py — Pure computation layer for Anyone Can Dock (local machine edition).
No Streamlit imports. All functions return plain dicts / tuples.
Safe to import in local scripts, pytest, or any UI framework.

Compatible with: macOS (Apple Silicon + Intel), Linux (x86_64), Windows (x86_64).

Patch 2025-05: three PDB-parsing fixes for atoms like Br in 4S9 / partial-occupancy entries:
  Fix A  _strip_anisou(text)         — remove ANISOU/SIGUIJ lines before ProDy / line-readers
  Fix B  _keep_best_altloc(text)     — keep highest-occupancy alt-conf, blank altLoc column
  Fix C  _atom_name_to_element()     — resolve "BR1" → "BR", "FE2" → "FE" etc.
  Fix D  _clean_pdb_text(text)       — convenience wrapper calling A+B
  Fix E  _clean_pdb_file(path)       — read/clean/write cleaned copy; returns cleaned path

These are applied in:
  scan_hetatm_residues()      — before parsePDB (Fix A+B) and in line-reader (Fix C)
  prepare_receptor()          — before parsePDB (Fix A+B)
  strip_and_convert_receptor()— in the HETATM line-reader (Fix C) and before obabel (Fix A+B)
"""

import json
import os
import platform as _platform
import subprocess
import sys
import tempfile
import time
import re as _re
from pathlib import Path

from .heme_state import apply_and_validate_pdbqt, prepare_heme_centers
from .ligand_validation import (
    file_sha256, validate_ligand_file, read_atom_records, mapping_row,
    write_mapping_report, validate_pdb_mapping,
)

# ── Platform helpers ──────────────────────────────────────────────────────────
_SYS    = _platform.system().lower()          # "linux" | "darwin" | "windows"
_IS_WIN = _SYS == "windows"
_IS_MAC = _SYS == "darwin"
_IS_LIN = _SYS == "linux"
# Shell null-redirect token — safe to embed in f-string shell commands.
_NULL   = "2>NUL" if _IS_WIN else "2>/dev/null"


def _silence_rdkit_logs():
    try:
        from rdkit import RDLogger, rdBase
        for name in ("rdApp.*", "rdApp.error", "rdApp.warning", "rdApp.info", "rdApp.debug"):
            try:
                RDLogger.DisableLog(name)
            except Exception:
                pass
            try:
                rdBase.DisableLog(name)
            except Exception:
                pass
        try:
            RDLogger.EnableLog = lambda *args, **kwargs: None
        except Exception:
            pass
        try:
            rdBase.EnableLog = lambda *args, **kwargs: None
        except Exception:
            pass
    except Exception:
        pass


_silence_rdkit_logs()

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

METAL_RESNAMES = {
    "MG", "ZN", "CA", "MN", "FE", "CU", "CO", "NI", "CD", "HG", "NA", "K", "HO",
    "LA", "CE", "PR", "ND", "PM", "SM", "EU", "GD", "TB", "DY", "ER", "TM", "YB", "LU",
}
METAL_CHARGES = {
    "MG": 2.0, "ZN": 2.0, "CA": 2.0, "MN": 2.0, "FE": 3.0,
    "CU": 2.0, "CO": 2.0, "NI": 2.0, "CD": 2.0, "HG": 2.0, "HO": 3.0,
    "LA": 3.0, "CE": 3.0, "PR": 3.0, "ND": 3.0, "PM": 3.0, "SM": 3.0,
    "EU": 3.0, "GD": 3.0, "TB": 3.0, "DY": 3.0, "ER": 3.0, "TM": 3.0,
    "YB": 3.0, "LU": 3.0,
    "NA": 1.0, "K":  1.0,
}

EXCLUDE_IONS = set(
    "HOH,WAT,DOD,SOL,NA,CL,K,CA,MG,ZN,MN,FE,CU,CO,NI,CD,HG,HO,LA,CE,PR,ND,PM,SM,EU,GD,TB,DY,ER,TM,YB,LU".split(",")
)
GLYCAN_NAMES = {
    "NAG", "BMA", "MAN", "FUC", "GAL", "GLC", "SIA", "NGA",
    "FUL", "GLA", "BGC", "A2G", "LAT", "MAL", "CEL", "SUC",
    "TRE", "GCS", "NDG", "NGC",
}
COFACTOR_NAMES = {
    "ATP", "ADP", "AMP", "GTP", "GDP", "GMP",
    "NAD", "NAP", "NDP", "FAD", "FMN",
    "HEM", "HEC", "HEA",
    "GOL", "PEG", "EDO", "MPD", "PGE", "PG4",
    "SO4", "PO4", "SUL", "PHO",
    "IHP", "TTP", "CTP", "UTP",
    "COA", "SAM", "SAH",
    "EPE", "MES", "TRS", "ACT", "ACY",
    "HO", "LA", "CE", "PR", "ND", "PM", "SM", "EU", "GD", "TB", "DY", "ER", "TM", "YB", "LU",
}

HEME_RESNAMES = {"HEM", "HEC", "HEA", "HEB", "HDD", "HDM"}

# ── Nucleotide / methyl-donor ligands used to DEFINE the grid box ─────────────
# ATP, SAM, SAH and close analogs are usually the binding-site-defining ligand
# (ATP-competitive kinase inhibitors, SAM/SAH-site methyltransferase inhibitors).
# Treat them as co-crystal *reference* ligands for grid-box centering: removed
# from the receptor and used to center the box, not kept as passive cofactors.
#
# NOTE: several of these (ATP, ADP, AMP, GTP, GDP, GMP, SAM, SAH) also
# appear in COFACTOR_NAMES. Because _guess_hetatm_type checks this set BEFORE
# COFACTOR_NAMES, and _collect_removable_ligands subtracts this set from its
# exclusion list, membership here wins and they are classified as "ligand".
REFERENCE_LIGAND_COFACTORS = {
    "ATP", "ADP", "AMP",
    "ANP",   # AMP-PNP (adenylyl-imidodiphosphate)
    "AGS",   # ATP-gamma-S
    "ACP",   # AMP-PCP (beta,gamma-methylene-ATP)
    "APC",   # diphosphomethylphosphonic-acid adenosyl ester
    "GTP", "GDP", "GMP",
    "GNP",   # GMP-PNP (GppNHp)
    "GSP",   # GTP-gamma-S
    "GCP",   # GMP-PCP (GppCp)
    "SAM",   # S-adenosyl-L-methionine
    "SAH",   # S-adenosyl-L-homocysteine
}

_PV_MAX_RETRIES = 3
_PV_RETRY_DELAY = 10
_PV_POLL_ATTEMPTS = 60


# ══════════════════════════════════════════════════════════════════════════════
#  PDB CLEANING HELPERS  (Patch 2025-05 — Fixes A–E)
# ══════════════════════════════════════════════════════════════════════════════

def _strip_anisou(pdb_text: str) -> str:
    """
    Fix A — Remove ANISOU and SIGUIJ records.

    These anisotropic B-factor lines immediately follow the ATOM/HETATM they
    belong to.  ProDy (some builds) and any line-by-line reader that advances
    one record at a time can land on the ANISOU line and either miscount
    atoms or silently drop the preceding HETATM.

    Example entry that triggered the bug:
        HETATM 7319 BR1  4S9 A1101  86.832 121.044  17.730  0.80 30.83  BR
        ANISOU 7319 BR1  4S9 A1101   3962   3965   3786   344    90   -56  BR

    Stripping ANISOU/SIGUIJ is safe — they carry no coordinate information.
    """
    out = []
    for line in pdb_text.splitlines(keepends=True):
        rec = line[:6]   # deliberately NOT .strip() — exact column check
        if rec in ("ANISOU", "SIGUIJ"):
            continue
        out.append(line)
    return "".join(out)


def _keep_best_altloc(pdb_text: str) -> str:
    """
    Fix B — Resolve alternate conformations.

    Keep the highest-occupancy alt-loc for each atom; blank the altLoc column
    (column 17, 0-indexed 16) so downstream tools see a normal single-conformer
    file.

    Example: BR1 at altLoc A / occ 0.80  +  altLoc B / occ 0.20
    Result:  BR1 with blank altLoc and occ 0.80 — no longer dropped.

    Without this fix, tools that skip non-blank or non-'A' altLoc atoms (e.g.
    Meeko, some ProDy selectors, obabel) silently lose the atom.
    """
    from collections import defaultdict

    lines = pdb_text.splitlines(keepends=True)

    # First pass: for each unique (chain, resseq, icode, atom-name) key that
    # has alt-loc variants, find the line index of the best conformer.
    # Key layout (all from fixed PDB columns):
    #   chain  = col 22   (0-indexed 21)
    #   resseq = cols 23-26 stripped
    #   icode  = col 27   (0-indexed 26)
    #   name   = cols 13-16
    best: dict = defaultdict(lambda: (" ", -1.0, -1))
    for i, line in enumerate(lines):
        rec = line[:6].strip()
        if rec not in ("ATOM", "HETATM") or len(line) < 27:
            continue
        altloc = line[16]
        if altloc == " ":
            continue  # no alt-conf — always kept; no tracking needed
        try:
            occ = float(line[54:60])
        except (ValueError, IndexError):
            occ = 0.0
        key = (
            line[21] if len(line) > 21 else " ",   # chain
            line[22:26].strip(),                     # resseq
            line[26] if len(line) > 26 else " ",    # icode
            line[12:16],                             # atom name (4 chars)
        )
        if occ > best[key][1]:
            best[key] = (altloc, occ, i)

    if not best:
        return pdb_text  # nothing to resolve — return unchanged

    keep_indices = {v[2] for v in best.values()}

    out = []
    for i, line in enumerate(lines):
        rec = line[:6].strip()
        if rec in ("ATOM", "HETATM") and len(line) > 16 and line[16] != " ":
            key = (
                line[21] if len(line) > 21 else " ",
                line[22:26].strip(),
                line[26] if len(line) > 26 else " ",
                line[12:16],
            )
            if i not in keep_indices:
                continue  # drop lower-occupancy conformer
            # Blank altLoc column so downstream tools treat it as normal
            line = line[:16] + " " + line[17:]
        out.append(line)
    return "".join(out)


def _atom_name_to_element(atom_name: str, element_col: str = "") -> str:
    """
    Fix C — Derive a 1–2 char element symbol from a PDB atom name field
    (cols 13–16) and the optional element column (cols 77–78).

    Handles non-standard names that include serial digits, e.g.:
      "BR1 " → "BR"      " FE2" → "FE"      " C  " → "C"
      "ZN1 " → "ZN"      "CL1 " → "CL"      "NA1 " → "NA"

    Priority: explicit element column > two-letter lookup > first letter.
    """
    # Prefer the explicit element column when present and purely alphabetic
    el = element_col.strip().upper()
    if el and el.isalpha():
        return el

    # Strip digits and whitespace, then take leading letters
    name = atom_name.strip().upper()
    letters = _re.sub(r"[^A-Z]", "", name)

    # Known two-letter elements that commonly appear as HETATM / metal ions
    TWO_LETTER = {
        "BR", "CL", "FE", "ZN", "MG", "CA", "MN", "CU", "CO",
        "NI", "CD", "HG", "SE", "NA", "AL", "SI", "AU", "AG",
        "RU", "RH", "PD", "PT", "IR", "OS", "RE", "MO", "TC",
        "SN", "PB", "BI", "SB", "TE", "AS", "GE", "GA", "IN",
        "TL", "BA", "SR", "CS", "RB", "LI", "BE", "SC", "TI",
        "CR", "YB", "LU", "TM", "ER", "DY", "TB", "GD",
        "EU", "SM", "PM", "ND", "PR", "CE", "LA",
    }
    if len(letters) >= 2 and letters[:2] in TWO_LETTER:
        return letters[:2]
    return letters[:1] if letters else "X"


def _parse_pdb_atom_line(line: str) -> dict:
    return {
        "record": line[:6].strip() or "HETATM",
        "serial": int(line[6:11]) if line[6:11].strip() else 0,
        "name": line[12:16].strip(),
        "resname": line[17:20].strip() or "LIG",
        "chain": (line[21] if len(line) > 21 else " ") or " ",
        "resid": int(line[22:26]) if line[22:26].strip() else 1,
        "x": float(line[30:38]),
        "y": float(line[38:46]),
        "z": float(line[46:54]),
        "element": _atom_name_to_element(line[12:16], line[76:78] if len(line) > 77 else ""),
    }


def _format_pdb_atom_line(
    serial: int,
    name: str,
    resname: str,
    chain: str,
    resid: int,
    x: float,
    y: float,
    z: float,
    element: str,
    record: str = "HETATM",
) -> str:
    atom_name = name[:4].strip()
    if len(atom_name) < 4:
        atom_name = atom_name.rjust(4)
    return (
        f"{record:<6}{serial:5d} {atom_name:<4} {resname:>3} {chain[:1]}{resid:4d}    "
        f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00          {element[:2].rjust(2)}\n"
    )


def _parse_pdbqt_atom_line(line: str) -> dict:
    tail = line[66:].split()
    charge = 0.0
    atype = "C"
    if tail:
        atype = tail[-1]
        if len(tail) >= 2:
            try:
                charge = float(tail[-2])
            except Exception:
                charge = 0.0
    return {
        "record": line[:6].strip() or "HETATM",
        "serial": int(line[6:11]) if line[6:11].strip() else 0,
        "name": line[12:16].strip(),
        "x": float(line[30:38]),
        "y": float(line[38:46]),
        "z": float(line[46:54]),
        "charge": charge,
        "atype": atype,
    }


def _format_pdbqt_atom_line(
    serial: int,
    name: str,
    resname: str,
    chain: str,
    resid: int,
    x: float,
    y: float,
    z: float,
    charge: float,
    atype: str,
    record: str = "HETATM",
) -> str:
    atom_name = name[:4].strip()
    if len(atom_name) < 4:
        atom_name = atom_name.rjust(4)
    return (
        f"{record:<6}{serial:5d} {atom_name:<4} {resname:<3s} "
        f"{chain[:1]}{resid:4d}    "
        f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00"
        f"    {charge:+.3f} {atype}\n"
    )


def _write_atom_block(lines: list[str], out_path: str):
    with open(out_path, "w") as f:
        for line in lines:
            if line[:6].strip() in ("ATOM", "HETATM", "TER"):
                f.write(line if line.endswith("\n") else line + "\n")
        f.write("END\n")


def _overlay_heme_pdb_lines(prepared_pdb: str, template_lines: list[str]) -> list[str]:
    template_atoms = [_parse_pdb_atom_line(l) for l in template_lines if l[:6].strip() in ("ATOM", "HETATM")]
    if not template_atoms:
        return []
    template_by_name = {a["name"].upper(): a for a in template_atoms}
    anchor = template_atoms[0]
    next_serial = max(a["serial"] for a in template_atoms) + 1
    out = []
    with open(prepared_pdb) as f:
        for line in f:
            if line[:6].strip() not in ("ATOM", "HETATM"):
                continue
            atom = _parse_pdb_atom_line(line)
            meta = template_by_name.get(atom["name"].upper())
            if meta is not None:
                serial = meta["serial"]
                resname = meta["resname"]
                chain = meta["chain"]
                resid = meta["resid"]
                record = meta["record"]
            else:
                serial = next_serial
                next_serial += 1
                resname = anchor["resname"]
                chain = anchor["chain"]
                resid = anchor["resid"]
                record = "HETATM"
            out.append(
                _format_pdb_atom_line(
                    serial=serial,
                    name=atom["name"],
                    resname=resname,
                    chain=chain,
                    resid=resid,
                    x=atom["x"],
                    y=atom["y"],
                    z=atom["z"],
                    element=atom["element"],
                    record=record,
                )
            )
    return out


def _overlay_heme_pdbqt_lines(prepared_pdbqt: str, template_lines: list[str]) -> list[str]:
    template_atoms = [_parse_pdb_atom_line(l) for l in template_lines if l[:6].strip() in ("ATOM", "HETATM")]
    if not template_atoms:
        return []
    template_by_name = {a["name"].upper(): a for a in template_atoms}
    anchor = template_atoms[0]
    next_serial = max(a["serial"] for a in template_atoms) + 1
    out = []
    with open(prepared_pdbqt) as f:
        for line in f:
            if line[:6].strip() not in ("ATOM", "HETATM"):
                continue
            atom = _parse_pdbqt_atom_line(line)
            meta = template_by_name.get(atom["name"].upper())
            if meta is not None:
                serial = meta["serial"]
                resname = meta["resname"]
                chain = meta["chain"]
                resid = meta["resid"]
                record = meta["record"]
            else:
                serial = next_serial
                next_serial += 1
                resname = anchor["resname"]
                chain = anchor["chain"]
                resid = anchor["resid"]
                record = "HETATM"
            out.append(
                _format_pdbqt_atom_line(
                    serial=serial,
                    name=atom["name"],
                    resname=resname,
                    chain=chain,
                    resid=resid,
                    x=atom["x"],
                    y=atom["y"],
                    z=atom["z"],
                    charge=atom["charge"],
                    atype=atom["atype"],
                    record=record,
                )
            )
    return out


def _prepare_heme_block(heme_lines: list[str], wdir, log: list[str]) -> dict:
    import shutil

    wdir = Path(wdir)
    result = {
        "display_lines": list(heme_lines),
        "pdbqt_lines": [],
        "display_method": "raw",
        "pdbqt_method": "manual",
    }
    if not heme_lines:
        return result

    heme_raw = str(wdir / "heme_raw.pdb")
    heme_h = str(wdir / "heme_h.pdb")
    heme_mol2 = str(wdir / "heme_h.mol2")
    heme_meeko = str(wdir / "heme_meeko.pdbqt")
    heme_obabel_pdbqt = str(wdir / "heme_obabel.pdbqt")
    _write_atom_block(heme_lines, heme_raw)

    rc_h, out_h = run_cmd(f'obabel "{heme_raw}" -O "{heme_h}" -h')
    if os.path.exists(heme_h) and os.path.getsize(heme_h) > 100:
        display_lines = _overlay_heme_pdb_lines(heme_h, heme_lines)
        if display_lines:
            result["display_lines"] = display_lines
            result["display_method"] = "obabel-h"
            log.append("✓ Heme hydrogens added via isolated OpenBabel pass")
    else:
        log.append(f"⚠ Isolated Heme hydrogenation failed (exit {rc_h}): {out_h[:240]}")

    meeko_cmd = shutil.which("mk_prepare_ligand.py")
    if meeko_cmd and os.path.exists(heme_h):
        rc_mol2, out_mol2 = run_cmd(f'obabel "{heme_h}" -O "{heme_mol2}"')
        if os.path.exists(heme_mol2) and os.path.getsize(heme_mol2) > 100:
            rc_meeko, out_meeko = run_cmd(
                f'"{meeko_cmd}" -i "{heme_mol2}" -o "{heme_meeko}"'
            )
            if os.path.exists(heme_meeko) and os.path.getsize(heme_meeko) > 100:
                pdbqt_lines = _overlay_heme_pdbqt_lines(heme_meeko, heme_lines)
                if pdbqt_lines:
                    result["pdbqt_lines"] = pdbqt_lines
                    result["pdbqt_method"] = "meeko"
                    log.append("✓ Heme PDBQT prepared via Meeko (isolated cofactor path)")
            else:
                msg = out_meeko or out_mol2
                log.append(f"⚠ Meeko Heme preparation failed; will try OpenBabel fallback ({msg[:240]})")
        else:
            log.append(f"⚠ Could not convert isolated Heme to MOL2 for Meeko ({out_mol2[:240]})")

    if os.path.exists(heme_h):
        rc_pdbqt, out_pdbqt = run_cmd(
            f'obabel "{heme_h}" -O "{heme_obabel_pdbqt}" -xrhnp --partialcharge gasteiger'
        )
        if os.path.exists(heme_obabel_pdbqt) and os.path.getsize(heme_obabel_pdbqt) > 100:
            pdbqt_lines = _overlay_heme_pdbqt_lines(heme_obabel_pdbqt, heme_lines)
            if pdbqt_lines:
                result["pdbqt_lines"] = pdbqt_lines
                result["pdbqt_method"] = "obabel-preserve-h"
                log.append("✓ Heme PDBQT prepared via isolated OpenBabel with hydrogens preserved")
        else:
            log.append(f"⚠ Isolated Heme PDBQT fallback failed (exit {rc_pdbqt}): {out_pdbqt[:240]}")

    return result


def _prepare_isolated_residue_block(lines: list[str], wdir, stem: str, log: list[str], label: str) -> dict:
    wdir = Path(wdir)
    result = {
        "display_lines": list(lines),
        "pdbqt_lines": [],
        "display_method": "raw",
        "pdbqt_method": "manual",
    }
    if not lines:
        return result

    raw_pdb = str(wdir / f"{stem}_raw.pdb")
    h_pdb = str(wdir / f"{stem}_h.pdb")
    pdbqt = str(wdir / f"{stem}.pdbqt")
    _write_atom_block(lines, raw_pdb)

    rc_h, out_h = run_cmd(f'obabel "{raw_pdb}" -O "{h_pdb}" -h')
    if os.path.exists(h_pdb) and os.path.getsize(h_pdb) > 100:
        display_lines = _overlay_heme_pdb_lines(h_pdb, lines)
        if display_lines:
            result["display_lines"] = display_lines
            result["display_method"] = "obabel-h"
            log.append(f"✓ {label} hydrogens added via isolated OpenBabel pass")
        rc_pdbqt, out_pdbqt = run_cmd(f'obabel "{h_pdb}" -O "{pdbqt}" -xr --partialcharge gasteiger')
        if os.path.exists(pdbqt) and os.path.getsize(pdbqt) > 20:
            pdbqt_lines = _overlay_heme_pdbqt_lines(pdbqt, lines)
            if pdbqt_lines:
                result["pdbqt_lines"] = pdbqt_lines
                result["pdbqt_method"] = "obabel"
                log.append(f"✓ {label} PDBQT prepared from hydrogenated isolated block")
        else:
            log.append(f"⚠ {label} isolated PDBQT preparation failed (exit {rc_pdbqt}): {out_pdbqt[:240]}")
    else:
        log.append(f"⚠ {label} isolated hydrogenation failed (exit {rc_h}): {out_h[:240]}")
    return result


def _clean_pdb_text(pdb_text: str) -> str:
    """
    Fix D — Apply Fix A + Fix B in sequence.
    Safe to call on any PDB string (no-op on CIF).
    """
    pdb_text = _strip_anisou(pdb_text)
    pdb_text = _keep_best_altloc(pdb_text)
    return pdb_text


def _clean_pdb_file(path: str) -> str:
    """
    Fix E — Read a PDB file, apply _clean_pdb_text, write a '_cleaned.pdb'
    copy alongside the original, and return the cleaned path.

    Returns the original path unchanged on any error or if the file is CIF.
    The cleaned file is idempotent — calling twice produces the same result.
    """
    try:
        # Skip CIF files — _clean_pdb_text is PDB-specific
        if is_cif_file(path):
            return path
        raw = open(path).read()
        cleaned = _clean_pdb_text(raw)
        if cleaned == raw:
            return path  # nothing changed; avoid extra write
        out_path = _re.sub(r"\.(pdb|ent)$", "_cleaned.pdb", path, flags=_re.IGNORECASE)
        if out_path == path:
            out_path = path + "_cleaned.pdb"
        with open(out_path, "w") as fh:
            fh.write(cleaned)
        return out_path
    except Exception:
        return path  # graceful degradation


# ══════════════════════════════════════════════════════════════════════════════
#  UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def run_cmd(cmd, cwd=None):
    r = subprocess.run(
        cmd, shell=isinstance(cmd, str),
        capture_output=True, text=True, cwd=cwd,
    )
    return r.returncode, (r.stdout + r.stderr).strip()


def _format_residue_identity(chain: str, resid: str, icode: str) -> str:
    chain = (chain or "").strip() or "_"
    resid = str(resid).strip()
    icode = (icode or "").strip()
    return f"{chain}:{resid}{icode}" if icode else f"{chain}:{resid}"


def _collect_residue_identity_map(pdb_path: str) -> dict:
    residues = {}
    with open(pdb_path) as f:
        for line in f:
            if line[:6].strip() not in ("ATOM", "HETATM"):
                continue
            resid = line[22:26].strip()
            if not resid:
                continue
            chain = line[21] if len(line) > 21 else " "
            icode = line[26] if len(line) > 26 else " "
            key = _format_residue_identity(chain, resid, icode)
            info = residues.setdefault(key, {
                "chain": (chain or "").strip() or "_",
                "resid": resid,
                "icode": (icode or "").strip(),
                "resnames": set(),
            })
            info["resnames"].add(line[17:20].strip().upper())
    for info in residues.values():
        info["resnames"] = sorted(info["resnames"])
    return residues


def _validate_prepared_receptor_subset(source_pdb: str, prepared_pdb: str) -> dict:
    source = _collect_residue_identity_map(source_pdb)
    prepared = _collect_residue_identity_map(prepared_pdb)
    source_keys = set(source)
    prepared_keys = set(prepared)
    missing = sorted(source_keys - prepared_keys)
    unexpected = sorted(prepared_keys - source_keys)
    return {
        "source_count": len(source_keys),
        "prepared_count": len(prepared_keys),
        "missing_residues": missing,
        "unexpected_residues": unexpected,
        "source_residues": source,
        "prepared_residues": prepared,
    }


def _capture_connectivity_annotations(struct_path: str, wdir) -> dict:
    struct_path = str(struct_path)
    records = []
    summary = {"link_count": 0, "ssbond_count": 0, "struct_conn_count": 0}
    try:
        if is_cif_file(struct_path):
            text = Path(struct_path).read_text(errors="replace")
            loop_pat = _re.compile(r"loop_\s*((?:_\S+\s*)+)(.*?)(?=loop_|data_|\Z)", _re.DOTALL)
            for m in loop_pat.finditer(text):
                headers = m.group(1).split()
                if not any(h.startswith("_struct_conn.") for h in headers):
                    continue
                n = len(headers)
                tokens = _re.findall(r"'[^']*'|\"[^\"]*\"|[^\s]+", m.group(2))
                for i in range(0, len(tokens) - n + 1, n):
                    row = tokens[i:i+n]
                    if len(row) < n:
                        break
                    data = {headers[j]: row[j].strip("'\"") for j in range(n)}
                    records.append({
                        "kind": "struct_conn",
                        "conn_type_id": data.get("_struct_conn.conn_type_id", ""),
                        "ptnr1_auth_asym_id": data.get("_struct_conn.ptnr1_auth_asym_id", ""),
                        "ptnr1_auth_seq_id": data.get("_struct_conn.ptnr1_auth_seq_id", ""),
                        "ptnr1_label_comp_id": data.get("_struct_conn.ptnr1_label_comp_id", ""),
                        "ptnr2_auth_asym_id": data.get("_struct_conn.ptnr2_auth_asym_id", ""),
                        "ptnr2_auth_seq_id": data.get("_struct_conn.ptnr2_auth_seq_id", ""),
                        "ptnr2_label_comp_id": data.get("_struct_conn.ptnr2_label_comp_id", ""),
                    })
                break
            summary["struct_conn_count"] = len(records)
        else:
            with open(struct_path) as f:
                for line in f:
                    rec = line[:6].strip()
                    if rec == "LINK":
                        records.append({"kind": "LINK", "raw": line.rstrip()})
                        summary["link_count"] += 1
                    elif rec == "SSBOND":
                        records.append({"kind": "SSBOND", "raw": line.rstrip()})
                        summary["ssbond_count"] += 1
    except Exception as e:
        summary["error"] = str(e)

    sidecar_path = Path(wdir) / "structure_connectivity_annotations.json"
    payload = {
        "source_path": struct_path,
        "source_format": "cif" if is_cif_file(struct_path) else "pdb",
        "summary": summary,
        "records": records,
    }
    with open(sidecar_path, "w") as f:
        json.dump(payload, f, indent=2)
    return {"path": str(sidecar_path), "summary": summary}


def _write_preparation_manifest(wdir, manifest: dict) -> str:
    path = Path(wdir) / "receptor_preparation_manifest.json"
    with open(path, "w") as f:
        json.dump(manifest, f, indent=2)
    return str(path)


def _fix_protonated_acid_sidechains(pdb_path: str) -> dict:
    """Revert Open Babel's protonated ASP/GLU forms back to ASP/GLU carboxylates."""
    renamed_ash = renamed_glh = removed_hd = removed_he = 0
    fixed_lines = []

    with open(pdb_path) as f:
        for line in f:
            if line[:6].strip() not in ("ATOM", "HETATM"):
                fixed_lines.append(line)
                continue

            resname = line[17:20].strip().upper()
            atom_name = line[12:16].strip().upper()

            if resname in {"ASH", "ASP"} and atom_name in {"HD1", "HD2"}:
                removed_hd += 1
                continue
            if resname in {"GLH", "GLU"} and atom_name in {"HE1", "HE2"}:
                removed_he += 1
                continue

            if resname == "ASH":
                line = f"{line[:17]}ASP{line[20:]}"
                renamed_ash += 1
            elif resname == "GLH":
                line = f"{line[:17]}GLU{line[20:]}"
                renamed_glh += 1

            fixed_lines.append(line)

    with open(pdb_path, "w") as f:
        f.writelines(fixed_lines)

    return {
        "renamed_ash": renamed_ash,
        "renamed_glh": renamed_glh,
        "removed_hd": removed_hd,
        "removed_he": removed_he,
    }


def _rdkit_six_patch():
    try:
        from rdkit import six  # noqa
    except ImportError:
        from io import StringIO as _SIO
        from types import ModuleType as _MT
        import rdkit as _rdkit
        _m = _MT("six")
        _m.StringIO = _SIO
        _m.PY3 = True
        _rdkit.six = _m
        sys.modules["rdkit.six"] = _m


def _strip_h_from_pdb(pdb_path: str, out_path: str) -> bool:
    import shutil
    try:
        lines = []
        with open(pdb_path) as f:
            for line in f:
                rec = line[:6].strip()
                if rec in ("ATOM", "HETATM"):
                    atom_name = line[12:16].strip()
                    element   = line[76:78].strip() if len(line) > 76 else ""
                    if element.upper() == "H" or atom_name.startswith("H"):
                        continue
                lines.append(line)
        with open(out_path, "w") as f:
            f.writelines(lines)
        return True
    except Exception:
        shutil.copy(pdb_path, out_path)
        return False


def _infer_pdb_element(line: str) -> str:
    name = line[12:16].strip().upper()
    raw = "".join(ch for ch in name if ch.isalpha()).upper()
    if len(raw) >= 2 and raw[:2] in METAL_RESNAMES:
        return raw[:2].rjust(2)
    if raw[:1] in {"C", "N", "O", "S", "P", "H", "F", "I", "B", "K"}:
        return raw[:1].rjust(2)
    return (raw[:1] or "C").rjust(2)


def _normalize_pdb_for_meeko(in_path: str, out_path: str) -> None:
    out_lines = []
    serial = 1
    with open(in_path) as f:
        for line in f:
            if line[:6].strip() not in ("ATOM", "HETATM"):
                continue
            atom_name = line[12:16].strip()
            element = (line[76:78].strip() if len(line) >= 78 else "") or _infer_pdb_element(line).strip()
            if element.upper() == "H" or atom_name.upper().startswith("H"):
                continue
            new_line = f"{line[:6]}{serial:5d}{line[11:76]:<65}{element.rjust(2)}{line[78:] if len(line) > 78 else ''}"
            out_lines.append(new_line.rstrip() + "\n")
            serial += 1
    with open(out_path, "w") as f:
        f.writelines(out_lines)


def _meeko_prepare_receptor_cmd() -> list[str] | None:
    import shutil
    exe = shutil.which("acd-mk-prepare-receptor") or shutil.which("mk_prepare_receptor.py")
    if exe:
        return [exe]
    return None


def _run_meeko_prepare_receptor(rec_input: str, rec_fh: str, rec_pdbqt: str, wdir) -> dict:
    wdir = Path(wdir)
    meeko_in = str(wdir / "receptor_atoms_for_meeko.pdb")
    _normalize_pdb_for_meeko(rec_input, meeko_in)
    cmd = _meeko_prepare_receptor_cmd()
    if cmd is None:
        return {"success": False, "error": "mk_prepare_receptor.py not found", "log": []}
    attempts = [
        ("plain", [], "✓ Receptor prepared with Meeko"),
        ("default_altloc_a", ["--default_altloc", "A"], "✓ Receptor prepared with Meeko after selecting default altloc A"),
        (
            "default_altloc_a_allow_bad_res",
            ["--default_altloc", "A", "--allow_bad_res"],
            "✓ Receptor prepared with Meeko after selecting default altloc A and allowing bad residues",
        ),
    ]
    last_out = ""
    for rung_name, extra_args, success_msg in attempts:
        full_cmd = cmd + ["--read_pdb", meeko_in, "--write_pdb", rec_fh, "-p", rec_pdbqt] + extra_args
        rc, out = run_cmd(full_cmd)
        last_out = out
        if rc == 0 and os.path.exists(rec_pdbqt) and os.path.getsize(rec_pdbqt) >= 100:
            return {
                "success": True,
                "log": [success_msg],
                "meeko_rung": rung_name,
                "meeko_args": extra_args,
                "meeko_output": out[:4000],
            }
    return {
        "success": False,
        "error": last_out[:4000],
        "log": [f"⚠ Meeko receptor prep failed; falling back to Open Babel path. {last_out[:400]}"],
        "meeko_rung": "failed",
        "meeko_args": [],
    }


def _append_rigid_pdbqt_from_pdb_lines(lines: list[str], wdir, stem: str) -> tuple[list[str], str | None]:
    tmp_pdb = Path(wdir) / f"{stem}.pdb"
    tmp_pdbqt = Path(wdir) / f"{stem}.pdbqt"
    with open(tmp_pdb, "w") as f:
        f.writelines(lines)
    rc, out = run_cmd(f'obabel "{tmp_pdb}" -O "{tmp_pdbqt}" -xr --partialcharge gasteiger')
    if rc != 0 or not tmp_pdbqt.exists() or tmp_pdbqt.stat().st_size < 20:
        return [], out[:400]
    with open(tmp_pdbqt) as f:
        pdbqt_lines = [line for line in f if line[:6].strip() in ("ATOM", "HETATM", "TER")]
    return pdbqt_lines, None


def convert_cif_to_pdb(cif_path: str, pdb_out_path: str) -> dict:
    log = []
    try:
        import gemmi
        doc    = gemmi.cif.read(cif_path)
        block  = doc.sole_block()
        st_obj = gemmi.make_structure_from_block(block)
        st_obj.setup_entities()
        st_obj.assign_label_seq_id()
        pdb_str = st_obj.make_pdb_headers() + st_obj.make_pdb_string()
        with open(pdb_out_path, "w") as f:
            f.write(pdb_str)
        if os.path.exists(pdb_out_path) and os.path.getsize(pdb_out_path) > 100:
            log.append("✓ CIF -> PDB conversion via gemmi")
            return {"success": True, "pdb_path": pdb_out_path, "log": log}
        else:
            log.append("⚠ gemmi produced empty PDB — trying OpenBabel")
    except ImportError:
        log.append("⚠ gemmi not installed — trying OpenBabel")
    except Exception as e:
        log.append(f"⚠ gemmi failed ({e}) — trying OpenBabel")

    try:
        rc, out = run_cmd(f'obabel "{cif_path}" -O "{pdb_out_path}" -ipdb')
        if not os.path.exists(pdb_out_path) or os.path.getsize(pdb_out_path) < 100:
            rc, out = run_cmd(f'obabel "{cif_path}" -O "{pdb_out_path}"')
        if os.path.exists(pdb_out_path) and os.path.getsize(pdb_out_path) > 100:
            log.append("✓ CIF -> PDB conversion via OpenBabel")
            return {"success": True, "pdb_path": pdb_out_path, "log": log}
        else:
            log.append(f"⚠ OpenBabel CIF->PDB produced empty file (exit {rc}): {out[:300]}")
    except Exception as e:
        log.append(f"⚠ OpenBabel CIF->PDB failed: {e}")

    try:
        from prody import parseMMCIF, writePDB as _writePDB
        atoms = parseMMCIF(cif_path)
        if atoms is not None and atoms.numAtoms() > 0:
            _writePDB(pdb_out_path, atoms)
            if os.path.exists(pdb_out_path) and os.path.getsize(pdb_out_path) > 100:
                log.append("✓ CIF -> PDB conversion via ProDy parseMMCIF")
                return {"success": True, "pdb_path": pdb_out_path, "log": log}
            else:
                log.append("⚠ ProDy parseMMCIF produced empty PDB")
        else:
            log.append("⚠ ProDy parseMMCIF returned None or 0 atoms")
    except ImportError:
        log.append("⚠ ProDy parseMMCIF not available")
    except Exception as e:
        log.append(f"⚠ ProDy parseMMCIF failed: {e}")

    return {
        "success": False,
        "pdb_path": pdb_out_path,
        "log": log,
        "error": "All CIF->PDB conversion methods failed.",
    }


def is_cif_file(filepath: str) -> bool:
    ext = Path(filepath).suffix.lower()
    if ext in (".cif", ".mmcif"):
        return True
    try:
        with open(filepath) as f:
            first_lines = f.read(512)
        if first_lines.strip().startswith("data_"):
            return True
    except Exception:
        pass
    return False


# ══════════════════════════════════════════════════════════════════════════════
#  TOOL AVAILABILITY CHECKS
# ══════════════════════════════════════════════════════════════════════════════

def check_obabel():
    import shutil
    if shutil.which("obabel") is None:
        return False, "obabel not found — install OpenBabel (https://openbabel.org) and ensure it is on PATH"
    _, out = run_cmd("obabel --version")
    return True, (out.splitlines()[0] if out else "ok")


# ══════════════════════════════════════════════════════════════════════════════
#  VINA BINARY
# ══════════════════════════════════════════════════════════════════════════════

def get_vina_binary(path: str = ""):
    import shutil as _shutil
    # ── Check if vina is already on PATH (common for local installs) ──────
    _vina_in_path = _shutil.which("vina") or _shutil.which("vina_1.2.7") or _shutil.which("AutoDock-Vina")
    if _vina_in_path and os.path.getsize(_vina_in_path) > 100_000:
        return _vina_in_path, f"ok (found on PATH: {_vina_in_path})"

    system  = _SYS
    machine = _platform.machine().lower()
    _BASE = "https://github.com/ccsb-scripps/AutoDock-Vina/releases/download/v1.2.7/"
    if system == "linux":
        _FNAME = "vina_1.2.7_linux_x86_64"
    elif system == "darwin":
        _FNAME = ("vina_1.2.7_mac_aarch64"
                  if machine in ("arm64", "aarch64")
                  else "vina_1.2.7_mac_x86_64")
    elif system == "windows":
        _FNAME = "vina_1.2.7_windows_x86_64.exe"
    else:
        return None, f"Unsupported platform: {system}/{machine}"
    _URL = _BASE + _FNAME
    if not path:
        path = os.path.join(tempfile.gettempdir(), _FNAME)

    def _download(url, dest):
        import requests as _rq
        r = _rq.get(url, stream=True, timeout=120, allow_redirects=True)
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1 << 20):
                f.write(chunk)

    if not os.path.exists(path) or os.path.getsize(path) < 100_000:
        try:
            _download(_URL, path)
        except Exception as e1:
            if system == "darwin" and machine in ("arm64", "aarch64"):
                _FNAME2 = "vina_1.2.7_mac_x86_64"
                path2   = os.path.join(tempfile.gettempdir(), _FNAME2)
                try:
                    _download(_BASE + _FNAME2, path2)
                    path = path2
                except Exception as e2:
                    return None, f"Download failed: {e1} / x86_64 fallback: {e2}"
            else:
                return None, f"Download failed: {e1}"

    if system != "windows":
        os.chmod(path, 0o755)
    return path, f"ok ({system}/{machine})"


# ══════════════════════════════════════════════════════════════════════════════
#  RECEPTOR PREPARATION
# ══════════════════════════════════════════════════════════════════════════════

_MIN_LIG_ATOMS = 4

BUFFER_RESNAMES = {
    "GOL", "EDO", "PEG", "PGE", "PG4", "MPD", "DMS", "DMSO", "ACT",
    "ACY", "ACE", "TRS", "MES", "EPE", "BME", "SO4", "PO4", "NO3",
    "SCN", "FMT", "IPA", "EOH", "MOH", "CL", "BR", "IOD"
}
LIPID_ADDITIVE_RESNAMES = {
    "Y01",  # cholesterol hemisuccinate
    "CHS",  # cholesteryl hemisuccinate
    "CLR",  # cholesterol
    "CHL",  # cholesterol / cholesteryl-like code in some entries
}
WATER_RESNAMES = {"HOH", "WAT", "DOD", "SOL"}


def _hetatm_key(resname, chain, resid):
    return f"{str(resname).strip().upper()}|{str(chain or '').strip() or '_'}|{int(resid)}"


def _hetatm_site_key(chain, resid):
    return f"{str(chain or '').strip() or '_'}|{int(resid)}"


def _hetatm_chain_key(resname, chain):
    return f"{str(resname).strip().upper()}|{str(chain or '').strip() or '_'}"


def _make_ligand_id(resname, chain, resid):
    return f"{str(resname).strip().upper()}_{str(chain or '').strip()}_{int(resid)}"


def _parse_ligand_id(ligand_id: str) -> tuple[str, str, str]:
    token = (ligand_id or "").strip()
    if not token:
        return "", "", ""
    parts = token.rsplit("_", 2)
    if len(parts) == 3:
        return parts[0].upper(), parts[1], parts[2]
    return token.upper(), "", ""


def _cif_full_resname_map(cif_path: str) -> dict:
    mapping = {}
    if not cif_path or not is_cif_file(cif_path) or not os.path.exists(cif_path):
        return mapping
    try:
        with open(cif_path, errors="replace") as fh:
            content = fh.read()
        loop_pat = _re.compile(
            r"loop_\s*((?:_atom_site\.\S+\s*)+)(.*?)(?=loop_|data_|\Z)",
            _re.DOTALL,
        )
        for m in loop_pat.finditer(content):
            headers = m.group(1).split()
            if "_atom_site.group_PDB" not in headers:
                continue
            def _idx(name):
                return headers.index(name) if name in headers else None
            group_idx = _idx("_atom_site.group_PDB")
            label_comp_idx = _idx("_atom_site.label_comp_id")
            auth_comp_idx = _idx("_atom_site.auth_comp_id")
            label_asym_idx = _idx("_atom_site.label_asym_id")
            auth_asym_idx = _idx("_atom_site.auth_asym_id")
            label_seq_idx = _idx("_atom_site.label_seq_id")
            auth_seq_idx = _idx("_atom_site.auth_seq_id")
            if group_idx is None or (label_comp_idx is None and auth_comp_idx is None):
                continue
            n = len(headers)
            for raw_line in m.group(2).splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or line.startswith("_"):
                    continue
                row = _re.findall(r"'[^']*'|\"[^\"]*\"|[^\s]+", line)
                if len(row) < n:
                    continue
                if len(row) > n:
                    row = row[:n]
                if row[group_idx].strip("'\"").upper() != "HETATM":
                    continue
                comp_id = ""
                for idx in (auth_comp_idx, label_comp_idx):
                    if idx is not None:
                        comp_id = row[idx].strip("'\"").upper()
                        if comp_id and comp_id not in {".", "?"}:
                            break
                if not comp_id or comp_id in WATER_RESNAMES:
                    continue
                chains = []
                for idx in (auth_asym_idx, label_asym_idx):
                    if idx is not None:
                        ch = row[idx].strip("'\"")
                        if ch and ch not in {".", "?"} and ch not in chains:
                            chains.append(ch)
                resids = []
                for idx in (auth_seq_idx, label_seq_idx):
                    if idx is not None:
                        rv = row[idx].strip("'\"")
                        if rv and rv not in {".", "?"}:
                            try:
                                rnum = str(int(float(rv)))
                            except Exception:
                                continue
                            if rnum not in resids:
                                resids.append(rnum)
                for ch in (chains or [""]):
                    for resid in resids:
                        mapping[_hetatm_key(comp_id[:3], ch, resid)] = comp_id
                        mapping[_hetatm_site_key(ch, resid)] = comp_id
                    mapping[_hetatm_chain_key(comp_id[:3], ch)] = comp_id
                if not chains:
                    mapping[_hetatm_chain_key(comp_id[:3], "")] = comp_id
            if mapping:
                break
    except Exception:
        return mapping
    return mapping


def _augment_rows_with_cif_ids(rows: list, cif_path: str) -> list:
    mapping = _cif_full_resname_map(cif_path)
    if not mapping:
        return rows
    for row in rows:
        full_resname = (
            mapping.get(_hetatm_key(row.get("resname", ""), row.get("chain", ""), row.get("resid", 0)))
            or mapping.get(_hetatm_site_key(row.get("chain", ""), row.get("resid", 0)))
            or mapping.get(_hetatm_chain_key(row.get("resname", ""), row.get("chain", "")))
        )
        if full_resname:
            row["full_resname"] = full_resname
            row["ligand_id"] = _make_ligand_id(full_resname, row.get("chain", ""), row.get("resid", 0))
    return rows


def _guess_hetatm_type(resname, n_atoms):
    rn = (resname or "").strip().upper()
    if rn in WATER_RESNAMES:
        return "water"
    if rn in METAL_RESNAMES:
        return "metal"
    if rn in HEME_RESNAMES:
        return "heme/cofactor"
    # ATP/SAM/SAH-like: grid-defining ligand, not a passive cofactor.
    # MUST precede COFACTOR_NAMES (ATP/ADP/GTP/SAM/SAH also live in that set).
    if rn in REFERENCE_LIGAND_COFACTORS:
        return "ligand"
    if rn in COFACTOR_NAMES:
        return "cofactor"
    if rn in LIPID_ADDITIVE_RESNAMES:
        return "lipid/additive"
    if rn in BUFFER_RESNAMES or n_atoms <= 3:
        return "buffer/ion"
    if n_atoms >= _MIN_LIG_ATOMS:
        return "ligand"
    return "other"


def _default_hetatm_action(type_guess, n_atoms):
    if type_guess == "water":
        return "remove"
    if type_guess == "metal":
        return "keep"
    if "cofactor" in type_guess:
        return "keep"
    if type_guess == "lipid/additive":
        return "remove"
    if type_guess == "ligand":
        return "reference" if n_atoms >= _MIN_LIG_ATOMS else "remove"
    return "remove"


def _collect_hetatm_residues(atoms) -> list:
    from prody import calcCenter
    het = atoms.select("hetatm")
    if het is None:
        return []
    rows = []
    for r in het.getHierView().iterResidues():
        rn = (r.getResname() or "").strip().upper()
        ch = (r.getChid() or "").strip()
        ri = int(r.getResnum())
        n_atoms = int(r.numAtoms())
        tg = _guess_hetatm_type(rn, n_atoms)
        sel = (f"resname {rn} and resid {ri} and chain {ch}" if ch else f"resname {rn} and resid {ri}")
        res_atoms = atoms.select(sel)
        if res_atoms is None:
            continue
        cx_, cy_, cz_ = (float(v) for v in calcCenter(res_atoms))
        rows.append({
            "key": _hetatm_key(rn, ch, ri),
            "resname": rn, "chain": ch, "resid": ri, "n_atoms": n_atoms,
            "type_guess": tg, "default_action": _default_hetatm_action(tg, n_atoms),
            "action": _default_hetatm_action(tg, n_atoms),
            "sel_str": sel, "atoms": res_atoms, "cx": cx_, "cy": cy_, "cz": cz_,
        })
    rank = {"ligand": 0, "heme/cofactor": 1, "cofactor": 2, "metal": 3, "buffer/ion": 4, "other": 5, "water": 6}
    rows.sort(key=lambda d: (rank.get(d["type_guess"], 9), -d["n_atoms"], d["resname"], d["chain"], d["resid"]))
    seen_reference = False
    for d in rows:
        if d["type_guess"] == "ligand":
            if not seen_reference:
                d["default_action"] = d["action"] = "reference"
                seen_reference = True
            else:
                d["default_action"] = d["action"] = "remove"
    return rows


def scan_hetatm_residues(raw_pdb: str) -> list:
    """
    Return HETATM residues for receptor setup UI.

    FIX A+B applied: PDB text is cleaned (ANISOU stripped, best altloc kept)
    before ProDy parses it, so partial-occupancy atoms like BR1 at occ=0.80
    are correctly detected rather than silently dropped.

    action options:
      reference = use as co-crystal reference/grid center and remove from receptor
      keep      = keep in receptor
      remove    = remove from receptor
    """
    try:
        from prody import parsePDB, confProDy
        confProDy(verbosity="none")

        # ── Fix A+B: clean before ProDy sees the file ──────────────────────
        _source_cif_path = raw_pdb if is_cif_file(raw_pdb) else ""
        _working_path = raw_pdb
        if not is_cif_file(raw_pdb):
            _working_path = _clean_pdb_file(raw_pdb)

        if is_cif_file(_working_path):
            import tempfile as _tf
            _tmp = _tf.mktemp(suffix=".pdb")
            res = convert_cif_to_pdb(_working_path, _tmp)
            if res["success"]:
                _working_path = _tmp
                # Clean the converted PDB too
                _working_path = _clean_pdb_file(_working_path)

        atoms = parsePDB(_working_path)
        if atoms is None:
            return []
        rows = _augment_rows_with_cif_ids(_collect_hetatm_residues(atoms), _source_cif_path)
        return [
            {k: d.get(k) for k in ("key", "resname", "full_resname", "ligand_id", "chain", "resid", "n_atoms", "type_guess", "default_action", "action")}
            for d in rows
        ]
    except Exception:
        return []


def _collect_removable_ligands(atoms) -> list:
    from prody import calcCenter
    # ATP/SAM/SAH-like reference ligands are intentionally NOT excluded here so
    # they can be detected as grid-defining co-crystal ligands.
    excl = (
        (EXCLUDE_IONS | GLYCAN_NAMES | COFACTOR_NAMES | HEME_RESNAMES | METAL_RESNAMES | LIPID_ADDITIVE_RESNAMES)
        - REFERENCE_LIGAND_COFACTORS
    )
    het  = atoms.select("hetatm and not water")
    _BACKBONE = {"N", "CA", "C", "O"}
    if het is None:
        return []
    results = []
    for r in het.getHierView().iterResidues():
        rn = (r.getResname() or "").strip().upper()
        if rn in excl:
            continue
        if r.numAtoms() <= _MIN_LIG_ATOMS:
            continue
        _atom_names = set(r.getNames())
        if _BACKBONE.issubset(_atom_names):
            continue
        ch = r.getChid()
        ri = r.getResnum()
        sel = (f"resname {rn} and resid {ri} and chain {ch}"
               if ch and ch.strip()
               else f"resname {rn} and resid {ri}")
        lig_atoms = atoms.select(sel)
        if lig_atoms is None or lig_atoms.numAtoms() == 0:
            continue
        cx_, cy_, cz_ = (float(v) for v in calcCenter(lig_atoms))
        results.append({
            "resname":   rn,
            "chain":     ch,
            "resid":     ri,
            "sel_str":   sel,
            "ligand_id": _make_ligand_id(rn, ch, ri),
            "n_atoms":   lig_atoms.numAtoms(),
            "atoms":     lig_atoms,
            "cx": cx_, "cy": cy_, "cz": cz_,
        })
    results.sort(key=lambda d: (-d["n_atoms"], d["chain"] != "A"))
    return results


def detect_cocrystal_ligand(raw_pdb: str) -> dict:
    from prody import parsePDB
    atoms = parsePDB(raw_pdb)
    if atoms is None:
        return {"found": False}
    cands = _augment_rows_with_cif_ids(_collect_removable_ligands(atoms), raw_pdb)
    if not cands:
        return {"found": False}
    chosen = cands[0]
    return {
        "found":     True,
        "resname":   chosen["resname"],
        "chain":     chosen["chain"],
        "resid":     chosen["resid"],
        "sel_str":   chosen["sel_str"],
        "ligand_id": chosen["ligand_id"],
        "cx": chosen["cx"], "cy": chosen["cy"], "cz": chosen["cz"],
        "n_atoms":   chosen["n_atoms"],
        "atoms":     chosen["atoms"],
    }


def scan_ligands(raw_pdb: str) -> list:
    try:
        from prody import parsePDB, confProDy
        confProDy(verbosity="none")
        _source_cif_path = raw_pdb if is_cif_file(raw_pdb) else ""
        # Fix A+B
        if not is_cif_file(raw_pdb):
            raw_pdb = _clean_pdb_file(raw_pdb)
        if is_cif_file(raw_pdb):
            import tempfile as _tf
            _tmp = _tf.mktemp(suffix=".pdb")
            res  = convert_cif_to_pdb(raw_pdb, _tmp)
            if res["success"]:
                raw_pdb = _clean_pdb_file(_tmp)
        atoms = parsePDB(raw_pdb)
        if atoms is None:
            return []
        ligs = _augment_rows_with_cif_ids(_collect_removable_ligands(atoms), _source_cif_path)
        return [
            {"resname": d["resname"], "full_resname": d.get("full_resname"), "ligand_id": d.get("ligand_id"), "chain": d["chain"],
             "resid": d["resid"], "n_atoms": d["n_atoms"]}
            for d in ligs
        ]
    except Exception:
        return []


def strip_and_convert_receptor(rec_raw: str, wdir, heme_preparation: dict | None = None) -> dict:
    wdir = Path(wdir)
    log  = []
    rec_fh    = str(wdir / "rec.pdb")
    rec_pdbqt = str(wdir / "rec.pdbqt")
    try:
        prep_meta = {
            "backend": "",
            "meeko_rung": "",
            "meeko_args": [],
            "missing_residues": [],
            "unexpected_residues": [],
            "deleted_residues": [],
        }
        metal_lines = []
        heme_lines  = []
        cofactor_lines = []
        clean_lines = []
        legacy_clean_lines = []
        heme_extra_serials = {
            int(center["oxo_serial"])
            for center in (heme_preparation or {}).get("centers", [])
            if center.get("oxo_serial") is not None
        }
        with open(rec_raw) as f:
            for line in f:
                field = line[:6].strip()
                rn    = line[17:20].strip().upper()
                try:
                    serial = int(line[6:11]) if field in ("ATOM", "HETATM") else -1
                except ValueError:
                    serial = -1
                if field in ("ATOM", "HETATM") and rn in METAL_RESNAMES:
                    metal_lines.append(line)
                elif field in ("ATOM", "HETATM") and (rn in HEME_RESNAMES or serial in heme_extra_serials):
                    heme_lines.append(line)
                elif field in ("ATOM", "HETATM") and rn in COFACTOR_NAMES:
                    cofactor_lines.append(line)
                    legacy_clean_lines.append(line)
                else:
                    clean_lines.append(line)
                    legacy_clean_lines.append(line)

        rec_nometal = str(wdir / "receptor_atoms_nometal.pdb")
        with open(rec_nometal, "w") as f:
            f.writelines(clean_lines)

        rec_legacy_input = str(wdir / "receptor_atoms_legacy_input.pdb")
        with open(rec_legacy_input, "w") as f:
            f.writelines(legacy_clean_lines)

        if metal_lines:
            names = ", ".join(sorted({l[17:20].strip() for l in metal_lines}))
            log.append(f"⚠ Stripped {len(metal_lines)} metal atom(s) before OpenBabel: {names}")
        if heme_lines:
            hnames = ", ".join(sorted({l[17:20].strip() for l in heme_lines}))
            log.append(f"⚠ Stripped {len(heme_lines)} heme atom(s) before OpenBabel: {hnames}")
        if cofactor_lines:
            cnames = ", ".join(sorted({l[17:20].strip() for l in cofactor_lines}))
            log.append(f"⚠ Stripped {len(cofactor_lines)} cofactor atom(s) before Meeko: {cnames}")
        heme_prepared = {
            "display_lines": [],
            "pdbqt_lines": [],
            "display_method": "raw",
            "pdbqt_method": "manual",
        }
        for heme_index, center in enumerate((heme_preparation or {}).get("centers", []), 1):
            center_lines = []
            for line in heme_lines:
                try:
                    line_serial = int(line[6:11])
                    line_resid = int(line[22:26])
                except ValueError:
                    continue
                same_residue = (
                    line[17:20].strip().upper() == center["resname"]
                    and (line[21].strip() or "_") == center["chain"]
                    and line_resid == center["resid"]
                )
                if same_residue or line_serial == center.get("oxo_serial"):
                    center_lines.append(line)
            parameter_block = heme_preparation["parameters"][center["selected_state"]]
            expected_hydrogens = len(parameter_block["heme_hydrogen_parents"])
            present_hydrogens = sum(
                1 for line in center_lines
                if line[12:16].strip().upper().lstrip("0123456789").startswith("H")
                or (len(line) >= 78 and line[76:78].strip().upper() == "H")
            )
            if present_hydrogens == expected_hydrogens:
                prepared_center = {
                    "display_lines": center_lines, "pdbqt_lines": [],
                    "display_method": "input-complete", "pdbqt_method": "manual",
                }
                log.append(
                    f"✓ Heme center {heme_index} already contains the complete "
                    f"JSON-defined hydrogen topology ({present_hydrogens}); preserved unchanged"
                )
            else:
                center_dir = Path(wdir) / f"heme_center_{heme_index}"
                center_dir.mkdir(exist_ok=True)
                prepared_center = _prepare_heme_block(center_lines, center_dir, log)
            heme_prepared["display_lines"].extend(prepared_center["display_lines"])
            heme_prepared["pdbqt_lines"].extend(prepared_center["pdbqt_lines"])
            heme_prepared["display_method"] = prepared_center["display_method"]
            heme_prepared["pdbqt_method"] = prepared_center["pdbqt_method"]

        meeko_res = _run_meeko_prepare_receptor(rec_nometal, rec_fh, rec_pdbqt, wdir)
        log.extend(meeko_res["log"])
        prep_meta["meeko_rung"] = meeko_res.get("meeko_rung", "")
        prep_meta["meeko_args"] = meeko_res.get("meeko_args", [])
        if meeko_res["success"]:
            residue_check = _validate_prepared_receptor_subset(rec_nometal, rec_fh)
            prep_meta["missing_residues"] = residue_check["missing_residues"]
            prep_meta["unexpected_residues"] = residue_check["unexpected_residues"]
            if residue_check["unexpected_residues"]:
                log.append(
                    "⚠ Meeko produced unexpected residue identities: "
                    + ", ".join(residue_check["unexpected_residues"][:10])
                )
                meeko_res["success"] = False
            elif residue_check["missing_residues"]:
                if meeko_res.get("meeko_rung") == "default_altloc_a_allow_bad_res":
                    prep_meta["deleted_residues"] = residue_check["missing_residues"]
                    log.append(
                        "ℹ Meeko deleted residue(s) under allow_bad_res: "
                        + ", ".join(residue_check["missing_residues"][:10])
                    )
                else:
                    log.append(
                        "⚠ Meeko dropped residue(s) without allow_bad_res; using Open Babel fallback: "
                        + ", ".join(residue_check["missing_residues"][:10])
                    )
                    meeko_res["success"] = False
        if not meeko_res["success"]:
            rc1, out1 = run_cmd(f'obabel "{rec_legacy_input}" -O "{rec_fh}" -h')
            if not os.path.exists(rec_fh) or os.path.getsize(rec_fh) < 100:
                raise ValueError(f"OpenBabel H-addition produced empty file (exit {rc1}). Output: {out1[:400]}")
            log.append("✓ Hydrogens added")
            acid_fix = _fix_protonated_acid_sidechains(rec_fh)
            if any(acid_fix.values()):
                log.append(
                    "✓ Restored deprotonated acidic side chains after H-addition "
                    f"(ASH→ASP lines: {acid_fix['renamed_ash']}, GLH→GLU lines: {acid_fix['renamed_glh']}, "
                    f"removed acid H: Asp {acid_fix['removed_hd']}, Glu {acid_fix['removed_he']})"
                )

            rc2, out2 = run_cmd(f'obabel "{rec_fh}" -O "{rec_pdbqt}" -xr --partialcharge gasteiger')
            if not os.path.exists(rec_pdbqt) or os.path.getsize(rec_pdbqt) < 100:
                raise ValueError(f"PDBQT conversion produced empty file (exit {rc2}). Output: {out2[:400]}")
            log.append("✓ PDBQT conversion complete")
            used_meeko = False
            prep_meta["backend"] = "openbabel_fallback"
            fallback_check = _validate_prepared_receptor_subset(rec_legacy_input, rec_fh)
            prep_meta["missing_residues"] = fallback_check["missing_residues"]
            prep_meta["unexpected_residues"] = fallback_check["unexpected_residues"]
        else:
            used_meeko = True
            prep_meta["backend"] = "meeko"

        # Open Babel 3.2 may emit COMPND/AUTHOR headers that Vina 1.2.7
        # rejects as unknown receptor tags. Keep only rigid-receptor records.
        with open(rec_pdbqt) as f:
            pdbqt_lines = [
                line for line in f
                if line[:6].strip() in ("ATOM", "HETATM", "TER", "END")
            ]
        with open(rec_pdbqt, "w") as f:
            f.writelines(pdbqt_lines)
        log.append("✓ Removed non-PDBQT Open Babel headers (Vina-safe)")

        # ── Re-add metals + heme to rec.pdb for display / PoseView ──────────
        # This is done AFTER PDBQT generation so the docking PDBQT still uses
        # the dedicated re-injection logic below (with proper AD4 atom types).
        # We ALWAYS attempt this, regardless of whether PDBQT re-injection works.
        if metal_lines or heme_lines or (used_meeko and cofactor_lines):
            try:
                rec_lines = open(rec_fh).readlines()
                # Remove any trailing END record so we can append cleanly
                rec_lines = [l for l in rec_lines if l.strip() != "END"]
                rec_lines.extend(metal_lines)
                rec_lines.extend(heme_prepared["display_lines"] or heme_lines)
                if used_meeko:
                    grouped = {}
                    order = []
                    for line in cofactor_lines:
                        key = (line[17:20], line[21], line[22:26], line[26] if len(line) > 26 else " ")
                        if key not in grouped:
                            grouped[key] = []
                            order.append(key)
                        grouped[key].append(line)
                    for idx, key in enumerate(order, 1):
                        prepared = _prepare_isolated_residue_block(grouped[key], wdir, f"cofactor_{idx}", log, f"Cofactor {key[0].strip()}")
                        rec_lines.extend(prepared["display_lines"] or grouped[key])
                rec_lines.append("END\n")
                with open(rec_fh, "w") as f:
                    f.writelines(rec_lines)
                log.append(
                    f"✓ Re-added {len(metal_lines)} metal + {len(heme_lines)} heme + "
                    f"{len(cofactor_lines) if used_meeko else 0} cofactor "
                    f"atom(s) to rec.pdb for display"
                )
            except Exception as e:
                log.append(f"⚠ Could not re-add metals/heme to rec.pdb: {e}")

        # ── Re-inject metals + heme into PDBQT with AD4 atom types ──────────
        if metal_lines or heme_lines or (used_meeko and cofactor_lines):
            pdbqt_lines = open(rec_pdbqt).readlines()
            pdbqt_lines = [l for l in pdbqt_lines if l.strip() != "END"]

            injected        = 0
            skipped_exotic  = 0
            heme_injected   = 0
            cofactor_injected = 0

            _no_reinject = {
                "HO", "LA", "CE", "PR", "ND", "PM", "SM", "EU",
                "GD", "TB", "DY", "ER", "TM", "YB", "LU",
            }

            # Metal atoms
            for ml in metal_lines:
                try:
                    resname = ml[17:20].strip().upper()
                    if resname in _no_reinject:
                        skipped_exotic += 1
                        continue
                    serial  = int(ml[6:11])
                    name    = ml[12:16].strip()
                    chain   = ml[21] if len(ml) > 21 else "A"
                    resid   = int(ml[22:26])
                    x       = float(ml[30:38])
                    y       = float(ml[38:46])
                    z       = float(ml[46:54])
                    charge  = METAL_CHARGES.get(resname, 0.0)
                    atype   = resname.capitalize()
                    pdbqt_lines.append(
                        f"HETATM{serial:5d} {name:<4s} {resname:<3s} "
                        f"{chain}{resid:4d}    "
                        f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00"
                        f"    {charge:+.3f} {atype}\n"
                    )
                    injected += 1
                except Exception as e:
                    log.append(f"⚠ Could not re-inject metal line: {e}")

            if heme_prepared["pdbqt_lines"]:
                pdbqt_lines.extend(heme_prepared["pdbqt_lines"])
                heme_injected = len(heme_prepared["pdbqt_lines"])
            else:
                # Last-resort fallback if isolated Heme PDBQT preparation fails:
                # preserve any hydrogens present in the hydrogenated Heme PDB block.
                fallback_heme_lines = heme_prepared["display_lines"] or heme_lines
                for hl in fallback_heme_lines:
                    try:
                        serial  = int(hl[6:11])
                        name    = hl[12:16].strip()
                        resname = hl[17:20].strip().upper()
                        chain   = hl[21] if len(hl) > 21 else "A"
                        resid   = int(hl[22:26])
                        x       = float(hl[30:38])
                        y       = float(hl[38:46])
                        z       = float(hl[46:54])
                        element = (hl[76:78].strip() if len(hl) > 77 else "") or _atom_name_to_element(hl[12:16], hl[76:78] if len(hl) > 77 else "")
                        if element.upper() == "H" or name.upper().startswith("H"):
                            atype  = "HD"
                            charge = 0.0
                        elif name.upper() in ("FE", "FE2", "FE3"):
                            atype  = "Fe"
                            charge = +3.0
                        elif element.upper() == "O" or name.upper().startswith("O"):
                            atype  = "OA"
                            charge = 0.0
                        elif name.upper().startswith("N"):
                            atype  = "NA"
                            charge = -0.3
                        elif name.upper().startswith("C"):
                            atype  = "A"   # aromatic carbon
                            charge = 0.0
                        else:
                            atype  = "C"
                            charge = 0.0
                        pdbqt_lines.append(
                            f"HETATM{serial:5d} {name:<4s} {resname:<3s} "
                            f"{chain}{resid:4d}    "
                            f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00"
                            f"    {charge:+.3f} {atype}\n"
                        )
                        heme_injected += 1
                    except Exception as e:
                        log.append(f"⚠ Could not re-inject heme line: {e}")
                if heme_injected:
                    log.append("⚠ Heme PDBQT used legacy fallback atom typing (no isolated prepared PDBQT)")

            if used_meeko and cofactor_lines:
                grouped = {}
                order = []
                for line in cofactor_lines:
                    key = (line[17:20], line[21], line[22:26], line[26] if len(line) > 26 else " ")
                    if key not in grouped:
                        grouped[key] = []
                        order.append(key)
                    grouped[key].append(line)
                for idx, key in enumerate(order, 1):
                    prepared = _prepare_isolated_residue_block(grouped[key], wdir, f"cofactor_{idx}", log, f"Cofactor {key[0].strip()}")
                    extra_lines = prepared["pdbqt_lines"]
                    if extra_lines:
                        pdbqt_lines.extend(extra_lines)
                        cofactor_injected += len(extra_lines)
                    else:
                        extra_lines, err = _append_rigid_pdbqt_from_pdb_lines(grouped[key], wdir, f"cofactor_{idx}")
                        if extra_lines:
                            pdbqt_lines.extend(extra_lines)
                            cofactor_injected += len(extra_lines)
                        elif err:
                            log.append(f"⚠ Could not re-inject cofactor {key[0].strip()} {key[1]}:{key[2].strip()}: {err}")

            pdbqt_lines.append("END\n")
            with open(rec_pdbqt, "w") as f:
                f.writelines(pdbqt_lines)

            if injected:
                log.append(f"✅ Re-injected {injected} metal atom(s) into PDBQT")
            if heme_injected:
                log.append(f"✅ Re-injected {heme_injected} heme atom(s) into PDBQT with AD4 atom types")
            if cofactor_injected:
                log.append(f"✅ Re-injected {cofactor_injected} cofactor PDBQT line(s)")
            if skipped_exotic:
                log.append(
                    f"ℹ Skipped re-injection of {skipped_exotic} Ho/lanthanide ion(s) into "
                    f"docking PDBQT; kept only in rec.pdb for display"
                )

        if heme_preparation and heme_preparation.get("centers"):
            charge_validation = apply_and_validate_pdbqt(rec_pdbqt, heme_preparation)
            log.extend(charge_validation["log"])
            prep_meta["heme_centers"] = charge_validation["centers"]

        log.append("✓ Receptor PDBQT ready")
        return {
            "success": True,
            "rec_fh": rec_fh,
            "rec_pdbqt": rec_pdbqt,
            "log": log,
            "prep_meta": prep_meta,
        }

    except Exception as e:
        log.append(f"ERROR: {e}")
        return {"success": False, "error": str(e), "log": log}


def write_box_pdb(filename: str, cx, cy, cz, sx, sy, sz):
    hx, hy, hz = sx / 2, sy / 2, sz / 2
    corners = [
        (cx + dx, cy + dy, cz + dz)
        for dx in (-hx, hx)
        for dy in (-hy, hy)
        for dz in (-hz, hz)
    ]
    with open(filename, "w") as f:
        for i, (x, y, z) in enumerate(corners, 1):
            f.write(
                f"HETATM{i:5d}  C   BOX A   1    "
                f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00           C\n"
            )
        f.write(
            "CONECT    1    2    3    5\nCONECT    2    1    4    6\n"
            "CONECT    3    1    4    7\nCONECT    4    2    3    8\n"
            "CONECT    5    1    6    7\nCONECT    6    2    5    8\n"
            "CONECT    7    3    5    8\nCONECT    8    4    6    7\n"
        )


def write_vina_config(filename: str, cx, cy, cz, sx, sy, sz):
    with open(filename, "w") as f:
        f.write(
            f"center_x = {cx:.4f}\n"
            f"center_y = {cy:.4f}\n"
            f"center_z = {cz:.4f}\n"
            f"size_x = {sx}\n"
            f"size_y = {sy}\n"
            f"size_z = {sz}\n"
        )


def calculate_blind_box(raw_pdb: str, padding: float = 4.0) -> tuple:
    """Return the whole-protein center and full box lengths used by ACD-online."""
    import numpy as np
    from prody import parsePDB

    atoms = parsePDB(raw_pdb)
    if atoms is None:
        raise ValueError("ProDy parsePDB returned None while calculating blind box")
    protein = atoms.select("protein")
    box_atoms = protein if protein is not None else atoms
    coords = box_atoms.getCoords()
    if coords is None or len(coords) == 0:
        raise ValueError("No coordinates available for blind docking box")
    lower = np.asarray(coords).min(axis=0)
    upper = np.asarray(coords).max(axis=0)
    center = tuple(float(v) for v in ((lower + upper) / 2.0))
    size = tuple(int(round(float(v))) for v in ((upper - lower) + 2.0 * float(padding)))
    return center, size


def prepare_receptor(
    raw_pdb: str,
    wdir,
    center_mode: str = "auto",
    manual_xyz: tuple = (0.0, 0.0, 0.0),
    prody_sel: str = "",
    box_size: tuple = (18, 18, 18),
    preferred_ligand: str = "",
    hetatm_policy: dict | None = None,
    reference_hetatm_key: str = "",
    heme_states: dict | None = None,
) -> dict:
    from prody import parsePDB, calcCenter, writePDB
    wdir = Path(wdir)
    log  = []
    sx, sy, sz = box_size
    try:
        source_input_path = raw_pdb
        connectivity_meta = _capture_connectivity_annotations(source_input_path, wdir)
        log.append("✓ Captured source connectivity annotations")
        _source_cif_path = raw_pdb if is_cif_file(raw_pdb) else ""
        if is_cif_file(raw_pdb):
            log.append("📄 Detected mmCIF format — converting to PDB…")
            converted_pdb = str(wdir / "converted_from_cif.pdb")
            cif_result = convert_cif_to_pdb(raw_pdb, converted_pdb)
            log.extend(cif_result["log"])
            if not cif_result["success"]:
                raise ValueError(f"CIF -> PDB conversion failed: {cif_result.get('error', 'unknown')}")
            raw_pdb = converted_pdb

        # Inspect the complete structure before ligand/HETATM filtering so a
        # standalone ferryl oxygen cannot be mistaken for a removable ligand.
        heme_preparation = prepare_heme_centers(raw_pdb, heme_states, remove_oxo_h=False)

        atoms = parsePDB(raw_pdb)
        if atoms is None:
            raise ValueError("ProDy parsePDB returned None")
        log.append(f"✓ Parsed {atoms.numAtoms()} atoms")

        ligand_pdb_path     = None
        cocrystal_ligand_id = ""
        cx = cy = cz = 0.0

        # HETATM-aware receptor setup. The UI can pass per-residue actions:
        #   reference = use as grid-center reference and remove from receptor
        #   keep      = keep in receptor
        #   remove    = strip from receptor
        _hetatm_rows = _augment_rows_with_cif_ids(_collect_hetatm_residues(atoms), _source_cif_path)
        _policy = {str(k): str(v).lower() for k, v in (hetatm_policy or {}).items()}
        for _r in _hetatm_rows:
            _r["action"] = _policy.get(_r["key"], _r.get("default_action", "remove")).lower()
        _oxo_residues = {
            (c["oxo_resname"], c["oxo_chain"], c["oxo_resid"])
            for c in heme_preparation["centers"]
            if c.get("oxo_serial") is not None
        }
        for _r in _hetatm_rows:
            _row_residue = (_r["resname"].upper(), _r["chain"] or "_", int(_r["resid"]))
            if _row_residue in _oxo_residues:
                _r["action"] = "keep"

        _reference = None
        if reference_hetatm_key:
            _reference = next((d for d in _hetatm_rows if d["key"] == reference_hetatm_key), None)
        if _reference is None:
            _reference = next((d for d in _hetatm_rows if d.get("action") == "reference"), None)

        # Backward compatibility: if no HETATM policy is provided, old preferred_ligand behavior still works.
        _all_ligs = _collect_removable_ligands(atoms)
        _all_ligs = [
            d for d in _all_ligs
            if (d["resname"].upper(), d["chain"] or "_", int(d["resid"])) not in _oxo_residues
        ]
        _primary = None
        if _reference is not None:
            _ref_name = _reference.get("full_resname") or _reference["resname"]
            _primary = {
                "resname": _reference["resname"], "full_resname": _ref_name, "chain": _reference["chain"],
                "resid": _reference["resid"], "sel_str": _reference["sel_str"],
                "ligand_id": _reference.get("ligand_id") or _make_ligand_id(_ref_name, _reference["chain"], _reference["resid"]),
                "n_atoms": _reference["n_atoms"], "atoms": _reference["atoms"],
                "cx": _reference["cx"], "cy": _reference["cy"], "cz": _reference["cz"],
            }
        elif not hetatm_policy and _all_ligs:
            _all_ligs = _augment_rows_with_cif_ids(_all_ligs, _source_cif_path)
            if preferred_ligand:
                _pref = preferred_ligand.strip().upper()
                _primary = next((d for d in _all_ligs if d["resname"].upper() == _pref or (d.get("full_resname") or "").upper() == _pref), None)
                if _primary is None:
                    _fallback_name = _all_ligs[0].get("full_resname") or _all_ligs[0]["resname"]
                    log.append(f"⚠ Preferred ligand '{preferred_ligand}' not found — using largest ({_fallback_name})")
            if _primary is None:
                _primary = _all_ligs[0]

        if _primary is not None:
            rn  = _primary.get("full_resname") or _primary["resname"]
            ch  = _primary["chain"]
            ri  = _primary["resid"]
            cocrystal_ligand_id = _primary.get("ligand_id") or _make_ligand_id(rn, ch, ri)
            ligand_pdb_path     = str(wdir / "LIG.pdb")
            writePDB(ligand_pdb_path, _primary["atoms"])
            log.append(f"✓ Reference HETATM for grid: {rn} chain '{ch}' resnum {ri} ({_primary['n_atoms']} atoms)")

        if center_mode == "auto":
            if _primary is not None:
                cx, cy, cz = _primary["cx"], _primary["cy"], _primary["cz"]
                log.append(f"📍 Auto center: ({cx:.3f}, {cy:.3f}, {cz:.3f})")
                log.append(f"🔑 PoseView2 ligand ID: {cocrystal_ligand_id}")
            else:
                log.append("⚠ No co-crystal ligand found")
        elif center_mode == "manual":
            cx, cy, cz = (float(v) for v in manual_xyz)
            log.append(f"🛠 Manual center: ({cx:.3f}, {cy:.3f}, {cz:.3f})")
            if _primary is not None:
                log.append(f"🔑 PoseView2 ligand ID: {cocrystal_ligand_id}")
        elif center_mode == "selection":
            if not prody_sel.strip():
                raise ValueError("ProDy selection string is empty.")
            ref_atoms = atoms.select(prody_sel.strip())
            if ref_atoms is None or ref_atoms.numAtoms() == 0:
                raise ValueError(f"ProDy selection '{prody_sel}' matched 0 atoms.")
            cx, cy, cz = (float(v) for v in calcCenter(ref_atoms))
            log.append(f"🔬 ProDy selection: '{prody_sel}' -> {ref_atoms.numAtoms()} atoms")
            log.append(f"📍 Center: ({cx:.3f}, {cy:.3f}, {cz:.3f})")
            if _primary is not None:
                log.append(f"🔑 PoseView2 ligand ID: {cocrystal_ligand_id}")

        if hetatm_policy:
            _remove_rows = [d for d in _hetatm_rows if d.get("action") in {"remove", "reference"}]
            if _remove_rows:
                _excl_expr = " or ".join(f"({d['sel_str']})" for d in _remove_rows)
                sel_str = f"not ({_excl_expr})"
            else:
                sel_str = "all"
            _kept = [d for d in _hetatm_rows if d.get("action") == "keep"]
            log.append(
                f"🧾 HETATM policy: keep {len(_kept)}, remove/reference {len(_remove_rows)}"
            )
            if _remove_rows:
                log.append(
                    "🧹 Removed/reference HETATM: "
                    + ", ".join(f"{d['resname']}:{d['chain'] or '-'}:{d['resid']}[{d.get('action')}]" for d in _remove_rows[:25])
                    + (" …" if len(_remove_rows) > 25 else "")
                )
        elif _all_ligs:
            _excl_expr = " or ".join(f"({d['sel_str']})" for d in _all_ligs)
            sel_str = f"not ({_excl_expr}) and not water"
            if len(_all_ligs) > 1:
                log.append(
                    f"🧹 Removing {len(_all_ligs)} ligand(s) from receptor: "
                    + ", ".join(f"{d['resname']}({d['n_atoms']}at)" for d in _all_ligs)
                )
        else:
            sel_str = "not water"

        rec_sel = atoms.select(sel_str)
        if rec_sel is None or rec_sel.numAtoms() == 0:
            raise ValueError("Receptor selection returned no atoms")

        rec_raw_path = str(wdir / "receptor_atoms.pdb")
        writePDB(rec_raw_path, rec_sel)
        # ProDy may renumber atoms. Refresh geometric identities on the written
        # receptor before oxo-H removal and final PDBQT charge mapping.
        heme_preparation = prepare_heme_centers(rec_raw_path, heme_states)
        log.extend(heme_preparation["log"])
        log.append(f"✓ Receptor: {rec_sel.numAtoms()} atoms")

        try:
            _rec_lines   = open(rec_raw_path).readlines()
            _coord_lines = [l for l in _rec_lines if l[:6].strip() in ("ATOM", "HETATM")]
            _all_blank   = all(
                (l[21] == " " if len(l) > 21 else True)
                for l in _coord_lines
            )
            if _all_blank and _coord_lines:
                _fixed = []
                for l in _rec_lines:
                    if l[:6].strip() in ("ATOM", "HETATM") and len(l) > 21:
                        l = l[:21] + "A" + l[22:]
                    _fixed.append(l)
                with open(rec_raw_path, "w") as _f:
                    _f.writelines(_fixed)
                log.append("✓ Assigned chain A to all blank-chain atoms")
        except Exception as _ce:
            log.append(f"⚠ Chain-fix skipped: {_ce}")

        conv = strip_and_convert_receptor(rec_raw_path, wdir, heme_preparation)
        log.extend(conv["log"])
        if not conv["success"]:
            raise ValueError(conv["error"])
        prep_meta = conv.get("prep_meta", {})
        log.append(
            f"ℹ Receptor preparation backend: {prep_meta.get('backend', 'unknown')}"
            + (f" [{prep_meta.get('meeko_rung')}]" if prep_meta.get("meeko_rung") else "")
        )
        if prep_meta.get("deleted_residues"):
            log.append("ℹ Deleted residue manifest: " + ", ".join(prep_meta["deleted_residues"][:10]))
        if prep_meta.get("unexpected_residues"):
            raise ValueError(
                "Prepared receptor contains unexpected residue identities: "
                + ", ".join(prep_meta["unexpected_residues"][:10])
            )

        box_pdb  = str(wdir / "rec.box.pdb")
        cfg_path = str(wdir / "rec.box.txt")
        write_box_pdb(box_pdb, cx, cy, cz, sx, sy, sz)
        write_vina_config(cfg_path, cx, cy, cz, sx, sy, sz)
        log.append("✓ Box + config written")
        manifest = {
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "source_input_path": str(source_input_path),
            "normalized_structure_path": str(raw_pdb),
            "connectivity_sidecar_path": connectivity_meta.get("path"),
            "connectivity_summary": connectivity_meta.get("summary", {}),
            "receptor_preparation": prep_meta,
            "box": {"cx": cx, "cy": cy, "cz": cz, "sx": sx, "sy": sy, "sz": sz},
            "reference_ligand": {
                "ligand_pdb_path": ligand_pdb_path,
                "cocrystal_ligand_id": cocrystal_ligand_id,
            },
        }
        manifest_path = _write_preparation_manifest(wdir, manifest)
        log.append("✓ Receptor preparation manifest written")

        return {
            "success":             True,
            "rec_fh":              conv["rec_fh"],
            "rec_pdbqt":           conv["rec_pdbqt"],
            "box_pdb":             box_pdb,
            "config_txt":          cfg_path,
            "cx": cx, "cy": cy, "cz": cz,
            "sx": sx, "sy": sy, "sz": sz,
            "ligand_pdb_path":     ligand_pdb_path,
            "cocrystal_ligand_id": cocrystal_ligand_id,
            "n_atoms":             rec_sel.numAtoms(),
            "all_ligands":         [
                {"resname": d["resname"], "full_resname": d.get("full_resname"), "ligand_id": d.get("ligand_id"), "chain": d["chain"],
                 "resid": d["resid"], "n_atoms": d["n_atoms"]}
                for d in _all_ligs
            ],
            "hetatm_table":        [
                {k: d.get(k) for k in ("key", "resname", "full_resname", "ligand_id", "chain", "resid", "n_atoms", "type_guess", "action")}
                for d in _hetatm_rows
            ],
            "preparation_manifest": manifest_path,
            "prep_meta":            prep_meta,
            "log": log,
        }
    except Exception as e:
        log.append(f"ERROR: {e}")
        return {"success": False, "error": str(e), "log": log}


# ══════════════════════════════════════════════════════════════════════════════
#  PKANET CLOUD — ionizable site table + HH scoring helpers
#  Ported from pKaNET Cloud notebook (Hengphasatporn et al. 2026)
#  Full replacement with all 12 fixes — see file header for details.
# ══════════════════════════════════════════════════════════════════════════════

# Weights matching real pKaNET Cloud notebook
_W_AROM_RING_LOST         = 8.0
_W_PHENOL_TO_KETO_FLIP    = 6.0
_W_PYROGALLOL_TRIKETO     = 6.0
_W_CATECHOL_DIKETO        = 4.0
_W_PHENOL_PRESERVED_BONUS = 0.5
_TAUTOMER_PLAUSIBILITY_CUTOFF = 3.0
_AMBIGUITY_SCORE_GAP          = 0.5

# ── Chromone system detection ─────────────────────────────────────────────────

def _detect_chromone_system(mol):
    """Return atom indices of the fused chromen-4-one system."""
    from rdkit import Chem
    ring_info = mol.GetRingInfo()
    rings = [set(r) for r in ring_info.AtomRings() if len(r) == 6]
    if not rings:
        return set()

    def _has_exo_carbonyl(atom_idx):
        atom = mol.GetAtomWithIdx(atom_idx)
        if atom.GetSymbol() != "C":
            return False
        for bond in atom.GetBonds():
            other = bond.GetOtherAtom(atom)
            if other.GetSymbol() != "O" or other.IsInRing():
                continue
            bo = bond.GetBondTypeAsDouble()
            if bo == 2.0:
                return True
            if bo == 1.5 and other.GetTotalNumHs() == 0 and other.GetDegree() == 1:
                return True
        return False

    pyrone_rings = [
        ring for ring in rings
        if sum(1 for i in ring if mol.GetAtomWithIdx(i).GetSymbol() == "O") == 1
        and any(_has_exo_carbonyl(i) for i in ring)
    ]
    if not pyrone_rings:
        return set()

    system: set = set()
    for py in pyrone_rings:
        system.update(py)
        for other in rings:
            if other is not py and len(py & other) >= 2:
                system.update(other)
    return system


# ── FIX 1-4: Flavonoid A-ring phenol detection ───────────────────────────────

def _find_flavone_A_ring_phenols(mol):
    """
    Position-aware pKa assignment for chromone A-ring phenolic OHs.

    Classification (Fixes 1-4):
      carbonyl_direct=True   -> flavone_3OH_flavonol   pKa  7.0  (FIX 3)
      carbonyl_direct=False  -> flavone_5OH_chelated   pKa 11.0  (FIX 1)
      ortho_to_ring_O        -> flavone_8OH            pKa  8.5
      n_ortho_phenols >= 2   -> flavone_6OH_pyrogallol pKa  8.5  (FIX 4a)
      n_ortho_phenols == 1   -> flavone_catechol_pair  pKa  7.0  (FIX 4b)
      else                   -> flavone_isolated       pKa  7.0  (FIX 2)
    """
    chromone_atoms = _detect_chromone_system(mol)
    if not chromone_atoms:
        return []

    ring_carbonyl_idx = None
    ring_oxygen_idx   = None

    for idx in chromone_atoms:
        atom = mol.GetAtomWithIdx(idx)
        if atom.GetSymbol() == "C":
            for bond in atom.GetBonds():
                other = bond.GetOtherAtom(atom)
                if (other.GetSymbol() == "O"
                        and not other.IsInRing()
                        and bond.GetBondTypeAsDouble() in (2.0, 1.5)
                        and other.GetTotalNumHs() == 0
                        and other.GetDegree() == 1):
                    ring_carbonyl_idx = idx
                    break
        elif atom.GetSymbol() == "O" and atom.IsInRing():
            ring_oxygen_idx = idx

    def _chromone_nbrs(idx):
        return [n.GetIdx() for n in mol.GetAtomWithIdx(idx).GetNeighbors()
                if n.GetIdx() in chromone_atoms]

    def _has_phenolic_OH(c_idx):
        for bond in mol.GetAtomWithIdx(c_idx).GetBonds():
            other = bond.GetOtherAtom(mol.GetAtomWithIdx(c_idx))
            if (other.GetSymbol() == "O"
                    and other.GetTotalNumHs() >= 1
                    and other.GetDegree() == 1
                    and bond.GetBondTypeAsDouble() == 1.0
                    and not other.IsInRing()):
                return True
        return False

    candidates = []
    for atom in mol.GetAtoms():
        c_idx = atom.GetIdx()
        if c_idx not in chromone_atoms:
            continue
        if atom.GetSymbol() != "C" or not atom.GetIsAromatic():
            continue
        if c_idx == ring_carbonyl_idx:
            continue
        for bond in atom.GetBonds():
            other = bond.GetOtherAtom(atom)
            if (other.GetSymbol() == "O"
                    and other.GetTotalNumHs() >= 1
                    and other.GetDegree() == 1
                    and bond.GetBondTypeAsDouble() == 1.0
                    and not other.IsInRing()):
                candidates.append((c_idx, other.GetIdx()))
                break

    sites = []
    for c_idx, o_idx in candidates:
        chromone_nbrs = _chromone_nbrs(c_idx)
        ortho_carbons = [n for n in chromone_nbrs
                         if mol.GetAtomWithIdx(n).GetSymbol() == "C"]

        # FIX 1 + FIX 3: direct bond vs peri path to C4=O
        ortho_to_carbonyl = False
        carbonyl_direct   = False
        if ring_carbonyl_idx is not None:
            if ring_carbonyl_idx in chromone_nbrs:
                # Direct bond C3-C4=O -> flavonol 3-OH (FIX 3)
                ortho_to_carbonyl = True
                carbonyl_direct   = True
            else:
                # Peri path C5-C4a-C4=O -> flavone 5-OH (FIX 1)
                for nb in chromone_nbrs:
                    if any(n.GetIdx() == ring_carbonyl_idx
                           for n in mol.GetAtomWithIdx(nb).GetNeighbors()):
                        ortho_to_carbonyl = True
                        carbonyl_direct   = False
                        break

        ortho_to_ring_O = (ring_oxygen_idx is not None
                           and ring_oxygen_idx in chromone_nbrs)
        n_ortho_phenols = sum(1 for n in ortho_carbons if _has_phenolic_OH(n))

        if ortho_to_carbonyl:
            if carbonyl_direct:
                label, pka = "flavone_3OH_flavonol", 7.0    # FIX 3 (quercetin 3-OH actual pKa ~7.0)
            else:
                label, pka = "flavone_5OH_chelated", 11.0   # FIX 1
        elif ortho_to_ring_O:
            label, pka = "flavone_8OH_ortho_pyranO", 8.5
        elif n_ortho_phenols >= 2:
            label, pka = "flavone_6OH_pyrogallol_center", 8.5  # FIX 4a
        elif n_ortho_phenols == 1:
            label, pka = "flavone_phenol_catechol_pair", 7.0   # FIX 4b
        else:
            label, pka = "flavone_phenol_isolated", 8.5         # FIX 2 (apigenin 7-OH actual pKa ~8.7)

        sites.append({
            "label":         label,
            "atom_indices":  [o_idx, c_idx],
            "ionizable_idx": o_idx,
            "heuristic_pka": pka,
            "site_type":     "acid",
        })

    if sites:
        detail = ", ".join(
            f"{s['label'].replace('flavone_','')}(pKa={s['heuristic_pka']})"
            for s in sites
        )
        print(f"    🌸  Detected {len(sites)} flavonoid A-ring phenol(s): {detail}")

    return sites


# ── Ionizable site SMARTS table ───────────────────────────────────────────────

_IONIZABLE_SITE_DEF = [
    ("sulfonic_acid",      "[SX4](=O)(=O)[OX2H1]",                             1.0,  "acid"),
    ("phosphate_diester",  "[PX4](=O)([OX2H1])([OX2,OX1-])[OX2,OX1-]",       2.1,  "acid"),  # alpha/beta/gamma-P (1 OH)
    ("phosphonate",       "[PX4](=O)([OX2H1])[OX2H1]",                         2.1,  "acid"),  # gamma-P (2 OH)
    ("carboxylic_acid",    "[CX3](=O)[OX2H1]",                                 4.5,  "acid"),
    ("tetrazole",          "c1nn[nH]n1",                                        4.9,  "acid"),
    # imidazole_acid removed: pKa 6.0 is the BASE (imidazolium) pKa, not N-H acid pKa
    # (~14). Treating it as acid caused false deprotonation at pH 7.4. The
    # protonatable ring N is already captured by pyridine_like (pKa=5.2, base).
    # benzimidazole: pKa 5.5 is also the BASE pKa (ring N protonation), not N-H acid
    # (~13). Changed to base so it is correctly neutral at pH 7.4 (e.g. omeprazole).
    ("benzimidazole",      "c1ccc2[nH]cnc2c1",                                 5.5,  "base"),
    # ── N-H acids (patched 2026-05): heteroaryl sulfonamides + barbiturate ──
    # NEW: sulfonyl-imide N-H split into cyclic vs sulfonylurea contexts.
    ("sulfonyl_imide_NH_cyclic",   "[CX3;R](=O)[NX3;H1;R][SX4;R](=O)(=O)",       2.0,  "acid"),
    ("sulfonylurea_NH",            "[NX3;H0,H1][CX3;!R](=O)[NX3;H1;!R][SX4;!R](=O)(=O)", 5.5,  "acid"),
    ("sulfonyl_imide_NH",          "[CX3](=O)[NX3;H1][SX4](=O)(=O)",             2.0,  "acid"),
    # Heteroaryl sulfonamide N-H (sulfa-antibiotics) pKa ~5-7 — MUST precede sulfonamide_NH
    ("sulfonamide_5het_NH",        "[SX4](=O)(=O)[NX3;H1][c;$([c]1[c,n][o,n,s][c,n][c,n]1),$([c]1[c,n][c,n][o,n,s][c,n]1)]",  5.7, "acid"),
    ("sulfonamide_thiazole_NH",    "[SX4](=O)(=O)[NX3;H1]c1nccs1",               7.0,  "acid"),
    ("sulfonamide_oxazole_NH",     "[SX4](=O)(=O)[NX3;H1]c1ncco1",               6.5,  "acid"),
    ("sulfonamide_pyrim2_NH",      "[SX4](=O)(=O)[NX3;H1]c1ncccn1",              7.0,  "acid"),
    ("sulfonamide_pyrim4_NH",      "[SX4](=O)(=O)[NX3;H1]c1ccncn1",              6.5,  "acid"),
    ("sulfonamide_pyrim5_NH",      "[SX4](=O)(=O)[NX3;H1]c1cncnc1",              6.5,  "acid"),
    ("sulfonamide_pyrazin_NH",     "[SX4](=O)(=O)[NX3;H1]c1cnccn1",              7.0,  "acid"),
    ("sulfonamide_pyridazin_NH",   "[SX4](=O)(=O)[NX3;H1]c1ccnnc1",              7.0,  "acid"),
    # 1,2,4-thiadiazol-5-yl: sulfamethizole pKa 5.45
    ("sulfonamide_thiadiazole_NH", "[SX4](=O)(=O)[NX3;H1]c1nncs1",               5.5,  "acid"),
    # Generic sulfonamide: H1,H2 to catch both secondary AND primary (-SO2-NH2)
    ("sulfonamide_NH",             "[SX4](=O)(=O)[NX3;H1,H2]",                  10.1,  "acid"),
    # Barbiturate ring N-H: pKa ~7.4 (phenobarbital). MUST precede imide_NH.
    ("barbiturate_NH",             "[NX3;H1;R]1[CX3;R](=O)[NX3;H1,H0;R][CX3;R](=O)[CX4;R][CX3;R]1=O", 7.4, "acid"),
    ("imide_NH",                   "[CX3](=O)[NX3;H1][CX3]=O",                   9.6,  "acid"),
    ("acylhydrazone_NH",   "[CX3](=O)[NX3;H1][NX2]=[CX3]",                   10.5,  "acid"),
    ("hydrazide_NH",       "[CX3](=O)[NX3;H1][NX3;H2]",                       10.5,  "acid"),
    ("urea_NH",            "[NX3;H1][CX3](=O)[NX3;H1,H2]",                    13.0,  "acid"),
    ("amide_NH",           "[CX3](=O)[NX3;H1,H2;!$([N]~N)]",                  15.0,  "acid"),
    ("phenol_diacyl",      "[OX2H1][c;R]1[c;R][c;R](=O)[c;R][c;R][c;R]1=O",   3.5,  "acid"),
    ("phenol_ortho_CO",    "[OX2H1][c;R]:[c;R][CX3;R](=O)",                    7.8,  "acid"),
    ("catechol_OH",        "[OX2H1][c;R]:[c;R][OX2H1]",                        9.2,  "acid"),
    ("phenol_EWG",         "[OX2H1][c;R]:[c;R][$([NX3](=O)=O),$([CX3]=O),"
                           "$(C#N),$([SX4](=O)(=O))]",                         7.2,  "acid"),
    ("phenol",             "c[OX2H1]",                                         10.0,  "acid"),
    ("thiol_arom",         "c[SX2H1]",                                          6.5,  "acid"),
    ("thiol_aliph",        "[CX4][SX2H1]",                                      9.8,  "acid"),
    ("aniline",            "c[NX3;H1,H2;!$(N~[!#6])]",                         4.6,  "base"),
    ("pyridine_like",      "[$([nX2]1:[c,n]:c:[c,n]:c1),$([nX2]:c:n)]",        5.2,  "base"),
    ("morpholine_N",       "[NX3;H0;R;$(N1CC[O,S]CC1)]",                       4.9,  "base"),
    ("piperazine_NH",      "[NX3;H1;R;$(N1CCNCC1)]",                           8.1,  "base"),
    ("piperazine_N_sub",   "[NX3;H0;R;$(N1CCNCC1)]",                           3.5,  "base"),
    # amidine and guanidine MUST precede aliphatic_amine (GROUP_SITE_LABELS claim all N atoms).
    ("amidine",            "[CX3](=[NX2;H0,H1])[NX3;H1,H2;"
                           "!$([NX3][CX3](=[NX2])[NX3])]",                    12.4,  "base"),
    ("guanidine",          "[NX3][CX3](=[NX2;!$(N~C#N)])[NX3]",               12.5,  "base"),
    ("amine_gamma_ring_sulfonyl",  "[NX3;H1,H2;!$(NC=O);!$([nH])][CX4;R][CX4;R][CX4;R][SX4;R](=O)(=O)", 6.5, "base"),
    ("aliphatic_amine",    "[NX3;H1,H2;!$(NC=O);!$(N~[!#6;!H]);!$([nH]);"
                           "!$(Nc);!$([NX3][CX3](=[NX2]))]",                  9.5,  "base"),
    ("aliphatic_amine_t",  "[NX3;H0;!$(NC=O);!$(Nc);!$([nH]);!$([N]~[!#6]);"
                           "!$([N;R]1CC[O,S]CC1);!$([N;R]1CCNCC1)]",          9.0,  "base"),
]


def _compile_ionizable_sites():
    from rdkit import Chem
    compiled = []
    for lbl, sma, pka, stype in _IONIZABLE_SITE_DEF:
        pat = Chem.MolFromSmarts(sma)
        if pat is not None:
            compiled.append((lbl, pat, pka, stype))
    return compiled

_IONIZABLE_SITES_COMPILED = _compile_ionizable_sites()


# ── FIX 5: find_ionizable_sites with claimed_atoms ───────────────────────────

def _find_ionizable_sites(mol):
    """
    FIX 5: claimed_atoms prevents SMARTS pass from overwriting A-ring OHs.

    Pass 1: flavonoid A-ring phenols (claim atoms -> block Pass 2).
    Pass 2: SMARTS table, first-match-wins per ionizable atom.
    """
    sites         = []
    seen_ion      = set()
    claimed_atoms = set()

    # Pass 1 — flavone A-ring (highest priority)
    for site in _find_flavone_A_ring_phenols(mol):
        ion_idx = site["ionizable_idx"]
        if ion_idx in seen_ion:
            continue
        seen_ion.add(ion_idx)
        claimed_atoms.update(site["atom_indices"])
        sites.append(site)

    # Pass 2 — generic SMARTS table (per-atom dedup)
    # Each ionizable atom (O/S/N with H) in a match becomes its own site.
    # This correctly handles multi-OH groups (e.g. gamma-phosphate in ATP/ADP)
    # where a single SMARTS match covers 2 ionizable oxygens.
    #
    # GROUP_SITES: entries that represent a resonance-delocalized ionization
    # event spanning multiple N atoms (guanidine, amidine). After one site is
    # recorded, ALL nitrogen atoms in the match are added to seen_ion so that
    # aliphatic_amine cannot claim the remaining NH/NH2 atoms in the same group
    # and produce spurious extra charges (e.g. arginine +3 instead of +1).
    _GROUP_SITE_LABELS = frozenset({"guanidine", "amidine"})

    for lbl, pat, pka, stype in _IONIZABLE_SITES_COMPILED:
        for match in mol.GetSubstructMatches(pat):
            if any(a in claimed_atoms for a in match):
                continue
            ion_atoms = [
                idx for idx in match
                if mol.GetAtomWithIdx(idx).GetAtomicNum() in (7, 8, 16)
                and mol.GetAtomWithIdx(idx).GetTotalNumHs() > 0
                and idx not in seen_ion
            ]
            if lbl == "sulfonylurea_NH":
                # Match atom 3 is N(H) bonded to BOTH sulfonyl S and carbonyl C.
                # The distal urea N must not inherit the same acidic pKa.
                ion_atoms = [match[3]] if match[3] in ion_atoms else []
                if ion_atoms:
                    claimed_atoms.update(match)
            if not ion_atoms:
                continue
            for ion_idx in ion_atoms:
                seen_ion.add(ion_idx)
                sites.append({
                    "label":         lbl,
                    "atom_indices":  [ion_idx],
                    "ionizable_idx": ion_idx,
                    "heuristic_pka": pka,
                    "site_type":     stype,
                })
                # For group sites (guanidine/amidine), record only the first
                # ionizable atom as the site, then claim all remaining N atoms
                # in the match so they cannot be re-fired by aliphatic_amine.
                if lbl in _GROUP_SITE_LABELS:
                    for other_idx in match:
                        if (other_idx != ion_idx
                                and mol.GetAtomWithIdx(other_idx).GetAtomicNum() == 7):
                            seen_ion.add(other_idx)
                    break  # only one site per guanidine/amidine group
    return sites


# ── FIX 6: HH scoring with dpH-scaled formula ────────────────────────────────

def _hh_fraction_charged(pka, ph, site_type):
    if site_type == "acid":
        return 1.0 / (1.0 + 10.0 ** (pka - ph))
    return 1.0 / (1.0 + 10.0 ** (ph - pka))


def _hh_match_score(pka, ph, site_type, actual_charge):
    """FIX 6: Real pKaNET Cloud formula — dpH-scaled with decisive multiplier."""
    f_charged = _hh_fraction_charged(pka, ph, site_type)
    dpH       = abs(ph - pka)
    decisive  = (f_charged >= 0.65) or (f_charged <= 0.35)
    rwd_mul   = 1.6 if decisive else 1.0
    pen_mul   = 1.6 if decisive else 1.0
    if site_type == "acid":
        expected_neg = f_charged > 0.5
        if expected_neg and actual_charge < 0:
            return  min(1.5, dpH * 0.55 * rwd_mul) + 0.15
        elif expected_neg:
            return -min(1.5, dpH * 0.45 * pen_mul) - 0.15
        elif actual_charge >= 0:
            return  0.15
        else:
            return -min(1.5, dpH * 0.45 * pen_mul) - 0.15
    else:
        expected_pos = f_charged > 0.5
        if expected_pos and actual_charge > 0:
            return  min(1.5, dpH * 0.55 * rwd_mul) + 0.15
        elif expected_pos:
            return -min(1.5, dpH * 0.45 * pen_mul) - 0.15
        elif actual_charge <= 0:
            return  0.15
        else:
            return -min(1.5, dpH * 0.45 * pen_mul) - 0.15


# ── FIX 7: Tautomer plausibility with aromaticity guards ─────────────────────

_CHEM_BONUS_DEF = [
    ("amide",            +2.5, "[CX3](=O)[NX3;H1,H2]"),
    ("lactam",           +2.5, "[C;R](=O)[N;R]"),
    ("urea_NH",          +1.5, "[NX3;H1][CX3](=O)[NX3;H1,H2]"),
    ("thioamide",        +1.0, "[CX3](=S)[NX3;H1,H2]"),
    ("aromatic_ring",    +0.3, "c1ccccc1"),
    ("phenol_preserved", _W_PHENOL_PRESERVED_BONUS, "c[OX2H1]"),
]
_CHEM_PENALTY_DEF = [
    ("lactim_ring",      -4.0, "[C;R](=[NX2])[OX2H1]"),
    ("iminol_general",   -3.5, "[NX2]=[CX3][OX2H1]"),
    ("amide_N_deproton", -5.0, "[$([NX3-]C=O),$([NX3-]c=O)]"),
    ("enol_simple",      -1.2, "[CX3](=[CX3])[OX2H1]"),
    ("exo_imine_arom",   -2.5, "[NX2;!r]=[cX3]"),
    ("pyrogallol_triketo", -_W_PYROGALLOL_TRIKETO,
        "[#6;!a;R]1(=O)[#6;!a;R](=O)[#6;!a;R](=O)[#6;R][#6;R][#6;R]1"),
    ("catechol_diketo",    -_W_CATECHOL_DIKETO,
        "[#6;!a;R]1(=O)[#6;!a;R](=O)[#6;R][#6;R][#6;R][#6;R]1"),
]


def _compile_chem_rules():
    from rdkit import Chem
    rules = []
    for lbl, wt, sma in _CHEM_BONUS_DEF + _CHEM_PENALTY_DEF:
        pat = Chem.MolFromSmarts(sma)
        if pat is not None:
            rules.append((lbl, wt, pat))
    return rules

_CHEM_RULES = _compile_chem_rules()


def _n_aromatic_rings(mol):
    if mol is None:
        return 0
    try:
        from rdkit.Chem import rdMolDescriptors
        return int(rdMolDescriptors.CalcNumAromaticRings(mol))
    except Exception:
        return 0


def _count_phenolic_OH(mol):
    if mol is None:
        return 0
    from rdkit import Chem
    pat = Chem.MolFromSmarts("c[OX2H1]")
    if pat is None:
        return 0
    return len(mol.GetSubstructMatches(pat))


def _score_tautomer(smiles, ref_mol=None):
    """FIX 7: Aromaticity-loss and phenol-flip penalties vs ref_mol."""
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return -999.0
    total = 0.0
    for lbl, wt, pat in _CHEM_RULES:
        n = len(mol.GetSubstructMatches(pat))
        if n:
            total += wt * n
    if ref_mol is not None:
        rings_lost   = max(0, _n_aromatic_rings(ref_mol) - _n_aromatic_rings(mol))
        phenols_lost = max(0, _count_phenolic_OH(ref_mol) - _count_phenolic_OH(mol))
        if rings_lost > 0:
            total += -_W_AROM_RING_LOST * rings_lost
        if phenols_lost > 0:
            total += -_W_PHENOL_TO_KETO_FLIP * phenols_lost
    return total


# ── FIX 8: Full 8-component microstate scoring ───────────────────────────────

def _score_microstate(smiles, ph, taut_score, pubchem, ref_mol=None, ion_sites=None):
    """
    FIX 8: Full 8-component scoring matching real pKaNET Cloud:
      s1 amide-N deprotonation safety
      s2 aromaticity loss vs ref_mol
      s3 tautomer plausibility (weighted)
      s4 HH pH-consistency per ionizable site
      s5 PubChem evidence bonus
      s6 zwitterion consistency
      s7 improbable neutral penalty
      s8 multicharge penalty
    """
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return -1e9

    # ion_sites must come from ref_mol (the original input SMILES), NOT from
    # the microstate mol which has [O-] atoms (Hs=0) that break site detection.
    if ion_sites is None:
        ion_sites = _find_ionizable_sites(ref_mol if ref_mol is not None else mol)
    fc_map    = {a.GetIdx(): int(a.GetFormalCharge()) for a in mol.GetAtoms()}
    net       = sum(fc_map.values())
    n_pos     = sum(1 for v in fc_map.values() if v > 0)
    n_neg     = sum(1 for v in fc_map.values() if v < 0)

    # s1: amide-N deprotonation safety
    pat_bad = Chem.MolFromSmarts("[$([NX3-]C=O),$([NX3-]c=O)]")
    s1 = -5.0 * len(mol.GetSubstructMatches(pat_bad)) if pat_bad else 0.0

    # s2: aromaticity loss vs ref_mol
    s2 = 0.0
    if ref_mol is not None:
        rings_lost = max(0, _n_aromatic_rings(ref_mol) - _n_aromatic_rings(mol))
        if rings_lost > 0:
            s2 = -_W_AROM_RING_LOST * rings_lost

    # s3: tautomer plausibility
    s3 = 0.65 * taut_score

    # s4: HH pH-consistency for each ionizable site
    s4 = 0.0
    for site in ion_sites:
        pka = site["heuristic_pka"]
        if pubchem.get("available") and pubchem.get("confidence") in ("high", "medium"):
            pc_vals = pubchem.get("pka_values", [])
            if pc_vals:
                pka = min(pc_vals, key=lambda v: abs(v - pka))
        site_charge = sum(fc_map.get(i, 0) for i in site["atom_indices"])
        s4 += _hh_match_score(pka, ph, site["site_type"], site_charge)

    # s5: PubChem evidence bonus
    s5 = 0.0
    if pubchem.get("available"):
        w = {"high": 1.0, "medium": 0.6, "low": 0.2}.get(
            pubchem.get("confidence", "low"), 0.2)
        for pv in pubchem.get("pka_values", []):
            exp = -1 if _hh_fraction_charged(pv, ph, "acid") > 0.5 else 0
            s5 += 0.25 * w if net == exp else -0.15 * w
        s5 = max(-0.4, min(0.5, s5))

    # s6: zwitterion consistency
    has_acid = any(s["site_type"] == "acid"
                   and (ph - s["heuristic_pka"]) > 1.0 for s in ion_sites)
    has_base = any(s["site_type"] == "base"
                   and (s["heuristic_pka"] - ph) > 1.0 for s in ion_sites)
    is_zw = (n_pos > 0 and n_neg > 0 and net == 0)
    if is_zw:
        s6 = 0.8 if (has_acid and has_base) else -0.6
    else:
        s6 = -0.4 if (has_acid and has_base and net == 0 and n_pos == 0) else 0.0

    # s7: improbable neutral penalty
    strong_acid   = [s for s in ion_sites if s["site_type"] == "acid"
                     and (ph - s["heuristic_pka"]) > 2.0]
    strong_base   = [s for s in ion_sites if s["site_type"] == "base"
                     and (s["heuristic_pka"] - ph) > 2.0]
    probable_acid = [s for s in ion_sites if s["site_type"] == "acid"
                     and 0.0 < (ph - s["heuristic_pka"]) <= 2.0]
    probable_base = [s for s in ion_sites if s["site_type"] == "base"
                     and 0.0 < (s["heuristic_pka"] - ph) <= 2.0]
    s7 = 0.0
    if strong_acid  and net >= 0 and n_neg == 0:
        s7 -= 0.5  * len(strong_acid)
    if strong_base  and net <= 0 and n_pos == 0:
        s7 -= 0.5  * len(strong_base)
    if probable_acid and net >= 0 and n_neg == 0:
        s7 -= 0.35 * len(probable_acid)
    if probable_base and net <= 0 and n_pos == 0:
        s7 -= 0.35 * len(probable_base)

    # s8: multicharge penalty
    s8 = -0.12 * max(0, n_pos + n_neg - 2)

    return s1 + s2 + s3 + s4 + s5 + s6 + s7 + s8


# ── FIX 9: Manual deprotonation ──────────────────────────────────────────────

def _manual_deprotonate_site(smiles, site):
    """FIX 9: Manually ionize a specific site. Returns new SMILES or None."""
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    if site.get("label") == "sulfonylurea_NH":
        # Canonical SMILES can reorder atoms. Re-find only the sulfonyl-side NH;
        # do not fall back to a different NH once this site is deprotonated.
        pat = next(p for label, p, *_ in _IONIZABLE_SITES_COMPILED
                   if label == "sulfonylurea_NH")
        matches = mol.GetSubstructMatches(pat)
        if not matches:
            return None
        site = dict(site, atom_indices=[matches[0][3]])
    rw = Chem.RWMol(mol)
    target_idx = None
    for idx in site["atom_indices"]:
        if idx >= rw.GetNumAtoms():
            continue
        atom = rw.GetAtomWithIdx(idx)
        sym, nh = atom.GetSymbol(), atom.GetTotalNumHs()
        if site["site_type"] == "acid":
            if sym in ("O", "S") and nh >= 1:
                target_idx = idx; break
            if sym == "N" and nh >= 1 and target_idx is None:
                target_idx = idx
        else:
            if sym == "N" and atom.GetFormalCharge() == 0:
                target_idx = idx; break
    if target_idx is None:
        return None
    try:
        atom = rw.GetAtomWithIdx(target_idx)
        if site["site_type"] == "acid":
            atom.SetFormalCharge(-1)
            atom.SetNumExplicitHs(0)
            atom.SetNoImplicit(False)
        else:
            atom.SetFormalCharge(+1)
            atom.SetNumExplicitHs(atom.GetTotalNumHs() + 1)
            atom.SetNoImplicit(False)
        new_mol = rw.GetMol()
        Chem.SanitizeMol(new_mol)
        return Chem.MolToSmiles(new_mol, isomericSmiles=True, canonical=True)
    except Exception:
        return None


# ── FIX 10: Supplement Dimorphite with missed ionizable sites ─────────────────

def _supplement_dimorphite(tautomer_smiles, dimorphite_results, ion_sites, target_ph):
    """
    FIX 10: For each ionizable site Dimorphite missed, force-generate
    the ionized variant. Critical for flavonoid A-ring OHs which
    Dimorphite's internal SMARTS table does not cover.
    """
    supplemented = list(dimorphite_results)
    existing     = set(dimorphite_results)
    for site in ion_sites:
        pka   = site.get("heuristic_pka", 10.0)
        stype = site.get("site_type", "acid")
        if stype == "acid" and (target_ph - pka) < -1.5:
            continue
        if stype == "base" and (pka - target_ph) < -1.5:
            continue
        new_smi = _manual_deprotonate_site(tautomer_smiles, site)
        if new_smi and new_smi not in existing:
            supplemented.append(new_smi)
            existing.add(new_smi)
    return supplemented


# ── PubChem lookup ────────────────────────────────────────────────────────────
# NOTE: PubChem pKa retrieval is delegated to pkanet-cloud.py's `pubchem_lookup`,
# loaded via `_load_local_pkanet_module` and used at protonate_pkanet Stage B
# (see line ~1810 below). The canonical implementation is preferred because it
# offers persistent two-level caching (cid:{ik} + diss:{cid}), evidence-graded
# confidence (temperature/solvent/site-label/vague/conflicting flags), a third
# regex fallback for loose prose forms, and a richer return dict
# (cid, inchikey, source_texts, flags, error). A local re-implementation was
# removed to prevent accidental use of a weaker duplicate.


# ── FIX 11: generate_ranked_microstates (full pipeline) ──────────────────────

def _generate_ranked_microstates(
    base_smiles,
    target_ph=7.4,
    ph_window=1.0,
    max_tautomers=8,
    pubchem=None,
):
    """
    FIX 11: Full pKaNET Cloud microstate ranking pipeline.
    Returns list of dicts sorted by selection_score descending.
    Each dict: microstate_smiles, net_charge, selection_score
    """
    from rdkit import Chem
    from rdkit.Chem.MolStandardize import rdMolStandardize

    if pubchem is None:
        pubchem = {}

    ref_mol = Chem.MolFromSmiles(base_smiles)
    if ref_mol is None:
        return []

    # Tautomer enumeration with aromaticity guard (FIX 7)
    enum   = rdMolStandardize.TautomerEnumerator()
    seen_t = set()
    tautomers = []
    input_canon = Chem.MolToSmiles(ref_mol, isomericSmiles=True, canonical=True)
    seen_t.add(input_canon)
    tautomers.append({
        "smiles": input_canon,
        "score":  _score_tautomer(input_canon, ref_mol=ref_mol),
    })
    try:
        for tmol in enum.Enumerate(ref_mol):
            smi = Chem.MolToSmiles(tmol, isomericSmiles=True, canonical=True)
            if smi in seen_t:
                continue
            seen_t.add(smi)
            tautomers.append({
                "smiles": smi,
                "score":  _score_tautomer(smi, ref_mol=ref_mol),
            })
    except Exception:
        pass

    tautomers = sorted(tautomers, key=lambda x: -x["score"])[:max_tautomers]
    best_t    = tautomers[0]["score"]
    kept      = [t for t in tautomers
                 if t["score"] >= best_t - _TAUTOMER_PLAUSIBILITY_CUTOFF]
    if not kept:
        kept = [tautomers[0]]

    # Ionizable sites from input molecule (FIX 5 — claimed_atoms)
    ion_sites = _find_ionizable_sites(ref_mol)

    ph_lo = max(0.0,  target_ph - ph_window / 2)
    ph_hi = min(14.0, target_ph + ph_window / 2)

    all_micro = []
    seen_smi  = set()

    for taut in kept:
        # Dimorphite-DL enumeration
        raw_states = [taut["smiles"]]
        try:
            from dimorphite_dl import protonate_smiles as _dim
            _raw = None
            for kw in [
                {"ph_min": ph_lo, "ph_max": ph_hi, "max_variants": 32},
                {"min_ph": ph_lo, "max_ph": ph_hi, "max_variants": 32},
            ]:
                try:
                    _raw = _dim(taut["smiles"], **kw)
                    break
                except TypeError:
                    continue
            if _raw:
                seen_d = {taut["smiles"]}
                for s in (_raw if isinstance(_raw, list) else [_raw]):
                    if not s:
                        continue
                    m = Chem.MolFromSmiles(s)
                    if m is None:
                        continue
                    c = Chem.MolToSmiles(m, canonical=True)
                    if c and c not in seen_d:
                        seen_d.add(c)
                        raw_states.append(c)
        except Exception:
            pass

        # FIX 10: supplement for sites Dimorphite missed
        microstates = _supplement_dimorphite(
            taut["smiles"], raw_states, ion_sites, target_ph
        )

        for smi in microstates:
            if smi in seen_smi:
                continue
            mol_check = Chem.MolFromSmiles(smi)
            if mol_check is None:
                continue
            seen_smi.add(smi)
            sc  = _score_microstate(smi, target_ph, taut["score"], pubchem,
                                    ref_mol=ref_mol, ion_sites=ion_sites)
            net = int(Chem.GetFormalCharge(mol_check))
            all_micro.append({
                "microstate_smiles": smi,
                "tautomer_smiles":   taut["smiles"],
                "selection_score":   float(sc),
                "net_charge":        net,
            })

    all_micro.sort(key=lambda x: (
        -x["selection_score"],
        abs(x["net_charge"]),
        x["microstate_smiles"],
    ))
    return all_micro


# ── FIX 12: _apply_ionizable_site_correction (uses fixed site detection) ─────

def _apply_ionizable_site_correction(original_smiles: str, current_smiles: str,
                                      ph: float, log: list) -> str:
    """
    FIX 12: Post-Dimorphite correction using the FIXED _find_ionizable_sites.
    Deprotonates any acid site with pKa < pH still protonated in current_smiles.
    Now works for flavonoids because _find_ionizable_sites uses claimed_atoms
    (FIX 5) and correct A-ring pKas (Fixes 1-4).
    """
    from rdkit import Chem
    mol = Chem.MolFromSmiles(current_smiles)
    if mol is None:
        return current_smiles

    fc_map = {a.GetIdx(): int(a.GetFormalCharge()) for a in mol.GetAtoms()}
    sites  = _find_ionizable_sites(mol)

    missed = sorted(
        [s for s in sites
         if s["site_type"] == "acid"
         and s["heuristic_pka"] < ph
         and s.get("ionizable_idx") is not None
         and mol.GetAtomWithIdx(s["ionizable_idx"]).GetTotalNumHs() > 0
         and fc_map.get(s["ionizable_idx"], 0) >= 0],
        key=lambda s: s["heuristic_pka"]
    )
    if not missed:
        return current_smiles

    site = missed[0]
    try:
        rw = Chem.RWMol(mol)
        rw.GetAtomWithIdx(site["ionizable_idx"]).SetFormalCharge(-1)
        Chem.SanitizeMol(rw)
        corrected = Chem.MolToSmiles(rw, canonical=True)
        log.append(
            f"✓ pKa site correction: deprotonated {site['label']} "
            f"(pKa={site['heuristic_pka']:.1f} < pH {ph:.1f})"
        )
        return corrected
    except Exception as e:
        log.append(f"⚠ Site correction failed ({site['label']}): {e}")
        return current_smiles


# ── protonate_pkanet: public API (unchanged signature) ───────────────────────
# NOTE: delegates entirely to pKaNET.py (generate_ranked_microstates) which
# contains the authoritative, bug-fixed implementation (2026-05 overhaul).
# Bugs fixed in pKaNET.py that were present in the old internal implementation:
#   Bug #1/#2  imidazole/benzimidazole pKa (6.0/5.5 → 14/13)
#   Bug A      phosphonate double-counting
#   Bug B      thiol_aliph pKa (10.5 → 9.8) + new thiol_alpha_amino (8.3)
#   Bug C      missing hydroxamic acid entry
#   Bug D      phosphate_diester label/pKa wrong
#   Bug F      catechol_OH priority
#   Bug G      new amine_alpha_EWG entry (pKa=7.5)
#   + new entries: sulfonyl_imide_NH, enol_lactone, enol_cyclic_dicarbonyl,
#                  enol_1_3_dicarbonyl, pyrazole_NH, indole_NH, aliphatic_imine


def _load_local_pkanet_module(log=None):
    """
    Load the adjacent pkanet.py (legacy pKaNET.py only if unambiguous).
    Reject distinct case-variant files and stale molecular-identity APIs.
    Reload locally rather than using an engine cached on sys.path.
    """
    import importlib.util
    import sys
    import hashlib
    from pathlib import Path

    core_dir = Path(__file__).resolve().parent
    candidates = [core_dir / name for name in ("pkanet.py", "pKaNET.py")
                  if (core_dir / name).exists()]
    if not candidates:
        raise FileNotFoundError(f"pKaNET.py/pkanet.py not found next to core.py: {core_dir}")
    hashes = [hashlib.md5(path.read_bytes()).hexdigest() for path in candidates]
    if len(candidates) == 2 and (
        not candidates[0].samefile(candidates[1]) or hashes[0] != hashes[1]
    ):
        raise RuntimeError(
            "Conflicting pKaNET engine files: "
            + "; ".join(f"{path} (md5 {digest})" for path, digest in zip(candidates, hashes))
            + ". Keep only one engine file, preferably the current pkanet.py."
        )
    pkanet_path = candidates[0]
    file_hash = hashes[0]

    module_name = "pKaNET_local_ACD"

    # Always reload the local file to avoid stale module cache.
    if module_name in sys.modules:
        del sys.modules[module_name]

    spec = importlib.util.spec_from_file_location(module_name, str(pkanet_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load pKaNET module from: {pkanet_path}")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    if not callable(getattr(mod, "_same_heavy_bond_graph", None)):
        raise RuntimeError(
            f"Stale pKaNET build loaded from {pkanet_path} (md5 {file_hash}): "
            "missing molecular-identity API required by core.py"
        )
    required = ("standardize_smiles", "pubchem_lookup", "generate_ranked_microstates")
    missing = [name for name in required if not callable(getattr(mod, name, None))]
    if missing:
        raise RuntimeError(
            f"Invalid pKaNET build loaded from {pkanet_path} (md5 {file_hash}): "
            f"missing required API: {', '.join(missing)}"
        )

    if log is not None:
        log.append(f"✓ pKaNET loaded from: {pkanet_path.name}  (md5: {file_hash})")

    return mod



def _pkanet_stereo_status(smiles: str) -> dict:
    """Detect whether a SMILES has assigned/undefined tetrahedral stereochemistry."""
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"valid": False, "assigned": 0, "unassigned": 0, "centers": []}
    centers = Chem.FindMolChiralCenters(mol, includeUnassigned=True, useLegacyImplementation=False)
    assigned = [(i, lab) for i, lab in centers if lab in ("R", "S")]
    unassigned = [(i, lab) for i, lab in centers if lab == "?"]
    return {"valid": True, "assigned": len(assigned), "unassigned": len(unassigned), "centers": centers}


def _select_pkanet_stereoisomer(smiles: str, stereo_choice: str = "keep_input") -> tuple[str, list[str], dict]:
    """
    Select R/S only when the input SMILES has one undefined chiral center.
    If the input already contains assigned stereochemistry (@/@@; RDKit R/S), it is kept unchanged.
    """
    from rdkit import Chem
    from rdkit.Chem.EnumerateStereoisomers import EnumerateStereoisomers, StereoEnumerationOptions

    log = []
    choice = (stereo_choice or "keep_input").strip().upper()
    if choice in {"KEEP", "KEEP_INPUT", "AS_IS", "AUTO", ""}:
        choice = "KEEP_INPUT"

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles[:60]}")

    status = _pkanet_stereo_status(smiles)
    if status["assigned"] > 0:
        log.append("✓ Stereochemistry already defined in input SMILES (@/@@); keeping input stereochemistry")
        return Chem.MolToSmiles(mol, isomericSmiles=True, canonical=True), log, status

    if choice not in {"R", "S"}:
        if status["unassigned"] > 0:
            log.append(f"ℹ Undefined stereocenter(s) detected: {status['unassigned']}; keeping input without forced R/S")
        return Chem.MolToSmiles(mol, isomericSmiles=True, canonical=True), log, status

    if status["unassigned"] == 0:
        log.append(f"ℹ No undefined stereocenter detected; requested {choice} ignored")
        return Chem.MolToSmiles(mol, isomericSmiles=True, canonical=True), log, status

    if status["unassigned"] != 1:
        log.append(f"⚠ {status['unassigned']} undefined stereocenters detected; R/S selector is only applied to single-center ligands. Keeping input.")
        return Chem.MolToSmiles(mol, isomericSmiles=True, canonical=True), log, status

    opts = StereoEnumerationOptions(onlyUnassigned=True, unique=True)
    isomers = list(EnumerateStereoisomers(mol, options=opts))
    for iso in isomers:
        centers = Chem.FindMolChiralCenters(iso, includeUnassigned=True, useLegacyImplementation=False)
        labels = [lab for _, lab in centers if lab in ("R", "S")]
        if len(labels) == 1 and labels[0] == choice:
            smi = Chem.MolToSmiles(iso, isomericSmiles=True, canonical=True)
            log.append(f"✓ Undefined stereocenter resolved as {choice} for docking")
            return smi, log, status

    log.append(f"⚠ Could not generate requested {choice} stereoisomer; keeping input")
    return Chem.MolToSmiles(mol, isomericSmiles=True, canonical=True), log, status

def protonate_pkanet(
    smiles: str,
    ph: float,
    use_pubchem: bool = False,
    max_tautomers: int = 8,
    ph_window: float = 1.0,
    selection_mode: str = "auto_recommended",
    manual_rank: int | None = None,
    stereo_choice: str = "keep_input",
    return_details: bool = False,
) -> tuple:
    """
    pKaNET Cloud protonation pipeline.
    Returns (selected_smiles, charge, log_list).
    If return_details=True, returns (selected_smiles, charge, log_list, details_dict).

    Important:
    - This function loads the validated adjacent pkanet.py (legacy name if unambiguous).
    - It does NOT silently fall back to Dimorphite-DL when pKaNET mode is selected.
      If pKaNET fails, the app should stop and show the error/log.
    """
    from rdkit import Chem

    log = []

    # ── Import authoritative local pKaNET.py ────────────────────────────────
    try:
        pk = _load_local_pkanet_module(log)

        _pkanet_standardize = pk.standardize_smiles
        _pkanet_pubchem = pk.pubchem_lookup
        _pkanet_rank = pk.generate_ranked_microstates

        log.append("✓ Validated local pKaNET engine imported")
    except Exception as e:
        log.append(f"❌ pKaNET import failed: {e}")
        if isinstance(e, RuntimeError):
            raise
        raise RuntimeError(
            f"pKaNET mode was selected, but the adjacent engine could not be loaded: {e}"
        ) from e

    # ── Stage 0: optional stereochemistry resolution ────────────────────────
    stereo_input, stereo_log, stereo_status = _select_pkanet_stereoisomer(smiles.strip(), stereo_choice)
    log.extend(stereo_log)

    # ── Stage A: Standardize via pKaNET ─────────────────────────────────────
    canonical, std_status = _pkanet_standardize(stereo_input)
    if canonical is None:
        log.append(f"❌ Standardization failed ({std_status})")
        raise ValueError(f"pKaNET standardization failed: {std_status}")

    log.append("✓ RDKit standardized (pKaNET)")

    # ── Stage B: PubChem pKa lookup via pKaNET ──────────────────────────────
    pubchem_result = {}
    if use_pubchem:
        try:
            pubchem_result = _pkanet_pubchem(canonical)
            if pubchem_result.get("available"):
                log.append(
                    f"✓ PubChem pKa: {pubchem_result.get('pka_values', [])} "
                    f"(conf: {pubchem_result.get('confidence', '?')})"
                )
            else:
                log.append(
                    f"ℹ PubChem: no usable pKa data — heuristic table "
                    f"({pubchem_result.get('error', '')})"
                )
        except Exception as e:
            # PubChem is optional evidence; do not stop pKaNET.
            pubchem_result = {}
            log.append(f"⚠ PubChem lookup failed: {e}")

    # ── Stage C: Ranked microstates via pKaNET.py ───────────────────────────
    try:
        top, ambiguous, all_micro, tr_flag, tr_motifs, ml_preds = _pkanet_rank(
            canonical,
            target_ph=ph,
            ph_window=ph_window,
            max_tautomers=max_tautomers,
            top_n=5,
            pubchem_result=pubchem_result,
        )
    except Exception as e:
        log.append(f"❌ pKaNET ranking failed: {e}")
        raise RuntimeError("pKaNET ranking failed. No fallback was used.") from e

    if not top:
        log.append("❌ pKaNET returned no microstates")
        raise RuntimeError("pKaNET returned no microstates. No fallback was used.")

    # Compact ranked summary (up to top 5) — visible in Preparation log
    for r in all_micro[:5]:
        marker = " ← selected" if r.get("recommended_default") else ""
        log.append(
            f"  rank {r.get('microstate_rank','?')}: "
            f"score={float(r.get('selection_score',0)):.3f}  "
            f"charge={int(r.get('net_charge',0)):+d}  "
            f"{r.get('microstate_smiles','')}{marker}"
        )

    # ── Stage D: choose microstate for docking ───────────────────────────────
    selection_mode = (selection_mode or "auto_recommended").strip().lower()
    if selection_mode in {"auto", "recommended", "auto recommended"}:
        selection_mode = "auto_recommended"
    elif selection_mode in {"highest", "highest_score", "rank1", "rank_1"}:
        selection_mode = "highest_score"
    elif selection_mode in {"manual", "manual_rank"}:
        selection_mode = "manual_rank"

    # Identity policy 2026-11-14: score ranking is not permission to change heavy bonds.
    if selection_mode == "manual_rank":
        if manual_rank is None:
            raise ValueError("Manual microstate selection requires an explicit rank")
        best = next((r for r in all_micro if int(r.get("microstate_rank",-1)) == int(manual_rank)),None)
        if best is None:
            raise ValueError("Requested manual microstate rank is not available; no substitute selected")
        if not best.get("heavy_bond_graph_preserved",False):
            log.append("WARNING: manually selected different chemical microstate; not unchanged input identity")
    else:
        eligible = [r for r in all_micro if r.get("heavy_bond_graph_preserved") is True]
        if not eligible:
            raise RuntimeError("No candidate preserves the input heavy-atom bonds/stereochemistry; explicit review required")
        best = eligible[0] if selection_mode == "highest_score" else next((r for r in eligible if r.get("recommended_default")),eligible[0])
        if selection_mode != "highest_score": selection_mode = "auto_recommended"
    if "strict_input_identity" not in best:
        raise RuntimeError("Unpatched pKaNET engine: molecular identity metadata missing")

    best_smi = best["microstate_smiles"]
    charge = int(best["net_charge"])
    selected_rank = int(best.get("microstate_rank", 1))

    log.append(
        f"✓ pKaNET: ranked {len(all_micro)} microstates — "
        f"selected rank: {selected_rank}  "
        f"score: {float(best.get('selection_score', 0.0)):.3f}  "
        f"charge: {charge:+d}  "
        f"mode: {selection_mode}  "
        f"backend: {best.get('decision_backend', '?')} ({best.get('decision_mode', '?')})"
    )
    if selected_rank != 1:
        log.append(
            f"ℹ Rank-1 was not used for docking; conservative/manual selected rank {selected_rank}. "
            f"Reason: {best.get('recommendation_reason', 'user/auto selection')}"
        )
    log.append(f"✓ pKa source: {best.get('pKa_source', 'heuristic')}")

    if ambiguous:
        if len(top) > 1:
            log.append(f"⚠ Top assignment ambiguous — alt charge {int(top[1].get('net_charge', 0)):+d}")
        else:
            log.append("⚠ Top assignment ambiguous")

    if tr_flag:
        log.append(f"⚠ Tautomer-rich motifs: {', '.join(tr_motifs)}")
    if best.get("flag_amide_preserved"):
        log.append("✓ Amide bond preserved")
    if best.get("flag_imidic_acid_penalty"):
        log.append("⚠ Imidic-acid tautomer penalised")
    if best.get("flag_aromaticity_lost"):
        log.append("⚠ Aromaticity lost in top microstate")
    if best.get("is_zwitterion_strict"):
        log.append("✓ Zwitterion detected")
    if best.get("flag_borderline_pka"):
        log.append("⚠ Borderline pKa — protonation state uncertain near pH target")

    log.append(f"✓ Final pKaNET SMILES: {best_smi}")
    log.append(f"✓ Formal charge: {charge:+d}")

    # Safety check: charge must match the returned SMILES.
    mol = Chem.MolFromSmiles(best_smi)
    if mol is None:
        raise RuntimeError(f"pKaNET returned invalid SMILES: {best_smi}")
    actual_charge = int(Chem.GetFormalCharge(mol))
    if actual_charge != charge:
        log.append(
            f"⚠ Charge mismatch corrected: pKaNET reported {charge:+d}, "
            f"RDKit formal charge is {actual_charge:+d}"
        )
        charge = actual_charge

    details = {
        "identity_policy_version":"2026-11-14",
        "strict_input_identity":bool(best["strict_input_identity"]),
        "tautomer_changed":bool(best["tautomer_changed"]),
        "selection_mode": selection_mode,
        "stereo_choice": stereo_choice,
        "stereo_status": stereo_status,
        "selected_rank": int(best.get("microstate_rank", 1)),
        "selected_microstate": {k: v for k, v in best.items() if k != "charged_atom_rows"},
        "ranked_microstates": [{k: v for k, v in r.items() if k != "charged_atom_rows"} for r in all_micro],
        "top_microstates": [{k: v for k, v in r.items() if k != "charged_atom_rows"} for r in top],
        "ambiguous": bool(ambiguous),
        "tautomer_rich": bool(tr_flag),
        "tautomer_rich_motifs": tr_motifs,
        "pubchem_result": pubchem_result,
        "ml_predictions": ml_preds,
    }
    if return_details:
        return best_smi, charge, log, details
    return best_smi, charge, log



# ══════════════════════════════════════════════════════════════════════════════
#  LIGAND PREPARATION
# ══════════════════════════════════════════════════════════════════════════════


def _meeko_to_pdbqt(mol, out_path: str, *, atom_mapping=False, preserve_hydrogens=False):
    """Convert an RDKit mol to PDBQT via Meeko."""
    from meeko import MoleculePreparation
    prep = MoleculePreparation(**({"merge_these_atom_types": ()} if preserve_hydrogens else {}))
    if atom_mapping:
        # Keep the existing preparation model; request provenance from its writer.
        from meeko import PDBQTWriterLegacy
        setups = prep.prepare(mol, rename_atoms=False)
        if len(setups) != 1:
            raise ValueError("PDB mapping requires exactly one Meeko setup")
        setup = setups[0]
        pdbqt_str, success, error = PDBQTWriterLegacy.write_string(setup, add_index_map=True)
        if not success or not pdbqt_str.strip():
            raise ValueError(f"Meeko could not write ligand PDBQT: {error}")
        # Meeko 0.7.1's ligand writer omits insertion codes; restore only that
        # metadata through its explicit mapping, without altering tree or charges.
        serial_to_idx = {}
        for line in pdbqt_str.splitlines():
            if line.startswith("REMARK INDEX MAP "):
                values = list(map(int, line.split()[3:]))
                serial_to_idx.update({serial: idx - 1 for idx, serial in zip(values[::2], values[1::2])})
        lines = []
        for line in pdbqt_str.splitlines(keepends=True):
            if line.startswith(("ATOM  ", "HETATM")):
                idx = serial_to_idx.get(int(line[6:11]))
                if idx is not None and 0 <= idx < mol.GetNumAtoms():
                    info = mol.GetAtomWithIdx(idx).GetPDBResidueInfo()
                    if info is not None:
                        line = line[:26] + (info.GetInsertionCode() or " ") + line[27:]
            lines.append(line)
        Path(out_path).write_text("".join(lines))
        return setup
    try:
        from meeko import PDBQTWriterLegacy
        setups    = prep.prepare(mol)
        pdbqt_str, _, _ = PDBQTWriterLegacy.write_string(setups[0])
    except (ImportError, AttributeError):
        prep.prepare(mol)
        pdbqt_str = prep.write_pdbqt_string()
    with open(out_path, "w") as f:
        f.write(pdbqt_str)


def _ligand_charge_summary(smiles: str) -> dict:
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Bad SMILES: {smiles[:60]}")
    net = n_pos = n_neg = 0
    rows = []
    for atom in mol.GetAtoms():
        fc = int(atom.GetFormalCharge())
        net += fc
        if fc > 0:
            n_pos += 1
        elif fc < 0:
            n_neg += 1
        if fc != 0:
            rows.append({
                "atom_idx": atom.GetIdx(),
                "symbol": atom.GetSymbol(),
                "formal_charge": fc,
            })
    return {
        "net_charge": int(net),
        "charged_atoms": rows,
        "is_zwitterion": bool(n_pos > 0 and n_neg > 0 and net == 0),
    }

def _charged_atoms_text(rows: list) -> str:
    if not rows:
        return "none"
    return ", ".join(f"{r['symbol']}{r['atom_idx']}({r['formal_charge']:+d})" for r in rows)


def prepare_ligand(
    smiles: str,
    name: str,
    ph: float,
    wdir,
    mode: str = "pkanet",
    use_pubchem: bool = True,
    max_tautomers: int = 8,
    ph_window: float = 1.0,
    pkanet_selection_mode: str = "auto_recommended",
    pkanet_manual_rank: int | None = None,
    pkanet_stereo_choice: str = "keep_input",
    conformer_seed: int | None = None,
    *,
    allow_dimorphite_fallback: bool = False,
) -> dict:
    """
    Ligand preparation — pKaNET Cloud is the default protonation mode.

    Behavior:
      - pkanet     : full tautomer-aware microstate ranking via pKaNET.py (default)
      - neutral    : keep the input connectivity/charge state, add H only
      - dimorphite : protonate with Dimorphite-DL (legacy fallback, kept for compatibility)

    Charge reporting is always based on RDKit formal charge of the final SMILES
    actually used for 3D building and docking.
    pKaNET errors propagate unless allow_dimorphite_fallback is explicitly True.
    An opted-in fallback is marked degraded in the result and microstate CSV.
    """
    _rdkit_six_patch()
    from rdkit import Chem
    from rdkit.Chem import AllChem

    wdir      = Path(wdir)
    log       = []
    out_pdbqt = str(wdir / f"{name}.pdbqt")
    out_sdf   = str(wdir / f"{name}_3d.sdf")
    pkanet_error = None
    protonation_degraded = False
    protonation_backend = mode or "dimorphite"

    try:
        raw = smiles.strip()
        prot = raw
        pkanet_details = {}
        pkanet_ranked_csv = ""
        pkanet_decision_log = ""
        actual_mode = mode or "dimorphite"

        if actual_mode == "neutral":
            mol_check = Chem.MolFromSmiles(raw)
            if mol_check is None:
                raise ValueError(f"RDKit could not parse SMILES: {raw[:60]}")
            prot = Chem.MolToSmiles(mol_check, isomericSmiles=True, canonical=True)
            log.append("✓ Neutral mode (keep input charge state)")

        elif actual_mode == "pkanet":
            try:
                prot, _, pka_log, pkanet_details = protonate_pkanet(
                    raw, ph,
                    use_pubchem=use_pubchem,
                    max_tautomers=max_tautomers,
                    ph_window=ph_window,
                    selection_mode=pkanet_selection_mode,
                    manual_rank=pkanet_manual_rank,
                    stereo_choice=pkanet_stereo_choice,
                    return_details=True,
                )
                # Export ranked microstates and decision log for reproducibility/ESI.
                try:
                    import csv as _csv
                    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in str(name)) or "ligand"
                    pkanet_ranked_csv = str(wdir / f"{safe_name}_pkanet_ranked_microstates.csv")
                    rows = [dict(row, protonation_degraded=False, protonation_backend="pkanet")
                            for row in (pkanet_details.get("ranked_microstates", []) or [])]
                    if rows:
                        preferred = [
                            "microstate_rank", "recommended_default", "recommendation", "selection_score",
                            "delta_from_best", "net_charge", "microstate_smiles", "charged_atoms",
                            "pKa_source", "decision_backend", "decision_mode", "ambiguous_top_assignment",
                            "flag_heuristic_only", "flag_polyphenol_like", "flag_coumarin_like", "flag_flavonoid_like",
                            "flag_possible_overdeprotonation", "flag_borderline_pka", "flag_tautomer_rich",
                            "recommendation_reason",
                            "protonation_degraded", "protonation_backend",
                        ]
                        extra = sorted({k for r in rows for k in r.keys()} - set(preferred))
                        fieldnames = preferred + extra
                        with open(pkanet_ranked_csv, "w", newline="", encoding="utf-8") as fh:
                            wr = _csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
                            wr.writeheader(); wr.writerows(rows)
                    pkanet_decision_log = str(wdir / f"{safe_name}_pkanet_decision_log.txt")
                    with open(pkanet_decision_log, "w", encoding="utf-8") as fh:
                        fh.write("\n".join(pka_log))
                    log.append(f"✓ pKaNET ranked microstates exported: {pkanet_ranked_csv}")
                    log.append(f"✓ pKaNET decision log exported: {pkanet_decision_log}")
                except Exception as _csv_e:
                    log.append(f"⚠ Could not export pKaNET ranked table: {_csv_e}")
                log.extend(pka_log)
                log.append("✓ pKaNET Cloud protonation applied")
            except Exception as _pke:
                if not allow_dimorphite_fallback:
                    pkanet_error = _pke
                    raise
                log.append(f"⚠ pKaNET failed ({_pke}) — falling back to Dimorphite-DL")
                protonation_degraded = True
                protonation_backend = "dimorphite_fallback"
                actual_mode = "dimorphite"
                try:
                    from dimorphite_dl import protonate_smiles
                    _win = ph_window * 0.5
                    vs = protonate_smiles(
                        raw,
                        ph_min=ph - _win, ph_max=ph + _win,
                        max_variants=16,
                    )
                    if vs:
                        _vs_list = vs if isinstance(vs, list) else [vs]
                        # Prefer the state with the smallest absolute charge
                        # (avoids the Dimorphite bug of listing [n-] before neutral)
                        from rdkit import Chem as _Chem
                        def _abs_charge(s):
                            m = _Chem.MolFromSmiles(s)
                            return abs(int(_Chem.GetFormalCharge(m))) if m else 99
                        prot = min(_vs_list, key=lambda s: (_abs_charge(s), s))
                        log.append(
                            "WARNING: Dimorphite fallback candidate was chosen by a |charge| "
                            "heuristic, not pKa-derived ranking; ionised states may be discarded. "
                            "Ionizable-site correction is applied next, but this is not pKaNET."
                        )
                        log.append(
                            f"✓ Dimorphite-DL fallback pH {ph:.1f} "
                            f"(picked charge {_abs_charge(prot):+d} from {len(_vs_list)} variants)"
                        )
                    else:
                        raise RuntimeError("Dimorphite-DL fallback returned no protonation candidates")
                    prot = _apply_ionizable_site_correction(raw, prot, ph, log)
                except Exception as e2:
                    raise RuntimeError(f"Opted-in Dimorphite-DL fallback failed: {e2}") from e2

                import csv as _csv
                safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in str(name)) or "ligand"
                pkanet_ranked_csv = str(wdir / f"{safe_name}_pkanet_ranked_microstates.csv")
                fallback_row = {
                    "microstate_smiles": prot,
                    "net_charge": int(Chem.GetFormalCharge(Chem.MolFromSmiles(prot))),
                    "protonation_degraded": True,
                    "protonation_backend": protonation_backend,
                    "warning": "Fallback |charge| heuristic, not pKaNET/pKa-derived ranking",
                }
                with open(pkanet_ranked_csv, "w", newline="", encoding="utf-8") as fh:
                    writer = _csv.DictWriter(fh, fieldnames=list(fallback_row))
                    writer.writeheader()
                    writer.writerow(fallback_row)
                pkanet_decision_log = str(wdir / f"{safe_name}_pkanet_decision_log.txt")
                Path(pkanet_decision_log).write_text("\n".join(log), encoding="utf-8")

        else:
            # dimorphite (legacy compatibility)
            try:
                from dimorphite_dl import protonate_smiles
                _win = ph_window * 0.5
                vs = protonate_smiles(
                    prot,
                    ph_min=ph - _win, ph_max=ph + _win,
                    max_variants=16,
                )
                if vs:
                    _vs_list = vs if isinstance(vs, list) else [vs]
                    from rdkit import Chem as _Chem
                    def _abs_charge(s):
                        m = _Chem.MolFromSmiles(s)
                        return abs(int(_Chem.GetFormalCharge(m))) if m else 99
                    prot = min(_vs_list, key=_abs_charge)
                    log.append(f"✓ Dimorphite-DL pH {ph:.1f}")
                else:
                    log.append("⚠ Dimorphite-DL returned no variants — using input SMILES")
            except Exception as e:
                log.append(f"⚠ Dimorphite-DL skipped: {e}")
            prot = _apply_ionizable_site_correction(raw, prot, ph, log)

        mol = Chem.MolFromSmiles(prot)
        if mol is None:
            raise ValueError(f"RDKit could not parse SMILES: {prot[:60]}")

        charge_info = _ligand_charge_summary(prot)
        charge = int(charge_info["net_charge"])
        log.append(f"✓ Formal charge: {charge:+d}")
        log.append(f"✓ Charged atoms: {_charged_atoms_text(charge_info['charged_atoms'])}")

        mol = Chem.AddHs(mol)
        _requested_conformer_seed = (
            None if conformer_seed is None or int(conformer_seed) == 0
            else int(conformer_seed)
        )
        if _requested_conformer_seed is not None and _requested_conformer_seed < 0:
            raise ValueError("conformer_seed must be 0/random or a positive integer")
        if _requested_conformer_seed is None:
            import secrets as _secrets
            _conformer_seed = _secrets.randbelow(2_147_483_646) + 1
            _conformer_seed_mode = "random"
        else:
            _conformer_seed = _requested_conformer_seed
            _conformer_seed_mode = "fixed"
        log.append(
            f"✓ RDKit ETKDG conformer seed: {_conformer_seed} ({_conformer_seed_mode})"
        )
        try:
            params = AllChem.ETKDGv3()
        except AttributeError:
            params = AllChem.ETKDG()
        params.randomSeed = _conformer_seed

        if AllChem.EmbedMolecule(mol, params) == -1:
            _fallback = {"useRandomCoords": True}
            _fallback["randomSeed"] = _conformer_seed
            AllChem.EmbedMolecule(mol, **_fallback)

        if AllChem.MMFFHasAllMoleculeParams(mol):
            AllChem.MMFFOptimizeMolecule(mol, maxIters=500)
        else:
            AllChem.UFFOptimizeMolecule(mol, maxIters=500)
        log.append("✓ 3D conformer generated + minimised")

        with Chem.SDWriter(out_sdf) as w:
            w.write(mol)

        try:
            _meeko_to_pdbqt(mol, out_pdbqt)
            log.append("✓ PDBQT written (Meeko)")
        except Exception as e_meeko:
            log.append(f"⚠ Meeko failed ({e_meeko}), trying OpenBabel…")
            subprocess.run(
                ["obabel", out_sdf, "-O", out_pdbqt, "-xh"],
                capture_output=True, timeout=30,
            )
            if not Path(out_pdbqt).exists() or Path(out_pdbqt).stat().st_size < 10:
                raise ValueError(f"Both Meeko and OpenBabel failed: {e_meeko}")
            log.append("✓ PDBQT written (OpenBabel fallback)")

        return {
            "success":           True,
            "pdbqt":             out_pdbqt,
            "sdf":               out_sdf,
            "input_smiles":      raw,
            "prepared_smiles":   prot,
            "prot_smiles":       prot,
            "charge":            charge,
            "net_charge":        charge,
            "charge_method":     "rdkit_formal_charge",
            "charged_atoms":     charge_info["charged_atoms"],
            "is_zwitterion":     charge_info["is_zwitterion"],
            "protonation_mode":  actual_mode,
            "protonation_degraded": protonation_degraded,
            "protonation_backend": protonation_backend,
            "pkanet_selection_mode": pkanet_details.get("selection_mode", pkanet_selection_mode),
            "pkanet_selected_rank": pkanet_details.get("selected_rank"),
            "pkanet_selected_microstate": pkanet_details.get("selected_microstate", {}),
            "pkanet_ranked_microstates": pkanet_details.get("ranked_microstates", []),
            "pkanet_ranked_csv": pkanet_ranked_csv,
            "pkanet_decision_log": pkanet_decision_log,
            "pkanet_ambiguous": pkanet_details.get("ambiguous", False),
            "conformer_seed":    _conformer_seed,
            "conformer_seed_mode": _conformer_seed_mode,
            "log":               log,
        }

    except Exception as e:
        if e is pkanet_error:
            raise
        log.append(f"ERROR: {e}")
        return {"success": False, "error": str(e), "log": log,
                "protonation_degraded": protonation_degraded,
                "protonation_backend": protonation_backend}

def prepare_ligand_from_file(file_path: str, name: str, wdir,
                              add_h: bool = True,
                              conformer_seed: int | None = None) -> dict:
    """
    Prepare a ligand from a structure file (.sdf / .mol2 / .pdb / .pdbqt) for docking.

    Parameters
    ----------
    file_path : path to the ligand structure file
    name      : output file base-name
    wdir      : working directory for output files
    add_h     : if True  (default) — add missing hydrogen atoms before writing
                if False           — do not add H; Meeko still assigns types/charges
                PDB input also disables H merging to preserve existing atoms.
                Other formats retain default merging; torsion order may change.
                PDBQT inputs bypass preparation regardless of this option.
    """
    # Direct PDBQT must branch before any RDKit/Meeko/protonation operation.
    try:
        validated = validate_ligand_file(file_path)
    except ValueError as exc:
        return {"success": False, "error": str(exc), "log": [f"ERROR: {exc}"]}
    file_path = validated["path"]
    if Path(file_path).suffix.lower() == ".pdbqt":
        return {"success": True, "pdbqt": file_path, "sdf": None,
                "direct_pdbqt": True, "input_sha256": validated["input_sha256"],
                "input_atom_count": validated["atom_count"],
                "log": ["Ligand mode: direct PDBQT", f"Input path: {file_path}",
                        "No ligand preparation performed.", f"Input atoms: {validated['atom_count']}",
                        f"SHA256 input: {validated['input_sha256']}"]}
    _rdkit_six_patch()
    from rdkit import Chem
    from rdkit.Chem import AllChem

    wdir      = Path(wdir)
    wdir.mkdir(parents=True, exist_ok=True)
    log       = []
    out_pdbqt = str(wdir / f"{name}.pdbqt")
    out_sdf   = str(wdir / f"{name}_3d.sdf")
    ext       = Path(file_path).suffix.lower()

    original_atoms = None
    report_path = str(wdir / "atom_mapping.tsv")
    mapping_summary = None
    try:
        mol = None
        if ext == ".sdf":
            supp = Chem.SDMolSupplier(file_path, removeHs=False, sanitize=True)
            mols = [m for m in supp if m]
            if not mols:
                supp = Chem.SDMolSupplier(file_path, removeHs=False, sanitize=False)
                mols = [m for m in supp if m]
            if mols:
                mol = mols[0]
        elif ext == ".pdb":
            original_text = Path(file_path).read_text()
            original_atoms = read_atom_records(original_text)
            write_mapping_report(report_path, [mapping_row(a) for a in original_atoms])
            if sum(line.startswith("MODEL") for line in original_text.splitlines()) > 1:
                raise ValueError("PDB ligand contains multiple models; select one before preparation")
            if any(a["altloc"] for a in original_atoms):
                raise ValueError("PDB alternate locations require an explicit single-conformer input; refusing to drop atoms")
            mol = Chem.MolFromPDBFile(file_path, removeHs=False, sanitize=True)
            if mol is None:
                mol = Chem.MolFromPDBFile(file_path, removeHs=False, sanitize=False)
            log.append("Ligand mode: " + ("standard PDB preparation" if add_h else "PDB conversion through existing ligand preparation"))
            log.append("PDB reader: RDKit; PDBQT writer: existing _meeko_to_pdbqt (no Open Babel)")
        elif ext == ".mol2":
            _ob_sdf = str(wdir / f"{name}_ob.sdf")
            subprocess.run(
                ["obabel", file_path, "-O", _ob_sdf],
                capture_output=True, timeout=30,
            )
            if Path(_ob_sdf).exists() and Path(_ob_sdf).stat().st_size > 10:
                supp = Chem.SDMolSupplier(_ob_sdf, removeHs=False, sanitize=True)
                mols = [m for m in supp if m]
                if not mols:
                    supp = Chem.SDMolSupplier(_ob_sdf, removeHs=False, sanitize=False)
                    mols = [m for m in supp if m]
                if mols:
                    mol = mols[0]
                    log.append("✓ Converted via OpenBabel")
            if mol is None:
                mol = Chem.MolFromMol2File(file_path, removeHs=False, sanitize=True)
                if mol is None:
                    mol = Chem.MolFromMol2File(file_path, removeHs=False, sanitize=False)

        if mol is None:
            raise ValueError(f"Could not read molecule from {Path(file_path).name}")

        frags = Chem.GetMolFrags(mol, asMols=True, sanitizeFrags=False)
        if len(frags) > 1:
            if ext == ".pdb":
                raise ValueError("PDB ligand has disconnected fragments; refusing to silently drop atoms")
            frags = sorted(frags, key=lambda m: m.GetNumAtoms(), reverse=True)
            mol = frags[0]
            log.append(f"⚠ {len(frags)} fragments — kept largest ({mol.GetNumAtoms()} atoms)")

        try:
            Chem.SanitizeMol(mol)
        except Exception:
            pass

        if original_atoms is not None:
            import math
            if mol.GetNumAtoms() != len(original_atoms):
                raise ValueError(f"PDB atom mapping failed during reading: input {len(original_atoms)}, read {mol.GetNumAtoms()}")
            if mol.GetNumConformers() != 1:
                raise ValueError("PDB atom mapping requires exactly one coordinate set")
            for original, atom in zip(original_atoms, mol.GetAtoms()):
                info = atom.GetPDBResidueInfo()
                point = mol.GetConformer().GetAtomPosition(atom.GetIdx())
                if (info is None or info.GetSerialNumber() != original["serial"]
                        or info.GetName().strip() != original["atom_name"]
                        or info.GetResidueName().strip() != original["resname"]
                        or info.GetResidueNumber() != original["resnum"]
                        or info.GetChainId().strip() != original["chain"]
                        or info.GetInsertionCode().strip() != original["icode"]
                        or math.dist(original["xyz"], (point.x, point.y, point.z)) > 0.000001):
                    raise ValueError(f"PDB atom identity/order/coordinates changed while reading atom {original['index']} ({original['atom_name']})")
                expected_element = original["element"].upper()
                actual_element = ("D" if atom.GetAtomicNum() == 1 and atom.GetIsotope() == 2 else
                                  "T" if atom.GetAtomicNum() == 1 and atom.GetIsotope() == 3 else atom.GetSymbol().upper())
                if expected_element and expected_element != actual_element:
                    raise ValueError(f"Input element changed at atom {original['index']}")
                formal = original["formal_charge"]
                if formal and (not _re.fullmatch(r"[0-9][+-]", formal) or
                               atom.GetFormalCharge() != int(formal[0]) * (1 if formal[1] == "+" else -1)):
                    raise ValueError(f"Input formal charge could not be preserved at atom {original['index']}")
        log.append("✓ Loaded molecule from file (no protonation)")

        try:
            smi = Chem.MolToSmiles(Chem.RemoveHs(mol))
        except Exception:
            try:
                smi = Chem.MolToSmiles(mol)
            except Exception:
                smi = name
        try:
            charge = Chem.GetFormalCharge(mol)
        except Exception:
            charge = 0
        log.append(f"✓ Formal charge: {charge:+d}")

        if add_h:
            mol = Chem.AddHs(mol, addCoords=True)
            log.append("✓ Hydrogens added (addCoords=True)")
        else:
            log.append("✓ Skipping H addition (--no-add-h); PDBQT typing/charge preparation still applies")

        if original_atoms is not None:
            # RDKit-generated H atoms have no original PDB identity. Give them
            # unique names and their bonded parent's residue, without renaming originals.
            used_names = {a["atom_name"] for a in original_atoms}
            next_h = 1
            for atom in list(mol.GetAtoms())[len(original_atoms):]:
                if atom.GetAtomicNum() != 1 or len(atom.GetNeighbors()) != 1:
                    raise ValueError("Unexpected generated atom during PDB hydrogen addition")
                while f"H{next_h}" in used_names:
                    next_h += 1
                new_name = f"H{next_h}"
                if len(new_name) > 4:
                    raise ValueError("Generated H names exceed PDB field width")
                used_names.add(new_name)
                parent = atom.GetNeighbors()[0].GetPDBResidueInfo()
                if parent is None:
                    raise ValueError("Generated H has no uniquely identified parent residue")
                info = Chem.AtomPDBResidueInfo()
                info.SetName(new_name.rjust(4))
                info.SetResidueName(parent.GetResidueName())
                info.SetResidueNumber(parent.GetResidueNumber())
                info.SetChainId(parent.GetChainId())
                info.SetInsertionCode(parent.GetInsertionCode())
                info.SetIsHeteroAtom(parent.GetIsHeteroAtom())
                atom.SetMonomerInfo(info)
            # Planar PDB coordinates are valid coordinates; don't regenerate them.
            mol.GetConformer().Set3D(True)
        _requested_conformer_seed = (
            None if conformer_seed is None or int(conformer_seed) == 0
            else int(conformer_seed)
        )
        if _requested_conformer_seed is not None and _requested_conformer_seed < 0:
            raise ValueError("conformer_seed must be 0/random or a positive integer")
        _conformer_seed = None
        _conformer_seed_mode = "not_used"

        conf = mol.GetConformer(0) if mol.GetNumConformers() > 0 else None
        if conf is None or conf.Is3D() is False:
            if not add_h:
                log.append("⚠ No 3D conformer found — generating one (required for PDBQT)")
            if _requested_conformer_seed is None:
                import secrets as _secrets
                _conformer_seed = _secrets.randbelow(2_147_483_646) + 1
                _conformer_seed_mode = "random"
            else:
                _conformer_seed = _requested_conformer_seed
                _conformer_seed_mode = "fixed"
            try:
                params = AllChem.ETKDGv3()
            except AttributeError:
                params = AllChem.ETKDG()
            log.append(
                f"✓ RDKit ETKDG conformer seed: {_conformer_seed} ({_conformer_seed_mode})"
            )
            params.randomSeed = _conformer_seed
            if AllChem.EmbedMolecule(mol, params) == -1:
                _fallback = {"useRandomCoords": True}
                _fallback["randomSeed"] = _conformer_seed
                AllChem.EmbedMolecule(mol, **_fallback)
            if AllChem.MMFFHasAllMoleculeParams(mol):
                AllChem.MMFFOptimizeMolecule(mol, maxIters=500)
            else:
                AllChem.UFFOptimizeMolecule(mol, maxIters=500)
            log.append("✓ 3D conformer generated")
        else:
            log.append("✓ Using 3D coordinates from file")

        with Chem.SDWriter(out_sdf) as w:
            w.write(mol)

        try:
            if original_atoms is not None:
                setup = _meeko_to_pdbqt(mol, out_pdbqt, atom_mapping=True, preserve_hydrogens=not add_h)
                mapping_summary = validate_pdb_mapping(original_atoms, mol, setup, out_pdbqt, report_path, preserve_atom_set=not add_h)
                log.extend([
                    f"Hydrogen addition: {'enabled' if add_h else 'disabled'}",
                    f"Input atom count: {mapping_summary['input_atoms']}",
                    f"Output mapped original atom count: {mapping_summary['mapped_original_atoms']}",
                    f"Output total atom count: {mapping_summary['output_atoms']}",
                    f"Added hydrogens: {mapping_summary['added_hydrogens']}",
                    f"Original nonpolar H merged by Meeko: {mapping_summary['merged_original_h']}",
                    f"Atom-name mapping: PASS (original labels restored: {mapping_summary['restored_names']}; final renamed original atoms: 0)",
                    "Atom-order mapping: PASS" + (" — explicit Meeko torsion-tree reordering; see INDEX MAP and report" if mapping_summary['reordered'] else " — preserved"),
                    "Residue-name/number/chain mapping: PASS", "Coordinates: PASS (PDBQT rounding tolerance 0.0011 Å)",
                    "Charges: input formal charges retained in RDKit; Meeko generates Gasteiger partial charges",
                    "Meeko hydrogen merging: " + ("default (reported above)" if add_h else "disabled; original atom set preserved"),
                    f"Atom mapping report: {report_path}",
                ])
            else:
                _meeko_to_pdbqt(mol, out_pdbqt)
            log.append("✓ PDBQT written (Meeko)")
        except Exception as e_meeko:
            if original_atoms is not None:
                raise ValueError(f"PDB ligand preparation/mapping failed: {e_meeko}. No Open Babel fallback; docking was not started.") from e_meeko
            log.append(f"⚠ Meeko failed ({e_meeko}), trying OpenBabel…")
            subprocess.run(
                ["obabel", out_sdf, "-O", out_pdbqt, "-xh"],
                capture_output=True, timeout=30,
            )
            if not Path(out_pdbqt).exists() or Path(out_pdbqt).stat().st_size < 10:
                raise ValueError(f"Both Meeko and OpenBabel failed: {e_meeko}")
            log.append("✓ PDBQT written (OpenBabel fallback)")

        return {
            "success":     True,
            "pdbqt":       out_pdbqt,
            "sdf":         out_sdf,
            "prot_smiles": smi,
            "charge":      charge,
            "atom_mapping_report": report_path if original_atoms is not None else None,
            "atom_mapping": mapping_summary,
            "conformer_seed": _conformer_seed,
            "conformer_seed_mode": _conformer_seed_mode,
            "log":         log,
        }
    except Exception as e:
        if original_atoms is not None:
            import csv
            with open(report_path) as report:
                rows = list(csv.DictReader(report, delimiter="\t"))
            for row in rows:
                if row["mapping_status"] == "not_prepared":
                    row.update(mapping_status="FAIL", reason=str(e))
            write_mapping_report(report_path, rows)
            log.append(f"Atom mapping report: {report_path}")
        log.append(f"ERROR: {e}")
        return {"success": False, "error": str(e), "log": log}


def smiles_from_file(file_path: str, wdir) -> str:
    wdir = Path(wdir)
    ext  = Path(file_path).suffix.lower()
    if ext == ".sdf":
        from rdkit import Chem
        mols = [m for m in Chem.SDMolSupplier(file_path, sanitize=True) if m]
        if not mols:
            raise ValueError("No valid molecule in SDF file")
        return Chem.MolToSmiles(mols[0])
    else:
        smi_tmp = str(wdir / "lig_upload.smi")
        run_cmd(f'obabel "{file_path}" -O "{smi_tmp}" --canonical {_NULL}')
        for line in open(smi_tmp):
            pts = line.strip().split(None, 1)
            if pts:
                return pts[0]
        raise ValueError("Could not convert structure file to SMILES")


# ══════════════════════════════════════════════════════════════════════════════
#  CO-CRYSTAL LIGAND  —  SMILES ACQUISITION
# ══════════════════════════════════════════════════════════════════════════════

def _rcsb_ccd_smiles(resname: str):
    """
    Fetch canonical SMILES for a PDB Chemical Component (3-letter code)
    from the RCSB Chemical Component Dictionary (CCD) REST API.

    Priority: typed ``SMILES_CANONICAL`` CCD descriptors, with a stable
    CACTVS/OpenEye program preference.  The RCSB summary object's
    ``SMILES_stereo`` and ``SMILES`` convenience fields are intentionally not
    used, so every environment consumes the same canonical CCD representation.

    Returns the SMILES string on success, None on any failure (network error,
    unknown residue, missing descriptor field).
    """
    import requests
    url = (
        f"https://data.rcsb.org/rest/v1/core/chemcomp/"
        f"{resname.strip().upper()}"
    )
    try:
        r = requests.get(url, timeout=10)
        if r.status_code != 200:
            return None
        data = r.json()
        descriptors = data.get("pdbx_chem_comp_descriptor", [])
        if isinstance(descriptors, dict):
            descriptors = [descriptors]

        canonical_by_program: dict = {}
        for item in descriptors:
            t = (item.get("type") or "").upper()
            d = (item.get("descriptor") or "").strip()
            program = (item.get("program") or "").strip().lower()
            if d and t == "SMILES_CANONICAL":
                canonical_by_program.setdefault(program, d)

        program_priority = ("cactvs", "openeye oetoolkits", "acdlabs")
        for program in program_priority:
            if program in canonical_by_program:
                return canonical_by_program[program]
        if canonical_by_program:
            return canonical_by_program[sorted(canonical_by_program)[0]]
        return None
    except Exception:
        return None


def _smiles_from_cif_block(cif_path: str, resname: str):
    """
    Extract SMILES from the ``_chem_comp.pdbx_smiles`` field of an mmCIF
    structure file.

    Handles three CIF layouts:

    *  **loop_** block  — a table whose header contains ``_chem_comp.id`` and
       ``_chem_comp.pdbx_smiles``.  We find the row whose ``id`` matches
       *resname* (exact) **or** starts with ``resname + "_"`` (e.g. ``LIG_B``
       for resname ``LIG``).
    *  **Inline single-value** — ``_chem_comp.pdbx_smiles   <value>`` on the
       same line (horizontal whitespace only between key and value).
    *  **Two-line single-value** — key on one line, value token on the next
       (but NOT another ``_``-key or a ``;``-block start).

    Returns the SMILES string on success, None otherwise.
    Ignores placeholder values ``"."`` and ``"?"``.
    """
    target = resname.strip().upper()
    try:
        with open(cif_path, errors="replace") as fh:
            content = fh.read()

        # ── Strategy A: loop_ containing _chem_comp columns ──────────────
        loop_pat = _re.compile(
            r"loop_\s*((?:_chem_comp\.\S+\s*)+)(.*?)(?=loop_|data_|\Z)",
            _re.DOTALL,
        )
        for m in loop_pat.finditer(content):
            header_block = m.group(1)
            data_block   = m.group(2)
            headers = header_block.split()
            if "_chem_comp.id" not in headers:
                continue
            if "_chem_comp.pdbx_smiles" not in headers:
                continue
            id_idx  = headers.index("_chem_comp.id")
            smi_idx = headers.index("_chem_comp.pdbx_smiles")
            n       = len(headers)
            tokens  = _re.findall(r"'[^']*'|\"[^\"]*\"|[^\s]+", data_block)
            for i in range(0, len(tokens) - n + 1, n):
                row = tokens[i : i + n]
                if len(row) < n:
                    break
                comp_id = row[id_idx].strip("'\"").upper()
                # Exact match OR prefix match: "LIG_B" → target "LIG"
                if comp_id == target or comp_id.startswith(target + "_"):
                    smi = row[smi_idx].strip("'\"")
                    if smi and smi not in (".", "?"):
                        return smi

        # ── Strategy B: inline single-value (same line, no newline allowed) ──
        # Use [ \t]+ (horizontal whitespace only) to stop at end of line so
        # we never accidentally capture the next field name on the line below.
        m = _re.search(
            r"_chem_comp\.pdbx_smiles[ \t]+([^\s#][^\r\n]*)", content
        )
        if m:
            smi = m.group(1).strip().strip("'\"")
            if smi and smi not in (".", "?"):
                return smi

        # ── Strategy C: two-line single-value  ────────────────────────────
        # key on one line, plain value token on the very next non-empty line,
        # but only if that line does NOT start with another key (_), a
        # comment (#), or a semicolon-block (;).
        m = _re.search(
            r"_chem_comp\.pdbx_smiles\s*\r?\n[ \t]*([^_#;\s][^\r\n]*)",
            content,
        )
        if m:
            smi = m.group(1).strip().strip("'\"")
            if smi and smi not in (".", "?"):
                return smi

        # ── Strategy D: semicolon text block ─────────────────────────────
        # _chem_comp.pdbx_smiles
        # ;
        # <value>
        # ;
        m = _re.search(
            r"_chem_comp\.pdbx_smiles\s*\r?\n;\r?\n([^\n]+)\r?\n;",
            content,
        )
        if m:
            smi = m.group(1).strip().strip("'\"")
            if smi and smi not in (".", "?"):
                return smi

    except Exception:
        pass
    return None


def _extract_ligand_pdb_from_cif(cif_path: str, cocrystal_ligand_id: str, out_pdb_path: str) -> bool:
    """
    Extract one ligand residue directly from an mmCIF/_atom_site loop into a
    simple PDB file that Open Babel/RDKit can read for 3D -> SMILES fallback.

    This is specifically for ModelCIF/mmCIF inputs that contain ligand
    coordinates but no `_chem_comp.pdbx_smiles` / CCD descriptor block.
    """
    resname, chain, resid = _parse_ligand_id(cocrystal_ligand_id)
    if not (cif_path and is_cif_file(cif_path) and os.path.exists(cif_path) and resname):
        return False

    target_resname = resname.strip().upper()
    target_chain = (chain or "").strip()
    target_resid = str(resid).strip()

    try:
        with open(cif_path, errors="replace") as fh:
            content = fh.read()

        loop_pat = _re.compile(
            r"loop_\s*((?:_atom_site\.\S+\s*)+)(.*?)(?=loop_|data_|\Z)",
            _re.DOTALL,
        )
        atom_lines = []

        for m in loop_pat.finditer(content):
            headers = m.group(1).split()
            if "_atom_site.group_PDB" not in headers:
                continue

            def _idx(name):
                return headers.index(name) if name in headers else None

            group_idx = _idx("_atom_site.group_PDB")
            type_idx = _idx("_atom_site.type_symbol")
            atom_idx = _idx("_atom_site.label_atom_id")
            label_comp_idx = _idx("_atom_site.label_comp_id")
            auth_comp_idx = _idx("_atom_site.auth_comp_id")
            label_asym_idx = _idx("_atom_site.label_asym_id")
            auth_asym_idx = _idx("_atom_site.auth_asym_id")
            label_seq_idx = _idx("_atom_site.label_seq_id")
            auth_seq_idx = _idx("_atom_site.auth_seq_id")
            x_idx = _idx("_atom_site.Cartn_x")
            y_idx = _idx("_atom_site.Cartn_y")
            z_idx = _idx("_atom_site.Cartn_z")
            occ_idx = _idx("_atom_site.occupancy")
            b_idx = _idx("_atom_site.B_iso_or_equiv")
            id_idx = _idx("_atom_site.id")
            if None in (group_idx, type_idx, atom_idx, x_idx, y_idx, z_idx):
                continue

            n = len(headers)
            serial = 1
            for raw_line in m.group(2).splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or line.startswith("_"):
                    continue
                row = _re.findall(r"'[^']*'|\"[^\"]*\"|[^\s]+", raw_line)
                if len(row) < n:
                    continue
                if row[group_idx].strip("'\"").upper() not in {"ATOM", "HETATM"}:
                    continue

                comp_id = ""
                for idx in (auth_comp_idx, label_comp_idx):
                    if idx is not None:
                        value = row[idx].strip("'\"").upper()
                        if value and value not in {".", "?"}:
                            comp_id = value
                            break
                if not comp_id or comp_id != target_resname:
                    continue

                row_chain = ""
                for idx in (auth_asym_idx, label_asym_idx):
                    if idx is not None:
                        value = row[idx].strip("'\"")
                        if value and value not in {".", "?"}:
                            row_chain = value
                            break
                if target_chain and row_chain != target_chain:
                    continue

                row_resid = ""
                for idx in (auth_seq_idx, label_seq_idx):
                    if idx is not None:
                        value = row[idx].strip("'\"")
                        if value and value not in {".", "?"}:
                            try:
                                row_resid = str(int(float(value)))
                            except Exception:
                                row_resid = value
                            break
                if target_resid and row_resid and row_resid != target_resid:
                    continue

                try:
                    atom_serial = int(float(row[id_idx].strip("'\""))) if id_idx is not None else serial
                except Exception:
                    atom_serial = serial
                serial += 1

                atom_name = row[atom_idx].strip("'\"")
                element = row[type_idx].strip("'\"").upper()[:2]
                x = float(row[x_idx].strip("'\""))
                y = float(row[y_idx].strip("'\""))
                z = float(row[z_idx].strip("'\""))
                occ = 1.0
                if occ_idx is not None:
                    try:
                        occ = float(row[occ_idx].strip("'\""))
                    except Exception:
                        pass
                bfac = 20.0
                if b_idx is not None:
                    try:
                        bfac = float(row[b_idx].strip("'\""))
                    except Exception:
                        pass

                atom_lines.append(
                    f"HETATM{atom_serial:5d} {atom_name[:4]:<4} {target_resname[:3]:>3} "
                    f"{(row_chain or target_chain or 'A')[:1]}{int(float(row_resid or target_resid or '1')):4d}    "
                    f"{x:8.3f}{y:8.3f}{z:8.3f}{occ:6.2f}{bfac:6.2f}          {element:>2}\n"
                )

            if atom_lines:
                break

        if not atom_lines:
            return False

        with open(out_pdb_path, "w") as fh:
            fh.writelines(atom_lines)
            fh.write("END\n")
        return os.path.exists(out_pdb_path) and os.path.getsize(out_pdb_path) > 20
    except Exception:
        return False


def get_cocrystal_smiles(
    ligand_pdb_path: str,
    cocrystal_ligand_id: str,
    raw_pdb: str = "",
) -> tuple:
    """
    Return ``(smiles, source, warning)`` for the extracted co-crystal ligand.

    Acquisition strategy (in priority order):

    1. **RCSB CCD REST API** — ideal, stereo-correct, curated SMILES.
       Uses the 3-letter residue code parsed from *cocrystal_ligand_id*
       (format ``RESNAME_CHAIN_RESID``).

    2. **CIF _chem_comp.pdbx_smiles** — parsed directly from the structure
       CIF if *raw_pdb* is a CIF file.  No network call required.

    3. **3D → SMILES conversion** (last resort) — RDKit reads the extracted
       ``LIG.pdb``.  PDB format carries no bond-order information, so
       aromatic/double-bond assignment is heuristic and may be wrong for
       complex ligands.  A warning is always attached to this source.

    Returns
    -------
    smiles  : str — SMILES string, empty on total failure.
    source  : str — ``"rcsb_ccd"`` | ``"cif_block"`` | ``"3d_conversion"`` | ``""``.
    warning : str — non-empty when the result may be unreliable, or on failure.
    """
    resname, _, _ = _parse_ligand_id(cocrystal_ligand_id)

    # ── 1. RCSB CCD ──────────────────────────────────────────────────────
    if resname:
        try:
            smi = _rcsb_ccd_smiles(resname)
            if smi:
                return smi, "rcsb_ccd", ""
        except Exception:
            pass

    # ── 2. CIF embedded block ────────────────────────────────────────────
    if raw_pdb and is_cif_file(raw_pdb) and resname:
        try:
            smi = _smiles_from_cif_block(raw_pdb, resname)
            if smi:
                return smi, "cif_block", ""
        except Exception:
            pass

    # ── 3. 3D → SMILES from extracted LIG.pdb (last resort) ─────────────
    #
    # Why this is hard:
    #   Crystal PDB files carry no explicit bond-order information — bonds are
    #   inferred from inter-atomic distances.  Without hydrogen atoms present,
    #   valence clues are missing, so RDKit's sanitiser often assigns wrong
    #   bond orders (e.g. all-single aromatic rings, missed double bonds).
    #
    # Fix:
    #   A. Use OpenBabel to convert PDB → SDF *with hydrogen addition* (-h).
    #      Obabel adds H first, then perceives bond orders — much more
    #      reliable than reading the bare PDB.  Read the SDF with RDKit to
    #      get a clean canonical SMILES.
    #   B. RDKit fallback: read PDB with removeHs=False so H are present
    #      during sanitisation; try DetermineBonds (RDKit ≥ 2022.09) before
    #      falling back to standard SanitizeMol; only strip H for the final
    #      SMILES step.

    warn_3d = (
        "SMILES was derived from 3D coordinates (PDB has no bond-order data). "
        "Bond orders were inferred heuristically — verify the structure, "
        "especially for aromatic rings or unusual valences, before trusting "
        "docking scores."
    )

    _ligand_pdb_candidates = []
    if ligand_pdb_path and os.path.exists(ligand_pdb_path):
        _ligand_pdb_candidates.append(ligand_pdb_path)
    if raw_pdb and is_cif_file(raw_pdb) and cocrystal_ligand_id:
        try:
            import tempfile
            with tempfile.NamedTemporaryFile(suffix=".pdb", delete=False) as tf:
                _tmp_ligand_pdb = tf.name
            if _extract_ligand_pdb_from_cif(raw_pdb, cocrystal_ligand_id, _tmp_ligand_pdb):
                _ligand_pdb_candidates.append(_tmp_ligand_pdb)
        except Exception:
            pass

    for _fallback_ligand_pdb in _ligand_pdb_candidates:
        _rdkit_six_patch()
        from rdkit import Chem

        # ── A. OpenBabel PDB → SDF (adds H, then perceives bonds) ────────
        # This is the most reliable path: obabel adds H before bond
        # perception, so valence information guides the assignment.
        try:
            import tempfile, os as _os
            with tempfile.NamedTemporaryFile(
                suffix=".sdf", delete=False
            ) as tf:
                ob_sdf = tf.name
            # -h  : add hydrogens
            # -p 7.4 : at physiological pH so protonation state is sensible
            rc, _ = run_cmd(
                ["obabel", _fallback_ligand_pdb, "-O", ob_sdf, "-h", "-p", "7.4"]
            )
            if rc == 0 and _os.path.exists(ob_sdf) and _os.path.getsize(ob_sdf) > 10:
                supp = Chem.SDMolSupplier(ob_sdf, removeHs=False, sanitize=True)
                mols = [m for m in supp if m is not None]
                if not mols:
                    supp = Chem.SDMolSupplier(ob_sdf, removeHs=False, sanitize=False)
                    mols = [m for m in supp if m is not None]
                if mols:
                    mol = mols[0]
                    try:
                        mol_noh = Chem.RemoveHs(mol)
                        smi = Chem.MolToSmiles(mol_noh, isomericSmiles=True)
                    except Exception:
                        smi = Chem.MolToSmiles(mol, isomericSmiles=True)
                    if smi:
                        return smi, "3d_conversion", warn_3d
        except Exception:
            pass

        # ── B. RDKit with H kept during sanitisation ──────────────────────
        # Read with removeHs=False so H atoms provide valence clues.
        # Try the modern DetermineBonds API first (RDKit >= 2022.09),
        # which uses a distance+charge model and is far more accurate than
        # the legacy distance-only sanitiser.
        try:
            mol = Chem.MolFromPDBFile(
                _fallback_ligand_pdb, removeHs=False, sanitize=False
            )
            if mol is not None:
                bonded = False

                # DetermineBonds (RDKit >= 2022.09)
                try:
                    from rdkit.Chem import DetermineBonds
                    DetermineBonds(mol, charge=0)
                    bonded = True
                except (ImportError, Exception):
                    pass

                if not bonded:
                    try:
                        Chem.SanitizeMol(mol)
                        bonded = True
                    except Exception:
                        # Partial sanitisation: keep going with what we have
                        try:
                            Chem.SanitizeMol(
                                mol,
                                Chem.SanitizeFlags.SANITIZE_ALL
                                ^ Chem.SanitizeFlags.SANITIZE_PROPERTIES,
                            )
                            bonded = True
                        except Exception:
                            pass

                if bonded or mol.GetNumAtoms() > 0:
                    try:
                        mol_noh = Chem.RemoveHs(mol, sanitize=False)
                        Chem.SanitizeMol(mol_noh)
                        smi = Chem.MolToSmiles(mol_noh, isomericSmiles=True)
                    except Exception:
                        smi = Chem.MolToSmiles(mol, isomericSmiles=True)
                    if smi:
                        return smi, "3d_conversion", warn_3d
        except Exception:
            pass

        # ── C. OpenBabel direct → SMILES (last-ditch) ────────────────────
        try:
            import tempfile
            with tempfile.NamedTemporaryFile(
                suffix=".smi", delete=False
            ) as tf:
                smi_tmp = tf.name
            rc, _ = run_cmd(
                ["obabel", _fallback_ligand_pdb, "-O", smi_tmp, "-h", "--canonical"]
            )
            if rc == 0 and os.path.exists(smi_tmp):
                for line in open(smi_tmp):
                    pts = line.strip().split(None, 1)
                    if pts and pts[0]:
                        return pts[0], "3d_conversion", warn_3d
        except Exception:
            pass

    return "", "", (
        f"Could not obtain SMILES for co-crystal ligand "
        f"'{resname or cocrystal_ligand_id}'. "
        "All strategies failed: RCSB CCD, CIF block, "
        "OpenBabel PDB→SDF, RDKit DetermineBonds, OpenBabel direct."
    )


# ══════════════════════════════════════════════════════════════════════════════
#  DOCKING  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

def run_vina(
    receptor_pdbqt: str,
    ligand_pdbqt: str,
    config_txt: str,
    vina_path: str,
    exhaustiveness: int = 8,
    n_modes: int = 10,
    energy_range: int = 3,
    wdir = ".",
    out_name: str = "out",
    seed: int | None = None,
    ligand_input_sha256: str | None = None,
) -> dict:
    wdir      = Path(wdir)
    out_pdbqt = str(wdir / f"{out_name}_out.pdbqt")
    out_sdf   = str(wdir / f"{out_name}_out.sdf")

    if ligand_input_sha256 is not None:
        try:
            checked = validate_ligand_file(ligand_pdbqt)
            if checked.get("input_sha256") != ligand_input_sha256 or file_sha256(ligand_pdbqt) != ligand_input_sha256:
                raise ValueError("Input PDBQT checksum changed. Docking was not started.")
            if Path(ligand_pdbqt).resolve() in (Path(out_pdbqt).resolve(), Path(out_sdf).resolve()):
                raise ValueError("Vina output would overwrite the original PDBQT. Choose a different --name or --output.")
            print(f"SHA256 Vina ligand: {checked['input_sha256']}")
            print("Input PDBQT checksum verified.")
            print("Passing original PDBQT directly to AutoDock Vina.")
        except (ValueError, OSError) as exc:
            return {"success": False, "error": str(exc), "log": "Docking was not started."}

    # --seed: when set, makes docking deterministic for the same input.
    _seed_flag = f" --seed {int(seed)}" if seed is not None else ""

    rc, vlog = run_cmd(
        f'"{vina_path}" '
        f'--receptor "{receptor_pdbqt}" '
        f'--ligand "{ligand_pdbqt}" '
        f'--config "{config_txt}" '
        f'--exhaustiveness {exhaustiveness} '
        f'--num_modes {n_modes} '
        f'--energy_range {energy_range}'
        f'{_seed_flag} '
        f'--out "{out_pdbqt}"',
        cwd=str(wdir),
    )

    if rc != 0 or not os.path.exists(out_pdbqt):
        return {"success": False, "error": f"Vina exit code {rc}", "log": vlog}

    run_cmd(f'obabel "{out_pdbqt}" -O "{out_sdf}" 2>/dev/null')

    scores    = []
    cur_model = None
    for line in open(out_pdbqt):
        ln = line.strip()
        if ln.startswith("MODEL"):
            try:
                cur_model = int(ln.split()[1])
            except Exception:
                pass
        elif ln.startswith("REMARK VINA RESULT:"):
            try:
                p = ln.split()
                scores.append({
                    "pose":     cur_model,
                    "affinity": float(p[3]),
                    "rmsd_lb":  float(p[4]),
                    "rmsd_ub":  float(p[5]),
                })
            except Exception:
                pass

    return {
        "success":   True,
        "out_pdbqt": out_pdbqt,
        "out_sdf":   out_sdf,
        "scores":    scores,
        "top_score": scores[0]["affinity"] if scores else None,
        "seed":      int(seed) if seed is not None else None,
        "log":       vlog,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  BOND ORDER CORRECTION  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

def _bo_template(smiles: str):
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        mol = Chem.MolFromSmiles(smiles, sanitize=False)
        if mol is None:
            raise ValueError(f"Cannot parse SMILES: {smiles!r}")
        try:
            mol.UpdatePropertyCache(strict=False)
            Chem.FastFindRings(mol)
            Chem.SetAromaticity(mol)
        except Exception:
            pass
    try:
        Chem.Kekulize(mol, clearAromaticFlags=True)
    except Exception:
        pass
    return mol


def _bo_fix_mol(probe, template):
    from rdkit import Chem
    from rdkit.Chem import AllChem
    probe_noH = Chem.RemoveHs(probe, sanitize=False)
    try:
        fixed = AllChem.AssignBondOrdersFromTemplate(template, probe_noH)
    except ValueError as exc:
        raise RuntimeError(f"AssignBondOrdersFromTemplate failed: {exc}") from exc
    match = fixed.GetSubstructMatch(template)
    if match:
        em = Chem.RWMol(fixed)
        for tmpl_idx, fix_idx in enumerate(match):
            fc = template.GetAtomWithIdx(tmpl_idx).GetFormalCharge()
            em.GetAtomWithIdx(fix_idx).SetFormalCharge(fc)
        fixed = em.GetMol()
    Chem.SanitizeMol(fixed)
    for prop in probe.GetPropsAsDict():
        fixed.SetProp(prop, probe.GetProp(prop))
    return fixed


def fix_sdf_bond_orders(raw_sdf: str, smiles: str, fixed_sdf: str) -> list:
    import shutil
    from rdkit import Chem, RDLogger
    from rdkit.Chem import AllChem
    RDLogger.DisableLog("rdApp.*")
    log = []
    try:
        template = _bo_template(smiles)
    except Exception as e:
        log.append(f"⚠ Could not build template: {e} — skipping fix")
        RDLogger.EnableLog("rdApp.error")
        shutil.copy(raw_sdf, fixed_sdf)
        return log
    supplier = Chem.SDMolSupplier(raw_sdf, sanitize=False, removeHs=False)
    writer   = Chem.SDWriter(fixed_sdf)
    writer.SetKekulize(False)
    ok = err = 0
    for i, mol in enumerate(supplier):
        if mol is None:
            log.append(f"⚠ Pose {i+1}: could not read — skipped")
            err += 1
            continue
        try:
            fixed = _bo_fix_mol(mol, template)
            try:
                from rdkit.Chem import RWMol
                rw = RWMol(fixed)
                charged_idx = []
                for atom in rw.GetAtoms():
                    if atom.GetFormalCharge() != 0:
                        atom.SetNoImplicit(True)
                        charged_idx.append(atom.GetIdx())
                fixed_protected = rw.GetMol()
                fixed_h = Chem.AddHs(fixed_protected, addCoords=True)
                conf    = fixed_h.GetConformer()
                bad = any(
                    abs(conf.GetAtomPosition(j).x)
                    + abs(conf.GetAtomPosition(j).y)
                    + abs(conf.GetAtomPosition(j).z) < 0.01
                    for j in range(fixed_h.GetNumAtoms())
                    if fixed_h.GetAtomWithIdx(j).GetAtomicNum() == 1
                )
                writer.write(fixed if bad else fixed_h)
            except Exception:
                writer.write(fixed)
            ok += 1
        except Exception as e:
            log.append(f"⚠ Pose {i+1}: fix failed ({e}) — writing raw")
            mol_noH = Chem.RemoveHs(mol, sanitize=False)
            writer.write(mol_noH)
            err += 1
    writer.close()
    RDLogger.EnableLog("rdApp.error")
    log.append(f"Bond-order fix: {ok} OK, {err} fallback")
    return log


# ══════════════════════════════════════════════════════════════════════════════
#  SDF UTILITIES  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

def load_mols_from_sdf(sdf_path: str, sanitize: bool = True) -> list:
    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    mols = []
    try:
        sup = Chem.SDMolSupplier(sdf_path, sanitize=sanitize, removeHs=False)
        for m in sup:
            if m is not None:
                mols.append(m)
    except Exception:
        pass
    if sanitize:
        try:
            sup2 = Chem.SDMolSupplier(sdf_path, sanitize=False, removeHs=False)
            raw  = [m for m in sup2 if m is not None]
            if len(raw) > len(mols):
                result = []
                for m in raw:
                    try:
                        Chem.SanitizeMol(m)
                    except Exception:
                        pass
                    result.append(m)
                RDLogger.EnableLog("rdApp.error")
                return result
        except Exception:
            pass
    RDLogger.EnableLog("rdApp.error")
    return mols


def write_single_pose(mol, path: str) -> None:
    from rdkit import Chem
    with Chem.SDWriter(path) as w:
        w.write(mol)


def write_single_pose_pdb(mol, path: str) -> None:
    from rdkit import Chem
    Chem.MolToPDBFile(mol, path)


def convert_sdf_to_v2000(sdf_path: str) -> str:
    from rdkit import Chem, RDLogger
    out = sdf_path.replace(".sdf", "_v2000.sdf")
    if out == sdf_path:
        out = sdf_path + "_v2000.sdf"
    RDLogger.DisableLog("rdApp.*")
    try:
        mol = None
        for sanitize in (True, False):
            sup = Chem.SDMolSupplier(sdf_path, sanitize=sanitize, removeHs=True)
            mol = next((m for m in sup if m is not None), None)
            if mol is not None:
                if not sanitize:
                    try:
                        Chem.SanitizeMol(mol)
                    except Exception:
                        pass
                break
        if mol is not None and mol.GetNumConformers() > 0:
            mol_noH = Chem.RemoveHs(mol, sanitize=False)
            try:
                Chem.SanitizeMol(mol_noH)
            except Exception:
                pass
            try:
                Chem.Kekulize(mol_noH, clearAromaticFlags=True)
            except Exception:
                pass
            w = Chem.SDWriter(out)
            w.SetKekulize(True)
            w.write(mol_noH)
            w.close()
            if os.path.exists(out) and os.path.getsize(out) > 10:
                RDLogger.EnableLog("rdApp.error")
                return out
    except Exception:
        pass
    RDLogger.EnableLog("rdApp.error")
    rc, _ = run_cmd(f'obabel "{sdf_path}" -O "{out}" {_NULL}')
    if rc == 0 and os.path.exists(out) and os.path.getsize(out) > 10:
        return out
    return sdf_path


# ══════════════════════════════════════════════════════════════════════════════
#  STRUCTURAL ANALYSIS  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

def get_interacting_residues(receptor_pdb: str, lig_mol, cutoff: float = 3.5) -> list:
    try:
        import numpy as np
        from prody import parsePDB
        conf    = lig_mol.GetConformer()
        lig_xyz = np.array([
            [conf.GetAtomPosition(i).x,
             conf.GetAtomPosition(i).y,
             conf.GetAtomPosition(i).z]
            for i in range(lig_mol.GetNumAtoms())
        ])
        rec      = parsePDB(receptor_pdb)
        r_xyz    = rec.getCoords()
        chains   = rec.getChids()
        resids   = rec.getResnums()
        resnames = rec.getResnames()
        seen = {}
        for j in range(len(r_xyz)):
            if np.linalg.norm(lig_xyz - r_xyz[j], axis=1).min() <= cutoff:
                key = (str(chains[j]), int(resids[j]))
                if key not in seen:
                    seen[key] = str(resnames[j])
        return [{"chain": k[0], "resi": k[1], "resn": v} for k, v in seen.items()]
    except Exception:
        return []


def calc_rmsd_heavy(pose_mol, crystal_pdb_path: str):
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")
    try:
        from rdkit import Chem
        from rdkit.Chem import rdFMCS
        import numpy as np
        if not os.path.exists(crystal_pdb_path):
            return None
        cryst = None
        for sanitize, removeHs, proxBonding in [
            (True,  True, True),
            (False, True, True),
            (True,  True, False),
            (False, True, False),
        ]:
            try:
                cryst = Chem.MolFromPDBFile(
                    crystal_pdb_path, sanitize=sanitize,
                    removeHs=removeHs, proximityBonding=proxBonding,
                )
                if cryst is not None and cryst.GetNumConformers() > 0:
                    if not sanitize:
                        try: Chem.SanitizeMol(cryst)
                        except Exception: pass
                    break
                cryst = None
            except Exception:
                cryst = None
        if cryst is None or cryst.GetNumConformers() == 0:
            return None
        pose = Chem.RemoveHs(pose_mol, sanitize=False)
        try: Chem.SanitizeMol(pose)
        except Exception: pass
        if pose.GetNumConformers() == 0:
            return None
        n_smaller = min(pose.GetNumAtoms(), cryst.GetNumAtoms())
        mcs = rdFMCS.FindMCS(
            [pose, cryst], timeout=10,
            bondCompare=rdFMCS.BondCompare.CompareAny,
            atomCompare=rdFMCS.AtomCompare.CompareElements,
            completeRingsOnly=False, matchValences=False,
        )
        if mcs.numAtoms < 3 or mcs.numAtoms < 0.6 * n_smaller:
            return None
        mcs_mol = Chem.MolFromSmarts(mcs.smartsString)
        if mcs_mol is None:
            return None
        pose_matches  = pose.GetSubstructMatches(mcs_mol,  uniquify=False)
        cryst_matches = cryst.GetSubstructMatches(mcs_mol, uniquify=False)
        if not pose_matches or not cryst_matches:
            return None
        pc, cc = pose.GetConformer(), cryst.GetConformer()
        def _rmsd(pm, cm):
            sq = sum(
                (pc.GetAtomPosition(pi).x - cc.GetAtomPosition(ci).x) ** 2 +
                (pc.GetAtomPosition(pi).y - cc.GetAtomPosition(ci).y) ** 2 +
                (pc.GetAtomPosition(pi).z - cc.GetAtomPosition(ci).z) ** 2
                for pi, ci in zip(pm, cm)
            )
            return float(np.sqrt(sq / len(pm)))
        return min(_rmsd(pm, cm) for pm in pose_matches for cm in cryst_matches)
    except Exception:
        return None
    finally:
        RDLogger.EnableLog("rdApp.error")


# ══════════════════════════════════════════════════════════════════════════════
#  POSEVIEW REST API  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

_PP_BASE          = "https://proteins.plus/api/v2/"
_PP_UPLOAD        = _PP_BASE + "molecule_handler/upload/"
_PP_UPLOAD_JOBS   = _PP_BASE + "molecule_handler/upload/jobs/"
_PP_POSEVIEW      = _PP_BASE + "poseview/"
_PP_POSEVIEW_JOBS = _PP_BASE + "poseview/jobs/"

_PP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Referer": "https://proteins.plus/",
    "Origin":  "https://proteins.plus",
}

_PP_PROTEIN_CACHE: dict = {}


def _pp_poll(job_id: str, poll_url: str, poll_interval: int = 2,
             max_polls: int = 60) -> dict:
    import requests
    job    = requests.get(poll_url + job_id + "/", headers=_PP_HEADERS, timeout=15).json()
    status = str(job.get("status", "")).lower()
    polls  = 0
    while status in ("pending", "running", "processing", "queued", ""):
        if polls >= max_polls:
            raise RuntimeError(f"Job {job_id} still '{status}' after {max_polls * poll_interval} s")
        time.sleep(poll_interval)
        polls += 1
        job    = requests.get(poll_url + job_id + "/", headers=_PP_HEADERS, timeout=15).json()
        status = str(job.get("status", "")).lower()
    return job


def _prepare_pdb_for_poseview(receptor_pdb: str) -> str:
    rec_dir = os.path.dirname(os.path.abspath(receptor_pdb))
    candidates = [
        os.path.join(rec_dir, "receptor_atoms.pdb"),
        receptor_pdb,
    ]
    source = next((p for p in candidates if os.path.exists(p) and os.path.getsize(p) > 100), receptor_pdb)
    out = os.path.join(rec_dir, "receptor_pv_clean.pdb")
    try:
        kept   = []
        serial = 0
        with open(source) as f:
            for line in f:
                rec = line[:6].strip()
                if rec not in ("ATOM", "HETATM", "TER", "END"):
                    continue
                if rec in ("ATOM", "HETATM"):
                    atom_name = line[12:16].strip()
                    element   = line[76:78].strip() if len(line) > 76 else ""
                    if element.upper() == "H" or (not element and atom_name.startswith("H")):
                        continue
                    serial += 1
                    line = f"{line[:6]}{serial:5d}{line[11:]}"
                kept.append(line if line.endswith("\n") else line + "\n")
        if not kept:
            return receptor_pdb
        if not any(l.startswith("END") for l in kept):
            kept.append("END\n")
        with open(out, "w") as f:
            f.writelines(kept)
        if os.path.exists(out) and os.path.getsize(out) > 100:
            return out
    except Exception:
        pass
    return receptor_pdb


def call_poseview_v1(receptor_pdb: str, pose_sdf: str) -> tuple:
    import requests
    last_error = "Unknown error"
    rec_to_send = _prepare_pdb_for_poseview(receptor_pdb)
    for attempt in range(1, _PV_MAX_RETRIES + 1):
        if attempt > 1:
            time.sleep(_PV_RETRY_DELAY)
        try:
            with open(rec_to_send) as rf, open(pose_sdf) as lf:
                r = requests.post(
                    _PP_POSEVIEW,
                    files={
                        "protein_file": ("receptor.pdb", rf, "chemical/x-pdb"),
                        "ligand_file":  ("ligand.sdf",   lf, "chemical/x-mdl-sdfile"),
                    },
                    headers=_PP_HEADERS, timeout=30,
                )
            r.raise_for_status()
            pv_data   = r.json()
            pv_job_id = pv_data.get("job_id") or pv_data.get("id")
            if not pv_job_id:
                last_error = f"PoseView submission: no job_id in {pv_data}"
                continue
        except Exception as e:
            last_error = f"PoseView submission failed (attempt {attempt}): {e}"
            continue
        try:
            pv_job = _pp_poll(pv_job_id, _PP_POSEVIEW_JOBS)
            status = str(pv_job.get("status", "")).lower()
        except RuntimeError as e:
            last_error = str(e); continue
        except Exception as e:
            last_error = f"Polling error (attempt {attempt}): {e}"; continue
        if status in ("failed", "failure", "error"):
            last_error = f"PoseView rejected job (attempt {attempt}). Full response: {pv_job}"
            continue
        if status != "success":
            last_error = f"Unexpected status '{status}' (attempt {attempt}). Full response: {pv_job}"
            continue
        img_url = pv_job.get("image")
        if not img_url:
            last_error = f"Job succeeded but 'image' key missing. Keys: {list(pv_job.keys())}"
            continue
        try:
            resp = requests.get(img_url, headers=_PP_HEADERS, timeout=20)
            resp.raise_for_status()
            return resp.content, None
        except Exception as e:
            last_error = f"SVG download failed (attempt {attempt}): {e}"
            continue
    return None, last_error


def warm_poseview_cache(receptor_pdb: str) -> tuple:
    return True, "Direct POST mode — no pre-upload needed"


def clear_poseview_cache():
    _PP_PROTEIN_CACHE.clear()


def call_poseview2_ref(pdb_code: str, ligand_id: str) -> tuple:
    import requests
    _SUBMIT = "https://proteins.plus/api/poseview2_rest"
    last_error = "Unknown error"
    for attempt in range(1, _PV_MAX_RETRIES + 1):
        if attempt > 1:
            time.sleep(_PV_RETRY_DELAY)
        try:
            r = requests.post(
                _SUBMIT,
                json={"poseview2": {
                    "pdbCode": pdb_code.strip().lower(),
                    "ligand":  ligand_id.strip(),
                }},
                headers={"Accept": "application/json", "Content-Type": "application/json"},
                timeout=30,
            )
            data = r.json()
            if r.status_code not in (200, 202):
                last_error = f"Submission failed ({r.status_code}), attempt {attempt}: {data}"
                continue
            location = data.get("location", "")
            if not location:
                last_error = f"API returned no job location. Response: {data}"
                continue
        except Exception as e:
            last_error = f"Submission error (attempt {attempt}): {e}"
            continue
        job_failed = False
        for poll_i in range(_PV_POLL_ATTEMPTS):
            time.sleep(2)
            try:
                poll        = requests.get(location, headers={"Accept": "application/json"}, timeout=15).json()
                status_code = poll.get("status_code")
                if status_code == 200:
                    svg_url = poll.get("result_svg", "")
                    if not svg_url:
                        last_error = f"Job finished but result_svg is empty. Full response: {poll}"
                        job_failed = True; break
                    resp = requests.get(svg_url, timeout=20)
                    resp.raise_for_status()
                    return resp.content, None
                elif status_code == 202:
                    continue
                else:
                    last_error = f"Unexpected poll status {status_code} (attempt {attempt}). Full response: {poll}"
                    job_failed = True; break
            except Exception as e:
                last_error = f"Polling error (attempt {attempt}, poll {poll_i+1}): {e}"
                continue
        if not job_failed:
            last_error = f"Timed out after {_PV_POLL_ATTEMPTS * 2} s (attempt {attempt})"
    return None, last_error


def diagnose_poseview() -> dict:
    import requests
    result = {
        "server_reachable": False, "upload_ok": False,
        "poseview_ok": False, "status": "", "job_response": {},
        "image_url": "", "error": "", "log": [],
    }
    log = result["log"]
    try:
        r = requests.get("https://proteins.plus/api/v2/", timeout=10)
        r.raise_for_status()
        result["server_reachable"] = True
        log.append(f"✓ Server reachable (HTTP {r.status_code})")
    except Exception as e:
        result["error"] = f"Server unreachable: {e}"
        log.append(f"✗ Server unreachable: {e}")
        return result
    try:
        r = requests.post(_PP_UPLOAD, data={"pdb_code": "4agn"}, timeout=30)
        r.raise_for_status()
        job_id = r.json().get("job_id")
        log.append(f"✓ Upload job submitted: {job_id}")
        job = _pp_poll(job_id, _PP_UPLOAD_JOBS, poll_interval=1, max_polls=30)
        log.append(f"✓ Upload job: {job.get('status')}")
        protein_id   = job["output_protein"]
        protein_json = requests.get(_PP_BASE + "molecule_handler/proteins/" + protein_id + "/", timeout=15).json()
        pdb_text     = protein_json["file_string"]
        ligand_id    = protein_json["ligand_set"][0]
        ligand_json  = requests.get(_PP_BASE + "molecule_handler/ligands/" + ligand_id + "/", timeout=15).json()
        sdf_text     = ligand_json["file_string"]
        log.append(f"✓ Got protein ({len(pdb_text)} chars) + ligand {ligand_json.get('name')} ({len(sdf_text)} chars)")
        result["upload_ok"] = True
    except Exception as e:
        result["error"] = f"MoleculeHandler step failed: {e}"
        log.append(f"✗ MoleculeHandler failed: {e}")
        return result
    try:
        import io as _io
        r = requests.post(
            _PP_POSEVIEW,
            files={
                "protein_file": ("test.pdb", _io.StringIO(pdb_text), "chemical/x-pdb"),
                "ligand_file":  ("test.sdf", _io.StringIO(sdf_text), "chemical/x-mdl-sdfile"),
            },
            timeout=30,
        )
        r.raise_for_status()
        pv_job_id = r.json().get("job_id")
        log.append(f"✓ PoseView job submitted: {pv_job_id}")
        pv_job = _pp_poll(pv_job_id, _PP_POSEVIEW_JOBS, poll_interval=2, max_polls=30)
        result["job_response"] = pv_job
        result["status"]       = pv_job.get("status", "")
        log.append(f"✓ PoseView job status: {result['status']}")
        if result["status"] == "success":
            result["image_url"]   = pv_job.get("image", "")
            result["poseview_ok"] = True
            log.append(f"✓ Image URL: {result['image_url']}")
        else:
            result["error"] = f"PoseView returned '{result['status']}'. Full response: {pv_job}"
            log.append(f"✗ {result['error']}")
    except Exception as e:
        result["error"] = f"PoseView step failed: {e}"
        log.append(f"✗ PoseView failed: {e}")
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  IMAGE UTILITIES  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

def svg_to_png(svg_bytes: bytes):
    try:
        import cairosvg
        return cairosvg.svg2png(bytestring=svg_bytes, scale=2, background_color="white")
    except Exception:
        return None


def stamp_png(png_bytes: bytes, text: str) -> bytes:
    try:
        from PIL import Image, ImageDraw, ImageFont
        import io as _io
        img  = Image.open(_io.BytesIO(png_bytes)).convert("RGBA")
        draw = ImageDraw.Draw(img)
        font = None
        _font_candidates = [
            # Linux
            ("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 28),
            ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 28),
            ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 26),
            # macOS (system + Homebrew)
            ("/System/Library/Fonts/Supplemental/Arial.ttf", 28),
            ("/System/Library/Fonts/Helvetica.ttc", 28),
            ("/Library/Fonts/Arial.ttf", 28),
            ("/opt/homebrew/share/fonts/liberation-fonts/LiberationSans-Regular.ttf", 28),
            # Windows
            ("C:/Windows/Fonts/arial.ttf", 28),
            ("C:/Windows/Fonts/segoeui.ttf", 28),
            ("C:/Windows/Fonts/calibri.ttf", 28),
        ]
        for fp, sz in _font_candidates:
            try:
                font = ImageFont.truetype(fp, sz); break
            except Exception:
                pass
        if font is None:
            font = ImageFont.load_default()
        bbox   = draw.textbbox((0, 0), text, font=font, anchor="lt")
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        pad_x, pad_y = 36, 16
        pill_w = tw + pad_x * 2
        pill_h = th + pad_y * 2
        pill_r = pill_h // 2
        px     = (img.width  - pill_w) // 2
        py_    =  img.height - pill_h  - 28
        draw.rounded_rectangle(
            [px, py_, px + pill_w, py_ + pill_h],
            radius=pill_r, fill=(232, 232, 232, 230),
        )
        draw.text(
            (px + pill_w // 2, py_ + pill_h // 2),
            text, font=font, fill=(26, 26, 26, 255), anchor="mm",
        )
        buf = _io.BytesIO()
        img.convert("RGB").save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return png_bytes


# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM 2D INTERACTION DIAGRAM  (unchanged from original)
# ══════════════════════════════════════════════════════════════════════════════

import math as _math

_ITYPE_PRIORITY = [
    "metal", "ionic", "halogen", "hbond_to_halogen",
    "hbond", "pi_pi", "cation_pi", "hydrophobic",
]

_CLR_HBOND   = "#1a7a1a"
_CLR_PIPI    = "#e200e8"
_CLR_HYDRO   = "#2287ff"
_CLR_IONIC   = "#aa0077"
_CLR_METAL   = "#cc8800"
_CLR_HAL     = "#cc2277"
_CLR_HBXHAL  = "#6633aa"

_RES_CIRCLE = {
    "hbond":            dict(fill="#80dd80", opacity=0.2),
    "hbond_to_halogen": dict(fill="#80dd80", opacity=0.2),
    "pi_pi":            dict(fill="#e200e8", opacity=0.2),
    "cation_pi":        dict(fill="#e200e8", opacity=0.2),
    "hydrophobic":      dict(fill="#2287ff", opacity=0.2),
    "ionic":            dict(fill="#ffaae0", opacity=0.2),
    "metal":            dict(fill="#ffe080", opacity=0.2),
    "halogen":          dict(fill="#ffb0d0", opacity=0.2),
}

_LBL_CLR = {
    "hbond":            _CLR_HBOND,
    "hbond_to_halogen": _CLR_HBOND,
    "pi_pi":            _CLR_PIPI,
    "cation_pi":        _CLR_PIPI,
    "hydrophobic":      _CLR_HYDRO,
    "ionic":            _CLR_IONIC,
    "metal":            _CLR_METAL,
    "halogen":          _CLR_HAL,
}

_LINE_CLR = {
    "hbond":            _CLR_HBOND,
    "hbond_to_halogen": _CLR_HBXHAL,
    "pi_pi":            _CLR_PIPI,
    "cation_pi":        _CLR_PIPI,
    "ionic":            _CLR_IONIC,
    "metal":            _CLR_METAL,
    "halogen":          _CLR_HAL,
}

_ATOM_CLR = {
    "C":"#1a1a1a", "N":"#1a5fa8", "O":"#cc2222",
    "S":"#c8a800", "P":"#e07000", "F":"#1a7a1a",
    "CL":"#1a7a1a", "BR":"#8b2500", "I":"#5c2d8a", "H":"#555555",
}
_AROM_DOT_CLR = "#1a7a1a"

_AROM_ATOMS = {"PHE","TYR","TRP","HIS","HEM","HEC","HEA","HEB","HDD","HDM"}

_AROM_ATOM_NAMES = {
    "CG","CD1","CD2","CE1","CE2","CZ",
    "ND1","NE2","CE3","CZ2","CZ3","CH2",
    "C1","C2","C3","C4","C5","C6","C7","C8",
    "C10","C11","C12","C13","C14","C15","C16","C17",
    "C19","C20",
    "CA","CB",
    "CAA","CAB","CAC","CAD",
    "CBA","CBB","CBC","CBD",
    "C2A","C3A","C4A",
    "C2B","C3B","C4B",
    "C2C","C3C","C4C",
    "C2D","C3D","C4D",
    "CHA","CHB","CHC","CHD",
}

_HYDR_BASE     = {"ALA","VAL","ILE","LEU","MET","PHE","TRP","PRO","GLY","TYR","HIS"}
_HYDR_EXTENDED = _HYDR_BASE | HEME_RESNAMES


def _get_aromatic_ring_data(mol, conf):
    import numpy as np
    results = []
    for ring in mol.GetRingInfo().AtomRings():
        if len(ring) not in (5, 6): continue
        if not all(mol.GetAtomWithIdx(i).GetIsAromatic() for i in ring): continue
        coords   = np.array([[conf.GetAtomPosition(i).x,
                               conf.GetAtomPosition(i).y,
                               conf.GetAtomPosition(i).z] for i in ring])
        centroid = coords.mean(axis=0)
        v1 = coords[1]-coords[0]; v2 = coords[2]-coords[0]
        n  = np.cross(v1,v2); nl = np.linalg.norm(n)
        if nl > 0: n /= nl
        results.append((centroid, n, list(ring)))
    return results


def _detect_all_interactions(lig_mol_3d, receptor_pdb: str,
                              cutoff: float = 4.5) -> list:
    import numpy as np
    from prody import parsePDB
    rec = parsePDB(receptor_pdb)
    if rec is None:
        return []
    rc  = np.array(rec.getCoords(),  dtype=float)
    rrn = rec.getResnames()
    rch = rec.getChids()
    rri = rec.getResnums()
    ran = rec.getNames()
    rel = rec.getElements()
    conf = lig_mol_3d.GetConformer()
    nl   = lig_mol_3d.GetNumAtoms()
    lxyz = np.array([[conf.GetAtomPosition(i).x,
                      conf.GetAtomPosition(i).y,
                      conf.GetAtomPosition(i).z] for i in range(nl)], dtype=float)
    latom = [lig_mol_3d.GetAtomWithIdx(i) for i in range(nl)]
    lel   = [a.GetSymbol().upper() for a in latom]
    lchg  = [a.GetFormalCharge() for a in latom]
    _VDW = {"H":1.20,"C":1.70,"N":1.55,"O":1.52,"S":1.80,"P":1.80,
            "F":1.47,"CL":1.75,"BR":1.85,"I":1.98,"SE":1.90}
    nr = len(rc)
    r_el  = [rel[j].strip().upper() if rel[j] and rel[j].strip()
             else ran[j][:1].upper() for j in range(nr)]
    r_el_arr = np.array(r_el)
    r_rn  = np.array([rrn[j].strip() for j in range(nr)])
    r_an  = np.array([ran[j].strip() for j in range(nr)])
    r_ch  = np.array([rch[j].strip() for j in range(nr)])
    r_ri  = np.array([int(rri[j])    for j in range(nr)])
    # ── SPATIAL PRE-FILTER: restrict to a shell around the ligand pose ────
    # Very large proteins (100+ kDa, ribosomes, viral capsids, AF-multimer
    # complexes) would otherwise cause the H-to-heavy distance matrix below
    # (h_coords[:, None, :] - hv_coords[None, :, :]) to allocate multi-GB
    # arrays and OOM-kill the process. All interaction cutoffs are ≤ 5.5 Å
    # (π-π is the longest), so an 8 Å shell around the ligand bounding
    # sphere is amply safe — including a 1.85 Å pad for the halogen-bond
    # covalent-neighbor lookup on atoms sitting at the edge of the shell.
    # Small proteins (<200 residues) see negligible change; large receptors
    # typically drop from tens of thousands of atoms to a few hundred near
    # the pose.
    _lig_centroid = lxyz.mean(axis=0)
    _lig_radius   = float(np.linalg.norm(lxyz - _lig_centroid, axis=1).max())
    _SHELL_PAD    = 8.0
    _keep_mask    = (
        np.linalg.norm(rc - _lig_centroid, axis=1) <= (_lig_radius + _SHELL_PAD)
    )
    if not _keep_mask.any():
        return []
    rc       = rc[_keep_mask]
    r_rn     = r_rn[_keep_mask]
    r_ch     = r_ch[_keep_mask]
    r_ri     = r_ri[_keep_mask]
    r_an     = r_an[_keep_mask]
    r_el_arr = r_el_arr[_keep_mask]
    r_el     = [r_el[k] for k, keep in enumerate(_keep_mask) if keep]
    nr       = int(_keep_mask.sum())
    HYDL = {"C","S","CL","BR","I","F"}
    LIG_ACCEPTOR_EL = {"N","O","F","S"}
    lig_is_acceptor    = np.array([lel[i] in LIG_ACCEPTOR_EL for i in range(nl)])
    lig_is_hydrophobic = np.array([lel[i] in HYDL for i in range(nl)])
    def _is_lig_donor(i):
        a = latom[i]
        if lel[i] not in ("N","O","S","F"): return False
        for nb in a.GetNeighbors():
            if nb.GetAtomicNum() == 1: return True
        return a.GetTotalNumHs() > 0
    lig_is_donor = np.array([_is_lig_donor(i) for i in range(nl)])
    def _angles_at_b(a_pts, b_pt, c_pt):
        va = a_pts - b_pt
        vc = c_pt  - b_pt
        na = np.linalg.norm(va, axis=1)
        nc = float(np.linalg.norm(vc))
        if nc < 1e-8: return np.zeros(len(a_pts))
        cos_t = (va @ vc) / (na * nc + 1e-12)
        cos_t = np.clip(cos_t, -1.0, 1.0)
        return np.degrees(np.arccos(cos_t))
    def _angle3(a, b, c):
        va = a - b; vc = c - b
        na = np.linalg.norm(va); nc = np.linalg.norm(vc)
        if na < 1e-8 or nc < 1e-8: return 0.0
        return float(np.degrees(np.arccos(
            np.clip(np.dot(va, vc) / (na * nc), -1.0, 1.0))))
    h_mask    = r_el_arr == "H"
    h_idx     = np.where(h_mask)[0]
    heavy_idx = np.where(~h_mask)[0]
    h_to_heavy = {}
    if len(h_idx) and len(heavy_idx):
        h_coords  = rc[h_idx]
        hv_coords = rc[heavy_idx]
        diff      = h_coords[:, None, :] - hv_coords[None, :, :]
        dists_hh  = np.linalg.norm(diff, axis=2)
        closest   = np.argmin(dists_hh, axis=1)
        min_d     = dists_hh[np.arange(len(h_idx)), closest]
        for k, (hi, ci, md) in enumerate(zip(h_idx, closest, min_d)):
            if md < 1.15:
                h_to_heavy[int(hi)] = int(heavy_idx[ci])
    heavy_to_h = {}
    for hj, hk in h_to_heavy.items():
        heavy_to_h.setdefault(hk, []).append(hj)
    PROT_DONOR_ATOMS = {
        "N","OG","OG1","OH","SG","NZ","NH1","NH2","NE",
        "ND1","NE2","NE1","ND2",
    }
    PROT_ACCEPTOR_ATOMS = {
        "O","OD1","OD2","OE1","OE2","OG","OG1","OH",
        "ND1","NE2","SD",
    }
    HBOND_DA_MAX  = 3.5
    HBOND_ANG_MIN = 120.0
    HBOND_PROXY   = 90.0
    results        = []
    hbond_residues = set()
    polar_mask = np.array([
        r_el_arr[j] in ("N","O","S") and r_el_arr[j] != "H"
        and r_rn[j] not in ("HOH","WAT","DOD")
        for j in range(nr)
    ])
    polar_idx = np.where(polar_mask)[0]
    for j in polar_idx:
        an = r_an[j]; ch = r_ch[j]; ri = int(r_ri[j]); el = r_el[j]
        rp = rc[j]
        key = (ch, ri)
        if key in hbond_residues:
            continue
        dists_j = np.linalg.norm(lxyz - rp, axis=1)
        if an in PROT_DONOR_ATOMS:
            cand = np.where(lig_is_acceptor & (dists_j <= HBOND_DA_MAX))[0]
            if len(cand):
                hs = heavy_to_h.get(j, [])
                for i in cand:
                    d_DA = float(dists_j[i])
                    if hs:
                        best = max(_angle3(rp, rc[hj], lxyz[i]) for hj in hs)
                        if best < HBOND_ANG_MIN: continue
                    else:
                        nbs_i = [nb.GetIdx() for nb in latom[i].GetNeighbors()
                                 if nb.GetAtomicNum() != 1 and nb.GetIdx() < nl]
                        if nbs_i:
                            if _angle3(rp, lxyz[i], lxyz[nbs_i[0]]) < HBOND_PROXY:
                                continue
                    hbond_residues.add(key)
                    results.append(dict(resname=r_rn[j],chain=ch,resid=ri,
                        itype="hbond",distance=round(d_DA,1),lig_atom_idx=int(i),
                        prot_el=el,is_donor=True,ring_atom_indices=None))
                    break
        if key in hbond_residues: continue
        if an in PROT_ACCEPTOR_ATOMS:
            cand = np.where(lig_is_donor & (dists_j <= HBOND_DA_MAX))[0]
            if len(cand):
                for i in cand:
                    d_DA = float(dists_j[i])
                    lig_hs = [nb.GetIdx() for nb in latom[i].GetNeighbors()
                              if nb.GetAtomicNum() == 1 and nb.GetIdx() < nl]
                    if lig_hs:
                        best = max(_angle3(lxyz[i], lxyz[hi], rp) for hi in lig_hs)
                        if best < HBOND_ANG_MIN: continue
                    else:
                        nbs_i = [nb.GetIdx() for nb in latom[i].GetNeighbors()
                                 if nb.GetAtomicNum() != 1 and nb.GetIdx() < nl]
                        if nbs_i:
                            if _angle3(rp, lxyz[i], lxyz[nbs_i[0]]) < HBOND_PROXY:
                                continue
                    hbond_residues.add(key)
                    results.append(dict(resname=r_rn[j],chain=ch,resid=ri,
                        itype="hbond",distance=round(d_DA,1),lig_atom_idx=int(i),
                        prot_el=el,is_donor=False,ring_atom_indices=None))
                    break
    for j in range(nr):
        rn = r_rn[j]; ch = r_ch[j]; ri = int(r_ri[j]); el = r_el[j]; rp = rc[j]
        dists_j = np.linalg.norm(lxyz - rp, axis=1)
        md = float(dists_j.min()); mi = int(dists_j.argmin())
        if md > max(cutoff + 1.0, 5.6): continue
        if el in {"C","S","CL","BR","I"} and rn in _HYDR_EXTENDED:
            cand = np.where(lig_is_hydrophobic & (dists_j < cutoff))[0]
            if len(cand):
                i = int(cand[0])
                results.append(dict(resname=rn,chain=ch,resid=ri,
                    itype="hydrophobic",distance=round(float(dists_j[i]),1),
                    lig_atom_idx=i,prot_el=el,is_donor=False,ring_atom_indices=None))
        if rn in {"ASP","GLU"} and el == "O":
            for i in range(nl):
                if lchg[i] > 0 and float(dists_j[i]) < 4.0:
                    results.append(dict(resname=rn,chain=ch,resid=ri,
                        itype="ionic",distance=round(float(dists_j[i]),1),
                        lig_atom_idx=i,prot_el=el,is_donor=False,ring_atom_indices=None)); break
        if rn in {"LYS","ARG"} and el == "N":
            for i in range(nl):
                if lchg[i] < 0 and float(dists_j[i]) < 4.0:
                    results.append(dict(resname=rn,chain=ch,resid=ri,
                        itype="ionic",distance=round(float(dists_j[i]),1),
                        lig_atom_idx=i,prot_el=el,is_donor=True,ring_atom_indices=None)); break
        _is_heme_fe = (r_rn[j] in HEME_RESNAMES and r_an[j].strip().upper() == "FE")
        if rn.strip().upper() in METAL_RESNAMES or el in METAL_RESNAMES or _is_heme_fe:
            if md < 2.8:
                results.append(dict(resname=rn,chain=ch,resid=ri,
                    itype="metal",distance=round(md,1),lig_atom_idx=mi,
                    prot_el=el,is_donor=False,ring_atom_indices=None))
    lr = _get_aromatic_ring_data(lig_mol_3d, conf)
    if lr:
        arom_mask = np.array([
            r_rn[j] in _AROM_ATOMS and r_an[j] in _AROM_ATOM_NAMES and r_el[j] == "C"
            for j in range(nr)
        ])
        arom_idx = np.where(arom_mask)[0]
        for j in arom_idx:
            rp = rc[j]
            for lc, _, ring_idxs in lr:
                d = float(np.linalg.norm(lc - rp))
                if d < 5.5:
                    results.append(dict(resname=r_rn[j],chain=r_ch[j],resid=int(r_ri[j]),
                        itype="pi_pi",distance=round(d,1),
                        lig_atom_idx=ring_idxs[0],prot_el="C",is_donor=False,
                        ring_atom_indices=ring_idxs)); break
        cat_mask = np.array([r_rn[j] in {"LYS","ARG"} and r_el[j] == "N" for j in range(nr)])
        for j in np.where(cat_mask)[0]:
            rp = rc[j]
            for lc, _, ring_idxs in lr:
                d = float(np.linalg.norm(lc - rp))
                if d < 5.0:
                    results.append(dict(resname=r_rn[j],chain=r_ch[j],resid=int(r_ri[j]),
                        itype="cation_pi",distance=round(d,1),
                        lig_atom_idx=ring_idxs[0],prot_el="N",is_donor=True,
                        ring_atom_indices=ring_idxs)); break
    _XD  = {17:"CL", 35:"BR", 53:"I"}
    _XA_el = {"O","N","S","F"}
    arom_C_mask = np.array([
        r_rn[j] in _AROM_ATOMS and r_an[j] in _AROM_ATOM_NAMES and r_el[j] == "C"
        for j in range(nr)
    ])
    xb_acc_mask = np.array([r_el[j] in _XA_el for j in range(nr)]) | arom_C_mask
    for i in range(nl):
        ano = latom[i].GetAtomicNum()
        if ano not in _XD: continue
        xel = _XD[ano]; xp = lxyz[i]; vdw_x = _VDW.get(xel, 1.80)
        c_nb = next((nb.GetIdx() for nb in latom[i].GetNeighbors()
                     if nb.GetAtomicNum() == 6 and nb.GetIdx() < nl), None)
        if c_nb is None: continue
        c_pos = lxyz[c_nb]
        max_d = vdw_x + 1.98 + 0.5
        cand_mask = xb_acc_mask & (np.linalg.norm(rc - xp, axis=1) <= max_d)
        cand_idx  = np.where(cand_mask)[0]
        if not len(cand_idx): continue
        for j in cand_idx:
            ael = r_el[j]; ap = rc[j]
            vdw_sum = vdw_x + _VDW.get(ael, 1.70) + 0.5
            d = float(np.linalg.norm(xp - ap))
            if d > vdw_sum: continue
            ang1 = _angle3(c_pos, xp, ap)
            if ang1 < 140.0: continue
            r_nbs = [k for k in range(nr)
                     if k != j and r_el[k] != "H"
                     and float(np.linalg.norm(rc[k] - ap)) < 1.85]
            if r_nbs:
                if _angle3(xp, ap, rc[r_nbs[0]]) < 90.0: continue
            results.append(dict(resname=r_rn[j],chain=r_ch[j],resid=int(r_ri[j]),
                itype="halogen",distance=round(d,1),lig_atom_idx=i,
                prot_el=ael,is_donor=False,ring_atom_indices=None))
    _HA = {9:"F", 17:"CL", 35:"BR", 53:"I"}
    _HD = {"O","N","S"}
    if len(h_idx):
        h_coords = rc[h_idx]
        for i in range(nl):
            ano = latom[i].GetAtomicNum()
            if ano not in _HA: continue
            xel = _HA[ano]; xp = lxyz[i]; vdw_x = _VDW.get(xel, 1.80)
            c_nb2 = next((nb.GetIdx() for nb in latom[i].GetNeighbors()
                          if nb.GetIdx() < nl), None)
            if c_nb2 is None: continue
            c_pos2 = lxyz[c_nb2]
            dhx_all = np.linalg.norm(h_coords - xp, axis=1)
            close_h = np.where(dhx_all <= _VDW["H"] + vdw_x)[0]
            for kk in close_h:
                hj = int(h_idx[kk]); hp = rc[hj]; dhx = float(dhx_all[kk])
                pk = h_to_heavy.get(hj)
                if pk is None or r_el[pk] not in _HD: continue
                dp = rc[pk]
                if _angle3(dp, hp, xp) < 120.0: continue
                if not (70.0 <= _angle3(c_pos2, xp, hp) <= 120.0): continue
                results.append(dict(resname=r_rn[hj],chain=r_ch[hj],resid=int(r_ri[hj]),
                    itype="hbond_to_halogen",distance=round(dhx,1),
                    lig_atom_idx=i,prot_el="N",is_donor=True,ring_atom_indices=None))
    return results


def _deduplicate_interactions(interactions: list) -> list:
    priority={t:i for i,t in enumerate(_ITYPE_PRIORITY)}
    best:dict={}
    for ix in interactions:
        key=(ix["chain"],ix["resid"])
        if key not in best: best[key]=ix
        else:
            pn=priority.get(ix["itype"],99); po=priority.get(best[key]["itype"],99)
            if pn<po or (pn==po and ix["distance"]<best[key]["distance"]): best[key]=ix
    return list(best.values())


def _enrich_with_res_xyz(interactions, mol3d, receptor_pdb):
    import numpy as np
    from prody import parsePDB
    try:
        rec = parsePDB(receptor_pdb)
        if rec is None: return
        rc  = rec.getCoords()
        rch = rec.getChids()
        rri = rec.getResnums()
        conf  = mol3d.GetConformer()
        n_lig = mol3d.GetNumAtoms()
        lxyz  = np.array([[conf.GetAtomPosition(i).x,
                            conf.GetAtomPosition(i).y,
                            conf.GetAtomPosition(i).z] for i in range(n_lig)])
    except Exception:
        return
    for ix in interactions:
        ch  = ix.get("chain", "")
        ri  = ix.get("resid", 0)
        lai = ix.get("lig_atom_idx", 0)
        lai = min(lai, n_lig - 1)
        ring_idxs = ix.get("ring_atom_indices") or []
        if ring_idxs:
            valid = [i for i in ring_idxs if 0 <= i < n_lig]
            if valid:
                lig_anchor = lxyz[valid].mean(axis=0)
            else:
                lig_anchor = lxyz[lai]
        else:
            lig_anchor = lxyz[lai]
        ix["lig_anchor_xyz"] = lig_anchor.tolist()
        res_idx = [j for j in range(len(rc))
                   if rch[j].strip() == ch and int(rri[j]) == ri]
        if not res_idx:
            ix["res_xyz"] = lig_anchor.tolist()
            continue
        res_coords = rc[res_idx]
        dists = np.linalg.norm(res_coords - lig_anchor, axis=1)
        closest_local = int(dists.argmin())
        ix["res_xyz"] = rc[res_idx[closest_local]].tolist()


def _compute_svg_coords(mol2d, cx, cy, target_size=280):
    from rdkit.Chem import rdDepictor
    if mol2d.GetNumConformers()==0: rdDepictor.Compute2DCoords(mol2d)
    conf=mol2d.GetConformer(); n=mol2d.GetNumAtoms()
    if n==0: return {}
    xs=[conf.GetAtomPosition(i).x for i in range(n)]
    ys=[conf.GetAtomPosition(i).y for i in range(n)]
    span=max(max(xs)-min(xs),max(ys)-min(ys),0.01)
    sc=target_size/span; mx=(min(xs)+max(xs))/2; my=(min(ys)+max(ys))/2
    return {i:(cx+(xs[i]-mx)*sc, cy-(ys[i]-my)*sc) for i in range(n)}


def _ring_centroid_2d(ring_atom_indices, svg_coords):
    xs=[svg_coords[i][0] for i in ring_atom_indices if i in svg_coords]
    ys=[svg_coords[i][1] for i in ring_atom_indices if i in svg_coords]
    if not xs: return None, None
    return sum(xs)/len(xs), sum(ys)/len(ys)


def _ring_centroid_from_atom(mol2d, atom_idx_2d, svg_coords):
    ring_info = mol2d.GetRingInfo()
    best_ring = None
    best_size = 999
    for ring in ring_info.AtomRings():
        if atom_idx_2d in ring:
            if mol2d.GetAtomWithIdx(ring[0]).GetIsAromatic():
                if len(ring) < best_size:
                    best_ring = ring
                    best_size = len(ring)
    if best_ring is None:
        return None, None
    xs = [svg_coords[i][0] for i in best_ring if i in svg_coords]
    ys = [svg_coords[i][1] for i in best_ring if i in svg_coords]
    if not xs:
        return None, None
    return sum(xs) / len(xs), sum(ys) / len(ys)


def _place_residues_no_cross(interactions, svg_coords, cx, cy, R=210):
    if not interactions: return []
    items = []
    for ix in interactions:
        if ix.get("ring_atom_indices"):
            ax, ay = _ring_centroid_2d(ix["ring_atom_indices"], svg_coords)
            if ax is None:
                ax, ay = svg_coords.get(ix.get("lig_atom_idx", 0), (cx, cy))
        else:
            ai = ix.get("lig_atom_idx", 0)
            ax, ay = svg_coords.get(ai, (cx, cy))
        angle = _math.atan2(ay - cy, ax - cx)
        items.append({**ix, "angle": angle, "anchor_angle": angle})
    items.sort(key=lambda x: x["angle"])
    n = len(items)
    if n == 1:
        a = items[0]["angle"]
        return [{**items[0], "bx": cx + R * _math.cos(a), "by": cy + R * _math.sin(a), "slot_angle": a}]
    for i in range(n):
        for j in range(i + 1, n):
            if abs(items[j]["angle"] - items[i]["angle"]) < 0.001:
                items[j]["angle"] += 0.05 * (j - i)
    min_dist_px = 78.0
    for _ in range(500):
        delta = [0.0] * n
        any_overlap = False
        for i in range(n):
            for j in range(i + 1, n):
                xi = cx + R * _math.cos(items[i]["angle"])
                yi = cy + R * _math.sin(items[i]["angle"])
                xj = cx + R * _math.cos(items[j]["angle"])
                yj = cy + R * _math.sin(items[j]["angle"])
                dx, dy = xj - xi, yj - yi
                dist = _math.sqrt(dx * dx + dy * dy)
                if dist < min_dist_px:
                    overlap_px = min_dist_px - dist
                    push_angle = overlap_px / max(R, 1.0)
                    delta[i] -= push_angle * 0.5
                    delta[j] += push_angle * 0.5
                    any_overlap = True
        for i in range(n):
            items[i]["angle"] += delta[i]
        if not any_overlap:
            break
    result = []
    for item in items:
        a = item["angle"]
        result.append({**item, "bx": cx + R * _math.cos(a), "by": cy + R * _math.sin(a), "slot_angle": a})
    return result


def _place_residues_pca(interactions, svg_coords, mol3d, cx, cy, R=210):
    if not interactions: return []
    try:
        import numpy as _np_rc
        NODE_R = 24.55; GAP = 45.0; ATOM_R = 20.0
        lx, ly  = _rl_ligand_center(svg_coords)
        atom_xy = list(svg_coords.values())
        anchor_a = [_rl_anchor_angle(ix, svg_coords, lx, ly) for ix in interactions]
        order    = sorted(range(len(interactions)), key=lambda k: anchor_a[k])
        sorted_ix = [interactions[k] for k in order]
        rng       = _np_rc.random.default_rng(42)
        positions = _rl_place_radially(sorted_ix, svg_coords, lx, ly, atom_xy, ATOM_R, GAP, NODE_R, rng)
        positions = _rl_resolve_overlaps(positions, atom_xy, lx, ly, node_r=NODE_R, excl_r=NODE_R + ATOM_R)
        positions = _rl_reduce_crossings(sorted_ix, positions, svg_coords, lx, ly)
        result = []
        for k, (bx, by) in enumerate(positions):
            ang = _math.atan2(by - ly, bx - lx)
            result.append({**sorted_ix[k], "angle": ang, "bx": float(bx), "by": float(by), "slot_angle": ang})
        return result
    except Exception:
        return _place_residues_no_cross(interactions, svg_coords, cx, cy, R)


def _rl_ligand_center(svg_coords):
    pts = list(svg_coords.values())
    if not pts: return 400.0, 380.0
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    return cx, cy


def _rl_anchor_angle(ix, svg_coords, cx, cy):
    ai = ix.get("lig_atom_idx", 0)
    ax, ay = svg_coords.get(ai, (cx, cy))
    ring_idxs = ix.get("ring_atom_indices")
    if ring_idxs:
        rx, ry = _ring_centroid_2d(ring_idxs, svg_coords)
        if rx is not None:
            ax, ay = rx, ry
    return _math.atan2(ay - cy, ax - cx)


def _rl_ray_boundary(cx, cy, theta, atom_xy, atom_r=20.0):
    dx = _math.cos(theta)
    dy = _math.sin(theta)
    r2 = atom_r * atom_r
    t_max = 0.0
    for (ax, ay) in atom_xy:
        vx = ax - cx; vy = ay - cy
        t_proj = vx * dx + vy * dy
        if t_proj < -atom_r: continue
        perp2 = vx * vx + vy * vy - t_proj * t_proj
        if perp2 >= r2: continue
        t_exit = t_proj + _math.sqrt(max(r2 - perp2, 0.0))
        if t_exit > t_max: t_max = t_exit
    return t_max if t_max > 1.0 else 20.0


def _rl_place_radially(sorted_interactions, svg_coords, cx, cy, atom_xy, atom_r, gap, node_r, rng):
    JITTER_T = 7.0; JITTER_R = 4.0
    n = len(sorted_interactions)
    jit_t = rng.uniform(-JITTER_T, JITTER_T, n)
    jit_r = rng.uniform(-JITTER_R, JITTER_R, n)
    positions = []
    for k, ix in enumerate(sorted_interactions):
        theta  = _rl_anchor_angle(ix, svg_coords, cx, cy)
        bdist  = _rl_ray_boundary(cx, cy, theta, atom_xy, atom_r)
        r_place = bdist + gap + node_r + jit_r[k]
        cos_t = _math.cos(theta); sin_t = _math.sin(theta)
        tx, ty = -sin_t, cos_t
        bx = cx + r_place * cos_t + jit_t[k] * tx
        by = cy + r_place * sin_t + jit_t[k] * ty
        positions.append((bx, by))
    return positions


def _rl_resolve_overlaps(positions, atom_xy, cx, cy, node_r=24.55, excl_r=46.0, max_iters=400):
    n = len(positions)
    if n <= 1: return list(positions)
    min_sep = node_r * 2.0 + 8.0
    bx = [p[0] for p in positions]
    by = [p[1] for p in positions]
    for i in range(n):
        for j in range(i + 1, n):
            ddx = bx[j] - bx[i]; ddy = by[j] - by[i]
            if _math.sqrt(ddx * ddx + ddy * ddy) < 1.0:
                ang = (i * 137.508 + j * 73.2) * _math.pi / 180.0
                kick = min_sep * 0.5
                bx[i] -= _math.cos(ang) * kick; by[i] -= _math.sin(ang) * kick
                bx[j] += _math.cos(ang) * kick; by[j] += _math.sin(ang) * kick
    for _it in range(max_iters):
        dx_acc = [0.0] * n; dy_acc = [0.0] * n
        any_overlap = False
        for i in range(n):
            for j in range(i + 1, n):
                ddx = bx[j] - bx[i]; ddy = by[j] - by[i]
                d   = _math.sqrt(ddx * ddx + ddy * ddy) + 1e-8
                if d < min_sep:
                    frac = (min_sep - d) * 0.55 / d
                    dx_acc[i] -= frac * ddx; dy_acc[i] -= frac * ddy
                    dx_acc[j] += frac * ddx; dy_acc[j] += frac * ddy
                    any_overlap = True
        for i in range(n):
            bx[i] += dx_acc[i]; by[i] += dy_acc[i]
        for i in range(n):
            for (ax, ay) in atom_xy:
                ddx = bx[i] - ax; ddy = by[i] - ay
                d   = _math.sqrt(ddx * ddx + ddy * ddy) + 1e-8
                if d < excl_r:
                    push = (excl_r - d) * 0.5 / d
                    if d < 0.5:
                        ddx = bx[i] - cx; ddy = by[i] - cy
                        d   = _math.sqrt(ddx * ddx + ddy * ddy) + 1e-8
                        push = excl_r * 0.5 / d
                    bx[i] += push * ddx; by[i] += push * ddy
        if not any_overlap: break
    return list(zip(bx, by))


def _rl_reduce_crossings(ix_list, bx_by, svg_coords, cx, cy):
    n = len(ix_list); bx_by = list(bx_by)
    def _anchor(ix):
        ai = ix.get("lig_atom_idx", 0)
        ax, ay = svg_coords.get(ai, (cx, cy))
        ri = ix.get("ring_atom_indices")
        if ri:
            rx, ry = _ring_centroid_2d(ri, svg_coords)
            if rx is not None: return (rx, ry)
        return (ax, ay)
    def _cross(a1, b1, a2, b2):
        def _side(O, A, B):
            return (B[0]-O[0])*(A[1]-O[1]) - (B[1]-O[1])*(A[0]-O[0])
        d1 = _side(a2, b2, a1); d2 = _side(a2, b2, b1)
        d3 = _side(a1, b1, a2); d4 = _side(a1, b1, b2)
        return (d1 * d2 < 0) and (d3 * d4 < 0)
    for _pass in range(n * 2):
        improved = False
        for i in range(n):
            for j in range(i + 1, n):
                if _cross(_anchor(ix_list[i]), bx_by[i], _anchor(ix_list[j]), bx_by[j]):
                    bx_by[i], bx_by[j] = bx_by[j], bx_by[i]; improved = True
        if not improved: break
    return bx_by


def _render_ligand_svg(mol2d, svg_coords):
    from rdkit import Chem
    parts=[]
    ri=mol2d.GetRingInfo()
    arom_bonds=set(); arom_rings=[]
    for ring in ri.AtomRings():
        if all(mol2d.GetAtomWithIdx(i).GetIsAromatic() for i in ring):
            for k in range(len(ring)):
                arom_bonds.add(frozenset([ring[k],ring[(k+1)%len(ring)]]))
            arom_rings.append(ring)
    def _sh(fx,fy,tx,ty,sym):
        if sym not in ("C",""):
            dx,dy=tx-fx,ty-fy; L=_math.sqrt(dx*dx+dy*dy)+1e-9
            r={"H":8,"N":9,"O":9,"S":11,"P":11,"F":8,"CL":13,"BR":13,"I":11}.get(sym,9)
            return fx+dx/L*r, fy+dy/L*r
        return fx,fy
    for bond in mol2d.GetBonds():
        i1,i2=bond.GetBeginAtomIdx(),bond.GetEndAtomIdx()
        x1,y1=svg_coords.get(i1,(0,0)); x2,y2=svg_coords.get(i2,(0,0))
        s1=mol2d.GetAtomWithIdx(i1).GetSymbol().upper()
        s2=mol2d.GetAtomWithIdx(i2).GetSymbol().upper()
        x1s,y1s=_sh(x1,y1,x2,y2,s1); x2s,y2s=_sh(x2,y2,x1,y1,s2)
        bt=bond.GetBondType()
        if frozenset([i1,i2]) in arom_bonds:
            parts.append(f'<line x1="{x1s:.2f}" y1="{y1s:.2f}" x2="{x2s:.2f}" y2="{y2s:.2f}" stroke="#1a1a1a" stroke-width="1.77" opacity="0.9"/>')
        elif bt==Chem.BondType.DOUBLE:
            dx,dy=x2s-x1s,y2s-y1s; L=_math.sqrt(dx*dx+dy*dy)+1e-9
            px,py=-dy/L*2.5,dx/L*2.5
            for sg in (1,-1):
                parts.append(f'<line x1="{x1s+px*sg:.2f}" y1="{y1s+py*sg:.2f}" x2="{x2s+px*sg:.2f}" y2="{y2s+py*sg:.2f}" stroke="#1a1a1a" stroke-width="2.44" opacity="0.9"/>')
        elif bt==Chem.BondType.TRIPLE:
            dx,dy=x2s-x1s,y2s-y1s; L=_math.sqrt(dx*dx+dy*dy)+1e-9
            px,py=-dy/L*3.8,dx/L*3.8
            for m in (-1,0,1):
                parts.append(f'<line x1="{x1s+px*m:.2f}" y1="{y1s+py*m:.2f}" x2="{x2s+px*m:.2f}" y2="{y2s+py*m:.2f}" stroke="#1a1a1a" stroke-width="2.0" opacity="0.9"/>')
        else:
            bd=bond.GetBondDir()
            if bd==Chem.BondDir.BEGINWEDGE:
                dx,dy=x2s-x1s,y2s-y1s; L=_math.sqrt(dx*dx+dy*dy)+1e-9
                px,py=-dy/L*3.0,dx/L*3.0
                parts.append(f'<polygon points="{x1s:.2f},{y1s:.2f} {x2s+px:.2f},{y2s+py:.2f} {x2s-px:.2f},{y2s-py:.2f}" fill="#1a1a1a" stroke="none"/>')
            elif bd==Chem.BondDir.BEGINDASH:
                dx,dy=x2s-x1s,y2s-y1s; L=_math.sqrt(dx*dx+dy*dy)+1e-9
                px,py=-dy/L,dx/L
                for step in range(1,6):
                    t=step/7; mx2=x1s+dx*t; my2=y1s+dy*t; w=t*5.0
                    parts.append(f'<line x1="{mx2-px*w:.2f}" y1="{my2-py*w:.2f}" x2="{mx2+px*w:.2f}" y2="{my2+py*w:.2f}" stroke="#1a1a1a" stroke-width="1.6"/>')
            else:
                parts.append(f'<line x1="{x1s:.2f}" y1="{y1s:.2f}" x2="{x2s:.2f}" y2="{y2s:.2f}" stroke="#1a1a1a" stroke-width="1.77" opacity="0.9"/>')
    for ring in arom_rings:
        rcoords=[svg_coords.get(i,(0,0)) for i in ring]
        rcx=sum(x for x,y in rcoords)/len(rcoords)
        rcy=sum(y for x,y in rcoords)/len(rcoords)
        avg=sum(_math.sqrt((x-rcx)**2+(y-rcy)**2) for x,y in rcoords)/len(rcoords)
        cr=avg*0.58
        parts.append(f'<circle cx="{rcx:.2f}" cy="{rcy:.2f}" r="{cr:.2f}" fill="none" stroke="#1a1a1a" stroke-width="1.77" stroke-dasharray="5.43 2.72" opacity="0.7"/>')
        parts.append(f'<circle cx="{rcx:.2f}" cy="{rcy:.2f}" r="5.43" fill="{_AROM_DOT_CLR}"/>')
    for i in range(mol2d.GetNumAtoms()):
        atom=mol2d.GetAtomWithIdx(i); sym=atom.GetSymbol()
        if sym=="C": continue
        ax,ay=svg_coords.get(i,(0,0))
        clr=_ATOM_CLR.get(sym.upper(),"#555")
        fs={"H":16}.get(sym,17.65)
        hw={"H":7,"N":9,"O":9,"S":11,"P":11,"F":8,"CL":16,"BR":16,"I":11}.get(sym.upper(),9)
        parts.append(f'<rect x="{ax-hw:.1f}" y="{ay-11:.1f}" width="{hw*2:.0f}" height="22" fill="white" stroke="none"/>')
        parts.append(f'<text x="{ax:.2f}" y="{ay:.2f}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-size="{fs}" font-weight="700" fill="{clr}">{sym}</text>')
        fc=atom.GetFormalCharge()
        if fc!=0:
            fcs="+" if fc==1 else "\u2212" if fc==-1 else f"{fc:+d}"
            parts.append(f'<text x="{ax+hw:.1f}" y="{ay-hw+2:.1f}" font-family="Arial,sans-serif" font-size="10" fill="{clr}">{fcs}</text>')
    return "".join(parts)


def _render_diagram_svg(mol2d, svg_coords, placements, title, W, H):
    parts=[]
    parts.append(f'<svg width="100%" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">')
    parts.append(f'<rect width="{W}" height="{H}" fill="white"/>')
    if title:
        esc=title.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        tw=len(esc)*14.5+48; tw=max(tw,240); tw=min(tw,W-40)
        px=(W-tw)/2; ph=46; pr=ph/2
        parts.append(f'<rect x="{px:.1f}" y="14" width="{tw:.0f}" height="{ph}" rx="{pr:.1f}" ry="{pr:.1f}" fill="#f2f2f2" stroke="none"/>')
        parts.append(f'<text x="{W/2:.1f}" y="37" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-size="24.93" font-weight="700" fill="#1a1a1a">{esc}</text>')
    for p in placements:
        itype=p["itype"]; bx,by=p["bx"],p["by"]
        cbx=max(50,min(bx,W-50)); cby=max(70,min(by,H-65))
        bg=_RES_CIRCLE.get(itype,dict(fill="#cccccc",opacity=0.2))
        parts.append(f'<circle cx="{cbx:.1f}" cy="{cby:.1f}" r="24.55" fill="{bg["fill"]}" opacity="{bg["opacity"]}"/>')
    for p in placements:
        itype=p["itype"]
        if itype=="hydrophobic": continue
        bx,by=p["bx"],p["by"]
        cbx=max(50,min(bx,W-50)); cby=max(70,min(by,H-65))
        if itype in ("pi_pi","cation_pi") and p.get("ring_atom_indices"):
            lx,ly=_ring_centroid_2d(p["ring_atom_indices"],svg_coords)
            if lx is None:
                ai=p.get("lig_atom_idx",0); lx,ly=svg_coords.get(ai,(W//2,H//2))
        else:
            ai=p.get("lig_atom_idx",0); lx,ly=svg_coords.get(ai,(W//2,H//2))
        clr=_LINE_CLR.get(itype,"#888")
        dash_attr=' stroke-dasharray="5 3"'
        dash_attr_hbx=' stroke-dasharray="4 2 1 2"'
        if itype in ("pi_pi","cation_pi"):
            parts.append(f'<line x1="{lx:.2f}" y1="{ly:.2f}" x2="{cbx:.2f}" y2="{cby:.2f}" stroke="{clr}" stroke-width="1.6"{dash_attr} opacity="0.85"/>')
        elif itype in ("hbond","hbond_to_halogen"):
            da=dash_attr if itype=="hbond" else dash_attr_hbx
            parts.append(f'<line x1="{lx:.2f}" y1="{ly:.2f}" x2="{cbx:.2f}" y2="{cby:.2f}" stroke="{clr}" stroke-width="1.6"{da} opacity="0.85"/>')
            if p.get("distance") is not None:
                t_along=0.40; bx_l=lx+(cbx-lx)*t_along; by_l=ly+(cby-ly)*t_along
                dx_l=cbx-lx; dy_l=cby-ly; _len=_math.sqrt(dx_l*dx_l+dy_l*dy_l)+1e-9
                px_l=-dy_l/_len*14; py_l=dx_l/_len*14; mx2=bx_l+px_l*14; my2=by_l+py_l*14
                ds=f"{p['distance']}\u00c5"; tw2=len(ds)*7+8
                parts.append(f'<rect x="{mx2-tw2/2:.1f}" y="{my2-9:.1f}" width="{tw2:.0f}" height="17" rx="4" fill="white" stroke="{clr}" stroke-width="0.5"/>')
                parts.append(f'<text x="{mx2:.1f}" y="{my2:.1f}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-size="14" font-weight="700" fill="{clr}">{ds}</text>')
        else:
            da={"ionic":"6 2 2 2","metal":"3 2","halogen":"5 2"}.get(itype,"5 3")
            parts.append(f'<line x1="{lx:.2f}" y1="{ly:.2f}" x2="{cbx:.2f}" y2="{cby:.2f}" stroke="{clr}" stroke-width="1.8" stroke-dasharray="{da}" opacity="0.85"/>')
            if p.get("distance") is not None:
                t_along=0.40; bx_l=lx+(cbx-lx)*t_along; by_l=ly+(cby-ly)*t_along
                dx_l=cbx-lx; dy_l=cby-ly; _len=_math.sqrt(dx_l*dx_l+dy_l*dy_l)+1e-9
                px_l=-dy_l/_len*14; py_l=dx_l/_len*14; mx2=bx_l+px_l*14; my2=by_l+py_l*14
                ds=f"{p['distance']}\u00c5"; tw2=len(ds)*7+8
                parts.append(f'<rect x="{mx2-tw2/2:.1f}" y="{my2-9:.1f}" width="{tw2:.0f}" height="17" rx="4" fill="white" stroke="{clr}" stroke-width="0.5"/>')
                parts.append(f'<text x="{mx2:.1f}" y="{my2:.1f}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-size="14" font-weight="700" fill="{clr}">{ds}</text>')
    parts.append(_render_ligand_svg(mol2d, svg_coords))
    for p in placements:
        itype=p["itype"]; bx,by=p["bx"],p["by"]
        cbx=max(50,min(bx,W-50)); cby=max(70,min(by,H-65))
        rn=p["resname"]; ri=p["resid"]; ch=p.get("chain","")
        _NO_NUM = HEME_RESNAMES | METAL_RESNAMES
        lbl = rn.upper() if rn.upper() in _NO_NUM else f"{rn.upper()} {ri}{ch}"
        lbl_clr=_LBL_CLR.get(itype,"#333")
        parts.append(f'<text x="{cbx:.1f}" y="{cby:.1f}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-size="14.29" font-weight="700" fill="{lbl_clr}">{lbl}</text>')
    _LEG_ORDER=["hydrophobic","hbond","pi_pi","cation_pi","hbond_to_halogen","ionic","metal","halogen"]
    _LEG_LABEL={"hydrophobic":"Hydrophobic","hbond":"Hydrogen bond","hbond_to_halogen":"H\u00b7\u00b7\u00b7Halogen","pi_pi":"\u03c0-\u03c0 stacking","cation_pi":"Cation-\u03c0","ionic":"Ionic","metal":"Metal contact","halogen":"Halogen bond"}
    active=[t for t in _LEG_ORDER if any(p["itype"]==t for p in placements)]
    if active:
        ly0=H-52
        def _entry_w(t):
            txt=_LEG_LABEL.get(t,t)
            return 9.54*2+(4+28 if t!="hydrophobic" else 0)+6+len(txt)*9.5+20
        total_w=sum(_entry_w(t) for t in active); total_w=min(total_w,W-40)
        lx0=(W-total_w)/2
        parts.append(f'<rect x="{lx0-8:.0f}" y="{ly0-5}" width="{total_w+16:.0f}" height="44" fill="white" stroke="#e0e0e0" stroke-width="0.8" rx="6"/>')
        for k,it in enumerate(active):
            bg=_RES_CIRCLE.get(it,dict(fill="#ccc",opacity=0.2))
            clr=_LINE_CLR.get(it,bg["fill"])
            lbl=_LEG_LABEL.get(it,it)
            text_w=len(lbl)*9.5+6
            glyph_w=9.54*2+(4+28 if it!="hydrophobic" else 0)
            entry_w=glyph_w+6+text_w
            circ_cx=lx0+sum(
                (9.54*2+(4+28 if active[kk]!="hydrophobic" else 0)+6+len(_LEG_LABEL.get(active[kk],active[kk]))*9.5+6+20)
                for kk in range(k)
            )+9.54
            parts.append(f'<circle cx="{circ_cx:.1f}" cy="{ly0+10}" r="9.54" fill="{bg["fill"]}" opacity="{bg["opacity"]}"/>')
            line_x1=circ_cx+9.54+4; line_x2=line_x1+28
            if it!="hydrophobic":
                parts.append(f'<line x1="{line_x1:.1f}" y1="{ly0+10}" x2="{line_x2:.1f}" y2="{ly0+10}" stroke="{clr}" stroke-width="2" stroke-dasharray="5 3" opacity="0.85"/>')
            text_x=(line_x2 if it!="hydrophobic" else circ_cx+9.54)+6
            parts.append(f'<text x="{text_x:.1f}" y="{ly0+10}" text-anchor="start" dominant-baseline="central" font-family="Arial,sans-serif" font-size="16" font-weight="700" fill="#555">{lbl}</text>')
    if any(p["itype"] == "metal" for p in placements):
        parts.append(f'<text x="{W//2}" y="{H-5}" text-anchor="middle" font-size="12" fill="#555">{METAL_CONTACT_LABEL}</text>')
    parts.append('</svg>')
    return "\n".join(parts)


def _build_diagram_data(receptor_pdb, pose_sdf, smiles, cutoff, max_residues, size=(800,759)):
    from rdkit import Chem, RDLogger
    from rdkit.Chem import rdDepictor
    RDLogger.DisableLog("rdApp.*")
    W, H = size
    mol3d = None
    for san in (True, False):
        sup = Chem.SDMolSupplier(pose_sdf, sanitize=san, removeHs=False)
        mol3d = next((m for m in sup if m is not None), None)
        if mol3d is not None:
            if not san:
                try: Chem.SanitizeMol(mol3d)
                except: pass
            break
    if mol3d is None or mol3d.GetNumConformers() == 0:
        raise ValueError("No valid 3D pose in SDF")

    def _parse_smi_robust(smi):
        if not smi: return None
        m = Chem.MolFromSmiles(smi)
        if m: return m
        try:
            m = Chem.MolFromSmiles(smi, sanitize=False)
            if m is None: return None
            m.UpdatePropertyCache(strict=False)
            Chem.FastFindRings(m)
            Chem.SetAromaticity(m)
            m2 = Chem.MolFromSmiles(Chem.MolToSmiles(m))
            return m2 if m2 else m
        except Exception:
            return None

    mol2d = None
    if smiles and smiles.strip():
        mol2d = _parse_smi_robust(smiles.strip())
    if mol2d is None:
        mol2d = Chem.RemoveHs(mol3d, sanitize=False)
        try: Chem.SanitizeMol(mol2d)
        except: pass
    mol2d = Chem.RemoveHs(mol2d)
    rdDepictor.Compute2DCoords(mol2d)

    m3 = Chem.RemoveHs(mol3d, sanitize=False)
    try: Chem.SanitizeMol(m3)
    except: pass

    m3to2d = {}
    try:
        def _strip_charges(mol):
            rw = Chem.RWMol(mol)
            for a in rw.GetAtoms(): a.SetFormalCharge(0)
            Chem.SanitizeMol(rw)
            return rw.GetMol()
        m3_neutral    = _strip_charges(m3)
        mol2d_neutral = _strip_charges(mol2d)
        mt = m3_neutral.GetSubstructMatch(mol2d_neutral)
        if len(mt) == mol2d.GetNumAtoms():
            for i2, i3 in enumerate(mt): m3to2d[i3] = i2
    except Exception:
        try:
            mt = m3.GetSubstructMatch(mol2d)
            if len(mt) == mol2d.GetNumAtoms():
                for i2, i3 in enumerate(mt): m3to2d[i3] = i2
        except Exception:
            pass
    try: raw = _detect_all_interactions(mol3d, receptor_pdb, cutoff=cutoff)
    except: raw = []
    try: _enrich_with_res_xyz(raw, mol3d, receptor_pdb)
    except: pass
    for ix in raw:
        ix["lig_atom_idx"] = m3to2d.get(ix.get("lig_atom_idx", 0), 0)
        if ix.get("ring_atom_indices"):
            ix["ring_atom_indices"] = [m3to2d.get(i, i) for i in ix["ring_atom_indices"]]
    pm = {t: i for i, t in enumerate(_ITYPE_PRIORITY)}
    ded = _deduplicate_interactions(raw)
    ded.sort(key=lambda x: (pm.get(x["itype"], 99), x["distance"]))
    ded = ded[:max_residues]
    cx, cy = W // 2, H // 2
    sc = _compute_svg_coords(mol2d, cx, cy, target_size=280)
    pl = _place_residues_pca(ded, sc, mol3d, cx, cy, R=210)
    RDLogger.EnableLog("rdApp.error")
    return mol2d, sc, pl, W, H


def draw_interaction_diagram(
    receptor_pdb: str,
    pose_sdf: str,
    smiles: str,
    title: str = "",
    cutoff: float = 4.5,
    size: tuple = (800, 759),
    max_residues: int = 14,
) -> bytes:
    try:
        mol2d, sc, pl, W, H = _build_diagram_data(receptor_pdb, pose_sdf, smiles, cutoff, max_residues, size)
    except Exception as e:
        W, H = size
        return (f'<svg viewBox="0 0 {W} 80" xmlns="http://www.w3.org/2000/svg">'
                f'<rect width="{W}" height="80" fill="white"/>'
                f'<text x="{W//2}" y="44" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" fill="#cc2222">'
                f'Error: {e}</text></svg>').encode()
    svg = _render_diagram_svg(mol2d, sc, pl, title, W, H)
    return svg.encode()


def draw_interaction_diagram_data(
    receptor_pdb: str,
    pose_sdf: str,
    smiles: str,
    title: str = "",
    cutoff: float = 4.5,
    size: tuple = (800, 759),
    max_residues: int = 14,
) -> dict:
    from rdkit import Chem, RDLogger
    from rdkit.Chem import rdDepictor
    import json as _json
    RDLogger.DisableLog("rdApp.*")
    W, H = size
    try:
        mol2d, sc, pl, W, H = _build_diagram_data(receptor_pdb, pose_sdf, smiles, cutoff, max_residues, size)
    except Exception:
        return None
    lig_svg = _render_ligand_svg(mol2d, sc)
    sc_serial = {str(k): [round(v[0], 2), round(v[1], 2)] for k, v in sc.items()}
    pl_serial = []
    for p in pl:
        lx, ly = sc.get(p.get("lig_atom_idx", 0), (W//2, H//2))
        if p.get("ring_atom_indices"):
            rx, ry = _ring_centroid_2d(p["ring_atom_indices"], sc)
            if rx is not None: lx, ly = rx, ry
        pl_serial.append({
            "id":       f"r{len(pl_serial)}",
            "label":    (p['resname'].upper() if p['resname'].upper() in (HEME_RESNAMES | METAL_RESNAMES)
                         else f"{p['resname']} {p['resid']}{p.get('chain','')}"),
            "itype":    p["itype"],
            "distance": p.get("distance"),
            "lx":       round(lx, 2),
            "ly":       round(ly, 2),
            "bx":       round(p["bx"], 2),
            "by":       round(p["by"], 2),
        })
    RDLogger.EnableLog("rdApp.error")
    return {
        "W": W, "H": H, "title": title,
        "ligand_svg": lig_svg,
        "placements": pl_serial,
        "svg_coords": sc_serial,
    }


def draw_interactions_rdkit_classic(
    lig_mol,
    receptor_pdb: str,
    smiles: str,
    title: str = "",
    cutoff: float = 3.5,
    size: tuple = (650, 620),
    max_residues: int = 10,
) -> bytes:
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Draw, rdDepictor, AllChem
    RDLogger.DisableLog("rdApp.*")
    _C_HB = (0.35, 0.61, 0.84, 0.45)
    _C_HP = (0.17, 0.55, 0.34, 0.45)
    _C_OT = (0.80, 0.37, 0.54, 0.45)
    def _parse_robust(smi):
        if not smi: return None
        m = Chem.MolFromSmiles(smi)
        if m: return m
        try:
            m = Chem.MolFromSmiles(smi, sanitize=False)
            if m is None: return None
            m.UpdatePropertyCache(strict=False)
            Chem.FastFindRings(m)
            Chem.SetAromaticity(m)
            m2 = Chem.MolFromSmiles(Chem.MolToSmiles(m))
            return m2 if m2 else m
        except Exception:
            return None
    W, H = size
    mol2d = _parse_robust(smiles)
    if mol2d is None:
        mol2d = Chem.RemoveHs(lig_mol, sanitize=False)
        try: Chem.SanitizeMol(mol2d)
        except: pass
    rdDepictor.Compute2DCoords(mol2d)
    n2d = mol2d.GetNumAtoms()
    mol3d_noH = Chem.RemoveHs(lig_mol, sanitize=False)
    try: Chem.SanitizeMol(mol3d_noH)
    except: pass
    idx3d_to_2d = {}
    try:
        def _strip_charges_rdk(mol):
            rw = Chem.RWMol(mol)
            for a in rw.GetAtoms(): a.SetFormalCharge(0)
            Chem.SanitizeMol(rw)
            return rw.GetMol()
        m3n   = _strip_charges_rdk(mol3d_noH)
        m2d_n = _strip_charges_rdk(mol2d)
        match = m3n.GetSubstructMatch(m2d_n)
        if len(match) == mol2d.GetNumAtoms():
            for i2d, i3d in enumerate(match):
                idx3d_to_2d[i3d] = i2d
    except Exception:
        try:
            match = mol3d_noH.GetSubstructMatch(mol2d)
            if len(match) == mol2d.GetNumAtoms():
                for i2d, i3d in enumerate(match):
                    idx3d_to_2d[i3d] = i2d
        except Exception:
            pass
    try:
        raw = _detect_all_interactions(lig_mol, receptor_pdb, cutoff=cutoff)
    except:
        raw = []
    for ix in raw:
        ix["lig_atom_idx"] = idx3d_to_2d.get(ix.get("lig_atom_idx", 0), 0)
    pm = {t: i for i, t in enumerate(_ITYPE_PRIORITY)}
    deduped = _deduplicate_interactions(raw)
    deduped.sort(key=lambda x: (pm.get(x["itype"], 99), x["distance"]))
    deduped = deduped[:max_residues]
    if not deduped:
        d2d = Draw.MolDraw2DSVG(W, H)
        d2d.DrawMolecule(mol2d, legend=title or "No interactions found")
        d2d.FinishDrawing()
        RDLogger.EnableLog("rdApp.error")
        return d2d.GetDrawingText().encode()
    lig_ext = Chem.RWMol(mol2d)
    pts, clrs = [], {}
    for ix in deduped:
        itype = ix["itype"]
        ai = ix.get("lig_atom_idx", 0)
        if ai >= n2d: ai = 0
        if itype in ("hbond", "hbond_to_halogen"): color = _C_HB
        elif itype == "hydrophobic":                color = _C_HP
        else:                                       color = _C_OT
        rn = ix["resname"]; ri = ix["resid"]; ch = ix.get("chain","")
        _NO_NUM = HEME_RESNAMES | METAL_RESNAMES
        lbl = rn.upper() if rn.upper() in _NO_NUM else f"{rn}{ri}{ch}"
        res_atom = Chem.Atom(0)
        res_atom.SetProp("atomLabel", lbl)
        aid = lig_ext.AddAtom(res_atom)
        pts.append(aid); clrs[aid] = color
        lig_ext.AddBond(aid, ai, Chem.BondType.ZERO)
    rdDepictor.Compute2DCoords(lig_ext)
    d2d = Draw.MolDraw2DSVG(W, H)
    opts = d2d.drawOptions()
    opts.circleAtoms = True; opts.fillHighlights = True
    opts.continuousHighlight = False; opts.highlightRadius = 0.5
    opts.addAtomIndices = False; opts.padding = 0.15
    try:
        d2d.SetDrawBounds(0, 0, W, H - 40)
    except AttributeError:
        pass
    d2d.DrawMolecule(lig_ext, highlightAtoms=pts, highlightAtomColors=clrs)
    d2d.FinishDrawing()
    svg_text = d2d.GetDrawingText()
    if title:
        svg_text = _svg_stamp(svg_text, title, W, H)
    RDLogger.EnableLog("rdApp.error")
    return svg_text.encode()


def draw_interactions_rdkit(lig_mol, receptor_pdb: str, smiles: str,
                            title: str="", cutoff: float=3.5,
                            size: tuple=(500,500), max_residues: int=10) -> bytes:
    import tempfile
    from rdkit import Chem
    tmp=tempfile.NamedTemporaryFile(suffix=".sdf",delete=False)
    with Chem.SDWriter(tmp.name) as w: w.write(lig_mol)
    return draw_interaction_diagram(receptor_pdb=receptor_pdb,pose_sdf=tmp.name,
        smiles=smiles,title=title,cutoff=cutoff,size=(800,759),max_residues=max_residues)


def _svg_stamp(svg_text:str,title:str,w:int,h:int)->str:
    esc=title.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
    pad=int(w*0.05); pw=w-2*pad; ph=28; py=h-ph-8; ty=py+ph//2; r=ph//2
    st=(f'<g><rect x="{pad}" y="{py}" width="{pw}" height="{ph}" rx="{r}" ry="{r}"'
        f' fill="#E8E8E8" fill-opacity="0.93" stroke="#C8C8C8" stroke-width="0.5"/>'
        f'<text x="{w//2}" y="{ty}" text-anchor="middle" dominant-baseline="middle"'
        f' font-family="Arial,sans-serif" font-size="13" font-weight="500" fill="#1A1A1A">'
        f'{esc}</text></g>')
    return svg_text.replace("</svg>",f"{st}</svg>")


def draw_interaction_diagram_interactive(
    receptor_pdb: str,
    pose_sdf: str,
    smiles: str,
    title: str = "",
    cutoff: float = 4.5,
    size: tuple = (800, 759),
    max_residues: int = 14,
) -> str:
    import json
    try:
        mol2d, sc, pl, W, H = _build_diagram_data(receptor_pdb, pose_sdf, smiles, cutoff, max_residues, size)
    except Exception as e:
        return f'<p style="color:red">Error: {e}</p>'
    lig_svg = _render_ligand_svg(mol2d, sc)
    residues_js = []
    for p in pl:
        itype = p["itype"]
        ai    = p.get("lig_atom_idx", 0)
        lx, ly = sc.get(ai, (W // 2, H // 2))
        if itype in ("pi_pi", "cation_pi") and p.get("ring_atom_indices"):
            rx, ry = _ring_centroid_2d(p["ring_atom_indices"], sc)
            if rx is not None: lx, ly = rx, ry
        residues_js.append({
            "id":      p["resname"] + str(p["resid"]) + p.get("chain",""),
            "label":   (p['resname'].upper() if p['resname'].upper() in (HEME_RESNAMES | METAL_RESNAMES)
                        else f"{p['resname']} {p['resid']}{p.get('chain','')}"),
            "itype":   itype,
            "dist":    str(p["distance"]) + "\u00c5" if p.get("distance") else "",
            "lx":      round(lx, 2), "ly": round(ly, 2),
            "bx":      round(p["bx"], 2), "by": round(p["by"], 2),
        })
    return json.dumps({"placements": residues_js, "W": W, "H": H,
                       "ligand_svg": lig_svg, "title": title})

# Shared reporting and reproducibility support (synchronized across distributions).
METAL_CONTACT_LABEL = "Metal contact (distance-based; geometry not scored)"
RANKING_INTERPRETATION = (
    "A large gap between top-1 RMSD and minimum RMSD indicates a ranking problem, "
    "not a sampling problem. Increasing exhaustiveness will not fix it."
)
METAL_MICROSTATE_RULES = [{
    "name": "sulfonamide_Zn",
    "smarts": "[S:1](=[O:2])(=[O:3])[N;H1,H2;+0:4]",
    "metal": "ZN", "atom_map": 4, "suggested_charge": -1,
    "note": "Metal-induced deprotonation is not predicted by bulk-pH protonation models. "
            "For Zn-dependent enzymes (e.g. carbonic anhydrases), the bound state of a "
            "sulfonamide is commonly the deprotonated nitrogen coordinating the metal, "
            "even though its solution pKa is above 7.4.",
}]


def receptor_metal_atoms(receptor_path):
    """Read PDB/PDBQT metal coordinates, including Fe within retained heme."""
    metals = {"ZN", "MG", "CA", "MN", "FE", "CU", "NI", "CO"}
    atoms = []
    for line in Path(receptor_path).read_text().splitlines():
        if not line.startswith(("ATOM  ", "HETATM")):
            continue
        name, resname = line[12:16].strip(), line[17:20].strip()
        if str(receptor_path).lower().endswith(".pdbqt"):
            element = line.split()[-1].upper()
        else:
            element = line[76:78].strip().upper()
        # CA in a protein ATOM record is the alpha carbon, never calcium.
        if not element and line.startswith("HETATM"):
            element = name.upper() if name.upper() in metals else resname.upper()
        if element not in metals:
            continue
        chain = line[21:22].strip()
        try:
            resid = int(line[22:26])
            xyz = tuple(float(line[a:b]) for a, b in ((30,38),(38,46),(46,54)))
        except ValueError:
            fields = line.split()
            chain, resid = (fields[4], int(fields[5])) if not fields[4].lstrip('-').isdigit() else ('', int(fields[4]))
            start = 6 if chain else 5
            xyz = tuple(float(v) for v in fields[start:start+3])
        atoms.append(dict(element=element, name=name, resname=resname,
                          chain=chain, resid=resid, xyz=xyz))
    return atoms


def detect_metal_contacts(ligand, receptor_path, cutoff=3.0):
    """Distance-only contacts for every ligand heavy atom, without changing scores.

    Accept an RDKit conformer molecule or a list of atom dictionaries with xyz,
    element and name. The 3.0 A reporting shell is distinct from the <1.8 A warning.
    """
    import math
    if hasattr(ligand, "GetAtoms"):
        conf = ligand.GetConformer()
        ligand = [dict(element=a.GetSymbol(), name=f"{a.GetSymbol()}{a.GetIdx()+1}",
                       index=a.GetIdx(), xyz=tuple(conf.GetAtomPosition(a.GetIdx())))
                  for a in ligand.GetAtoms() if a.GetAtomicNum() > 1]
    contacts = []
    for metal in receptor_metal_atoms(receptor_path):
        for index, atom in enumerate(ligand):
            if atom["element"].upper() in {"H", "HD", "HS", "D"}:
                continue
            distance = math.dist(atom["xyz"], metal["xyz"])
            if distance > cutoff:
                continue
            label = f"{metal['element']} {metal['resname']}{metal['resid']}{metal['chain']}"
            warning = ""
            if distance < 1.8:
                warning = (f"Ligand atom {atom['name']} is {distance:.2f} A from {label} — shorter than typical "
                           "coordination distances (~1.9-2.1 A). The Vina scoring function contains no "
                           "metal-coordination term, so this distance is not physically restrained. "
                           "Do not interpret it as a coordination bond without independent QM/MM or "
                           "experimental support.")
            contacts.append(dict(itype="metal", category=METAL_CONTACT_LABEL,
                distance=distance, lig_atom_idx=atom.get("index", index), ligand_atom=atom["name"],
                resname=metal["resname"], resid=metal["resid"], chain=metal["chain"],
                prot_el=metal["element"], is_donor=False, ring_atom_indices=None, warning=warning))
    return contacts


def metal_microstate_candidates(smiles, receptor_path=None, metals=None):
    """Additional metal-aware candidates. Leave the bulk-pH selection untouched."""
    from rdkit import Chem
    available = {str(m).upper() for m in (metals or [])}
    if receptor_path:
        available.update(m["element"] for m in receptor_metal_atoms(receptor_path))
    if not available:
        return []
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return []
    candidates, seen = [], set()
    for rule in METAL_MICROSTATE_RULES:
        if rule["metal"] not in available:
            continue
        query = Chem.MolFromSmarts(rule["smarts"])
        site = next(a.GetIdx() for a in query.GetAtoms() if a.GetAtomMapNum() == rule["atom_map"])
        for match in mol.GetSubstructMatches(query):
            copy = Chem.RWMol(mol)
            atom = copy.GetAtomWithIdx(match[site])
            hydrogens = atom.GetTotalNumHs()
            atom.SetFormalCharge(rule["suggested_charge"])
            atom.SetNumExplicitHs(hydrogens - 1)
            atom.SetNoImplicit(True)
            Chem.SanitizeMol(copy)
            candidate = Chem.MolToSmiles(copy)
            if candidate in seen:
                continue
            seen.add(candidate)
            candidates.append(dict(smiles=candidate, rule=rule["name"], metal=rule["metal"],
                                   note=rule["note"], additional_candidate=True))
    return candidates


def summarize_seed_rmsds(runs):
    """Sample SD across valid seeds. Missing RMSD remains unavailable."""
    import statistics
    summary = {"runs": runs, "interpretation": RANKING_INTERPRETATION}
    for metric in ("top1_rmsd", "minimum_rmsd"):
        values = [r[metric] for r in runs if r.get(metric) is not None]
        summary[metric] = dict(mean=statistics.mean(values) if values else None,
                               sd=statistics.stdev(values) if len(values) > 1 else None,
                               available_seeds=len(values))
    return summary


def annotate_docking_result(result, receptor_path, crystal_pdb=None):
    """Annotate exact saved poses and save an exportable report beside each run."""
    if not result.get("success"):
        return result
    import json
    path = result.get("out_pdbqt")
    contacts = []
    has_metals = Path(receptor_path).is_file() and bool(receptor_metal_atoms(receptor_path))
    if has_metals and path and Path(path).is_file():
        pose, atoms = 1, []
        def collect():
            if not atoms:
                return
            for contact in detect_metal_contacts(atoms, receptor_path):
                contacts.append(dict(contact, pose=pose))
        for line in Path(path).read_text().splitlines():
            if line.startswith("MODEL"):
                pose = int(line.split()[1])
            elif line.startswith(("ATOM  ", "HETATM")):
                atoms.append(dict(name=line[12:16].strip(), element=line.split()[-1],
                    xyz=tuple(float(line[a:b]) for a,b in ((30,38),(38,46),(46,54)))))
            elif line.startswith("ENDMDL"):
                collect()
                atoms = []
        if atoms:
            collect()
    elif has_metals and result.get("out_sdf") and Path(result["out_sdf"]).is_file():
        from rdkit import Chem
        for rank, mol in enumerate(Chem.SDMolSupplier(result["out_sdf"], sanitize=False, removeHs=False), 1):
            if mol is not None:
                contacts.extend(dict(contact, pose=rank) for contact in detect_metal_contacts(mol, receptor_path))
    result["metal_contacts"] = contacts
    result["warnings"] = list(dict.fromkeys(c["warning"] for c in contacts if c["warning"]))
    result["metal_contact_category"] = METAL_CONTACT_LABEL
    report_source = path or result.get("out_sdf")
    if report_source:
        report = Path(report_source).with_suffix(".summary.txt")
        lines = [METAL_CONTACT_LABEL] if contacts else []
        lines += [f"Pose {c['pose']}, {c['ligand_atom']} -> {c['prot_el']} "
                  f"{c['resname']}{c['resid']}{c['chain']}: {c['distance']:.2f} A" for c in contacts]
        lines += result["warnings"]
        if result.get("replicate_summary"):
            lines += [json.dumps(result["replicate_summary"], indent=2)]
        report.write_text("\n".join(lines) + "\n")
        result["summary_file"] = str(report)
    return result


def run_seed_replicates(runner, options, replicate_seeds=1, crystal_pdb=None, smiles=None):
    """Execute isolated seed runs with the selected engine and unchanged RMSD gate."""
    import secrets
    if isinstance(replicate_seeds, bool) or int(replicate_seeds) != replicate_seeds or replicate_seeds < 1:
        raise ValueError("replicate_seeds must be a positive integer")
    options = dict(options)
    base = options.get("seed")
    if replicate_seeds > 1 and base is None:
        base = secrets.randbelow(2**30)
    runs, primary = [], None
    for index in range(replicate_seeds):
        current = dict(options)
        if replicate_seeds > 1:
            current.update(seed=(base + index) % (2**31 - 1),
                           out_name=(options.get('out_name', 'out') if index == 0
                                     else f"{options.get('out_name', 'out')}_seed{index+1}"))
        result = runner(**current)
        if primary is None:
            primary = result
        row = dict(seed=current.get("seed"), success=result.get("success", False),
                   out_sdf=result.get("out_sdf"), top1_rmsd=None, minimum_rmsd=None,
                   error=result.get("error"))
        if result.get("success") and crystal_pdb and result.get("out_sdf"):
            sdf = result["out_sdf"]
            if smiles:
                fixed = str(Path(sdf).with_suffix(".rmsd.sdf"))
                fix_sdf_bond_orders(sdf, smiles, fixed)
                if Path(fixed).is_file():
                    sdf = fixed
            from rdkit import Chem
            mols = list(Chem.SDMolSupplier(sdf, sanitize=False, removeHs=False))
            values = [calc_rmsd_heavy(mol, crystal_pdb) if mol is not None else None for mol in mols]
            row["top1_rmsd"] = values[0] if values else None
            valid = [v for v in values if v is not None]
            row["minimum_rmsd"] = min(valid) if valid else None
        annotate_docking_result(result, current["receptor_pdbqt"])
        row["warnings"] = result.get("warnings", [])
        row["summary_file"] = result.get("summary_file")
        runs.append(row)
    if replicate_seeds > 1:
        primary["replicate_summary"] = summarize_seed_rmsds(runs)
        annotate_docking_result(primary, options["receptor_pdbqt"])
    return primary


def _install_reporting_support():
    import functools
    import inspect
    original = run_vina
    @functools.wraps(original)
    def reporting_run(*args, replicate_seeds=1, crystal_pdb=None, smiles=None, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        return run_seed_replicates(original, bound.arguments, replicate_seeds, crystal_pdb, smiles)
    globals()["run_vina"] = reporting_run
    original_multi = globals().get("run_vina_multi")
    def reporting_multi(*args, replicate_seeds=1, **kwargs):
        bound = inspect.signature(original_multi).bind(*args, **kwargs)
        bound.apply_defaults()
        return run_seed_replicates(original_multi, bound.arguments, replicate_seeds)
    if original_multi is not None:
        globals()["run_vina_multi"] = functools.wraps(original_multi)(reporting_multi)
    original_prepare = prepare_ligand
    @functools.wraps(original_prepare)
    def prepare(*args, receptor_path=None, **kwargs):
        result = original_prepare(*args, **kwargs)
        if result.get("success") and receptor_path and result.get("protonation_mode") == "pkanet":
            result["metal_microstate_candidates"] = metal_microstate_candidates(
                result.get("prot_smiles", ""), receptor_path)
            result.setdefault("log", []).extend(c["note"] for c in result["metal_microstate_candidates"])
        return result
    globals()["prepare_ligand"] = prepare
    original_interactions = _detect_all_interactions
    @functools.wraps(original_interactions)
    def interactions(ligand, receptor_pdb, cutoff=4.5):
        raw = original_interactions(ligand, receptor_pdb, cutoff=cutoff)
        raw = [ix for ix in raw if ix.get("itype") != "metal"]
        return raw + detect_metal_contacts(ligand, receptor_pdb)
    globals()["_detect_all_interactions"] = interactions


_install_reporting_support()
